Public Class countersink_input

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bu_ok.Click
        Me.Hide()
    End Sub

    Private Sub countersink_input_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class