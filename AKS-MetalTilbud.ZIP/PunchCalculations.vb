Public Class PunchCalculations

    Public Function CalculatePunchTimes(ByVal iNumberOfPlates As Integer, ByVal iPlateX As Integer, ByVal iPlateY As Integer, ByVal iSubjectX As Integer, ByVal iSubjectY As Integer, ByVal iToolChanges As Integer, ByVal iNumberOfHoles As Integer, ByVal Difficultfactor As Double) As Double
        Dim objDatabaseIO As DatabaseIO

        Dim punch100min As Double
        Dim ilgang1 As Double
        Dim ilgang2 As Double
        Dim ilgang3 As Double
        Dim ilgang100min As Double
        Dim toolshift100min As Double
        Dim subjectremove100min As Double
        Dim Dtrumpf100min As Double
        Dim sheetshift As Double






        objDatabaseIO = New DatabaseIO
        punch100min = (((((iSubjectX + iSubjectY) * 2) / 49) + iNumberOfHoles) * 100) / (5 * 60)

        ilgang1 = ((Math.Sqrt(Math.Pow(iSubjectX, 2) + (Math.Pow(iSubjectY, 2))) / 3) * iNumberOfHoles * 100)
        ilgang2 = (Math.Sqrt(Math.Pow(iPlateX, 2) + (Math.Pow(iPlateY, 2))) * iNumberOfPlates)
        ilgang3 = ((iSubjectX + iSubjectY) / 2) * 100
        ilgang100min = (ilgang1 + ilgang2 + ilgang3) / 60000

        toolshift100min = (iToolChanges * iNumberOfPlates * 5) / 60

        If iSubjectX > 350 Or iSubjectY > 350 Then
            subjectremove100min = (15 * 100) / 60
        Else
            subjectremove100min = (5 * 100) / 60
        End If

        If Difficultfactor = 0 Then
            Exit Function
        End If


        Dtrumpf100min = punch100min + ilgang100min + toolshift100min + (subjectremove100min * Difficultfactor)

        sheetshift = ((iNumberOfPlates * 30) + 16) / 60

        CalculatePunchTimes = Dtrumpf100min + sheetshift





    End Function
End Class
