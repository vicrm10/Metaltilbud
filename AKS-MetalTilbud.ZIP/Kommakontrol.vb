Public Class Kommakontrol
    Public Function Decimalkontrol(ByVal time) As Double

        Decimalkontrol = FormatNumber(time, 1)
    End Function
End Class
