<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class metal_tilbud
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(metal_tilbud))
        Me.Label78 = New System.Windows.Forms.Label
        Me.rtb_bem = New System.Windows.Forms.RichTextBox
        Me.Label76 = New System.Windows.Forms.Label
        Me.Label68 = New System.Windows.Forms.Label
        Me.Label69 = New System.Windows.Forms.Label
        Me.lb_operat�r = New System.Windows.Forms.Label
        Me.lb_dato = New System.Windows.Forms.Label
        Me.Label56 = New System.Windows.Forms.Label
        Me.Label57 = New System.Windows.Forms.Label
        Me.Label39 = New System.Windows.Forms.Label
        Me.Label50 = New System.Windows.Forms.Label
        Me.tb_opstart_afgivettilbud = New System.Windows.Forms.TextBox
        Me.Label51 = New System.Windows.Forms.Label
        Me.Label54 = New System.Windows.Forms.Label
        Me.tb_opstart_avance = New System.Windows.Forms.TextBox
        Me.Label55 = New System.Windows.Forms.Label
        Me.Label59 = New System.Windows.Forms.Label
        Me.Label60 = New System.Windows.Forms.Label
        Me.lb_opst_prog_brutto = New System.Windows.Forms.Label
        Me.lb_opstart_program = New System.Windows.Forms.Label
        Me.lb_program_kr = New System.Windows.Forms.Label
        Me.lb_antal_opstart = New System.Windows.Forms.Label
        Me.Label38 = New System.Windows.Forms.Label
        Me.Label37 = New System.Windows.Forms.Label
        Me.tb_tilbud2 = New System.Windows.Forms.TextBox
        Me.tb_tilbud3 = New System.Windows.Forms.TextBox
        Me.tb_tilbud4 = New System.Windows.Forms.TextBox
        Me.tb_tilbud5 = New System.Windows.Forms.TextBox
        Me.tb_tilbud1 = New System.Windows.Forms.TextBox
        Me.Label36 = New System.Windows.Forms.Label
        Me.Label35 = New System.Windows.Forms.Label
        Me.tb_avance = New System.Windows.Forms.TextBox
        Me.Label49 = New System.Windows.Forms.Label
        Me.Label48 = New System.Windows.Forms.Label
        Me.Label47 = New System.Windows.Forms.Label
        Me.Label53 = New System.Windows.Forms.Label
        Me.Label52 = New System.Windows.Forms.Label
        Me.Label46 = New System.Windows.Forms.Label
        Me.Label45 = New System.Windows.Forms.Label
        Me.lb_salg2 = New System.Windows.Forms.Label
        Me.lb_salg3 = New System.Windows.Forms.Label
        Me.lb_salg4 = New System.Windows.Forms.Label
        Me.lb_salg5 = New System.Windows.Forms.Label
        Me.lb_salg1 = New System.Windows.Forms.Label
        Me.lb_samlet2 = New System.Windows.Forms.Label
        Me.lb_samlet3 = New System.Windows.Forms.Label
        Me.lb_samlet4 = New System.Windows.Forms.Label
        Me.lb_samlet5 = New System.Windows.Forms.Label
        Me.lb_samlet1 = New System.Windows.Forms.Label
        Me.lb_cnc2 = New System.Windows.Forms.Label
        Me.lb_cnc3 = New System.Windows.Forms.Label
        Me.lb_cnc4 = New System.Windows.Forms.Label
        Me.lb_cnc5 = New System.Windows.Forms.Label
        Me.lb_cnc1 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.lb_timer5 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.lb_indk�b2 = New System.Windows.Forms.Label
        Me.lb_indk�b3 = New System.Windows.Forms.Label
        Me.lb_indk�b4 = New System.Windows.Forms.Label
        Me.lb_indk�b5 = New System.Windows.Forms.Label
        Me.lb_indk�b1 = New System.Windows.Forms.Label
        Me.lb_r�varer2 = New System.Windows.Forms.Label
        Me.lb_r�varer3 = New System.Windows.Forms.Label
        Me.lb_r�varer4 = New System.Windows.Forms.Label
        Me.lb_r�varer5 = New System.Windows.Forms.Label
        Me.lb_r�varerstk1 = New System.Windows.Forms.Label
        Me.lb_mand2 = New System.Windows.Forms.Label
        Me.lb_mand3 = New System.Windows.Forms.Label
        Me.lb_mand4 = New System.Windows.Forms.Label
        Me.lb_mand5 = New System.Windows.Forms.Label
        Me.lb_mand1 = New System.Windows.Forms.Label
        Me.tb_antal2 = New System.Windows.Forms.TextBox
        Me.tb_antal3 = New System.Windows.Forms.TextBox
        Me.tb_antal4 = New System.Windows.Forms.TextBox
        Me.tb_antal5 = New System.Windows.Forms.TextBox
        Me.tb_antal1 = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.tb_revision = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.tb_emne = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.cb_kunde = New System.Windows.Forms.ComboBox
        Me.bu_Reset = New System.Windows.Forms.Button
        Me.rb_netto = New System.Windows.Forms.RadioButton
        Me.rb_brutto = New System.Windows.Forms.RadioButton
        Me.lb_tykkelse = New System.Windows.Forms.Label
        Me.tb_pladetykkelse = New System.Windows.Forms.TextBox
        Me.cb_materiale = New System.Windows.Forms.ComboBox
        Me.gb_gruppe1 = New System.Windows.Forms.GroupBox
        Me.lb_laser_opstart = New System.Windows.Forms.Label
        Me.Label85 = New System.Windows.Forms.Label
        Me.lb_laserCNC_tid = New System.Windows.Forms.Label
        Me.tb_hulantal_3C = New System.Windows.Forms.TextBox
        Me.tb_laserCNC_tid_uk = New System.Windows.Forms.TextBox
        Me.tb_laser_opstart_uk = New System.Windows.Forms.TextBox
        Me.Label97 = New System.Windows.Forms.Label
        Me.Label64 = New System.Windows.Forms.Label
        Me.Label98 = New System.Windows.Forms.Label
        Me.tb_hulantal_2C = New System.Windows.Forms.TextBox
        Me.tb_hulantal_1C = New System.Windows.Forms.TextBox
        Me.lb_opstart = New System.Windows.Forms.Label
        Me.Label32 = New System.Windows.Forms.Label
        Me.tb_cuttinglength_C = New System.Windows.Forms.TextBox
        Me.Label31 = New System.Windows.Forms.Label
        Me.rb_C_laser = New System.Windows.Forms.RadioButton
        Me.lb_gruppe1_opstart = New System.Windows.Forms.Label
        Me.tb_gruppe1_opstart_uk = New System.Windows.Forms.TextBox
        Me.rb_B_kombi = New System.Windows.Forms.RadioButton
        Me.lb_gruppe1_tid = New System.Windows.Forms.Label
        Me.rb_klip = New System.Windows.Forms.RadioButton
        Me.rb_D_stans = New System.Windows.Forms.RadioButton
        Me.tb_CNCmin_uk = New System.Windows.Forms.TextBox
        Me.gb_gruppe2 = New System.Windows.Forms.GroupBox
        Me.Label146 = New System.Windows.Forms.Label
        Me.gb_gevind = New System.Windows.Forms.GroupBox
        Me.Label22 = New System.Windows.Forms.Label
        Me.tb_m6 = New System.Windows.Forms.TextBox
        Me.Label180 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label179 = New System.Windows.Forms.Label
        Me.tb_m8 = New System.Windows.Forms.TextBox
        Me.Label24 = New System.Windows.Forms.Label
        Me.tb_m10 = New System.Windows.Forms.TextBox
        Me.Label28 = New System.Windows.Forms.Label
        Me.tb_m5 = New System.Windows.Forms.TextBox
        Me.Label139 = New System.Windows.Forms.Label
        Me.tb_m2_5 = New System.Windows.Forms.TextBox
        Me.Label141 = New System.Windows.Forms.Label
        Me.tb_m3 = New System.Windows.Forms.TextBox
        Me.Label142 = New System.Windows.Forms.Label
        Me.tb_m4 = New System.Windows.Forms.TextBox
        Me.Label143 = New System.Windows.Forms.Label
        Me.Label144 = New System.Windows.Forms.Label
        Me.Label145 = New System.Windows.Forms.Label
        Me.tb_m2 = New System.Windows.Forms.TextBox
        Me.lb_gevind_antal = New System.Windows.Forms.Label
        Me.Label151 = New System.Windows.Forms.Label
        Me.lb_gevind = New System.Windows.Forms.Label
        Me.tb_gevind_uk = New System.Windows.Forms.TextBox
        Me.gb_unders�nk = New System.Windows.Forms.GroupBox
        Me.Label183 = New System.Windows.Forms.Label
        Me.tb_2 = New System.Windows.Forms.TextBox
        Me.Label184 = New System.Windows.Forms.Label
        Me.tb_3 = New System.Windows.Forms.TextBox
        Me.Label185 = New System.Windows.Forms.Label
        Me.tb_4 = New System.Windows.Forms.TextBox
        Me.Label186 = New System.Windows.Forms.Label
        Me.Label187 = New System.Windows.Forms.Label
        Me.Label188 = New System.Windows.Forms.Label
        Me.tb_1 = New System.Windows.Forms.TextBox
        Me.Label182 = New System.Windows.Forms.Label
        Me.Label181 = New System.Windows.Forms.Label
        Me.lb_unders�nk_antal = New System.Windows.Forms.Label
        Me.Label148 = New System.Windows.Forms.Label
        Me.lb_countersink = New System.Windows.Forms.Label
        Me.tb_countersink_uk = New System.Windows.Forms.TextBox
        Me.cb_steelmaster = New System.Windows.Forms.CheckBox
        Me.cb_brush = New System.Windows.Forms.CheckBox
        Me.cb_vibrationsafgr = New System.Windows.Forms.CheckBox
        Me.cb_rette = New System.Windows.Forms.CheckBox
        Me.cb_afgrat = New System.Windows.Forms.CheckBox
        Me.Label41 = New System.Windows.Forms.Label
        Me.Label147 = New System.Windows.Forms.Label
        Me.tb_boltesvejs_antal = New System.Windows.Forms.TextBox
        Me.tb_presm�trik_antal = New System.Windows.Forms.TextBox
        Me.lb_grinding = New System.Windows.Forms.Label
        Me.lb_afgrat = New System.Windows.Forms.Label
        Me.lb_stans_manuel = New System.Windows.Forms.Label
        Me.lb_rette = New System.Windows.Forms.Label
        Me.lb_vibration = New System.Windows.Forms.Label
        Me.lb_brush = New System.Windows.Forms.Label
        Me.lb_boltesvejs = New System.Windows.Forms.Label
        Me.lb_pressnut = New System.Windows.Forms.Label
        Me.Label100 = New System.Windows.Forms.Label
        Me.tb_vibration_uk = New System.Windows.Forms.TextBox
        Me.tb_boltesvejs_uk = New System.Windows.Forms.TextBox
        Me.tb_afgrat_uk = New System.Windows.Forms.TextBox
        Me.Label106 = New System.Windows.Forms.Label
        Me.tb_pressnut_uk = New System.Windows.Forms.TextBox
        Me.tb_grinding_uk = New System.Windows.Forms.TextBox
        Me.Label105 = New System.Windows.Forms.Label
        Me.tb_brush_uk = New System.Windows.Forms.TextBox
        Me.Label104 = New System.Windows.Forms.Label
        Me.Label103 = New System.Windows.Forms.Label
        Me.Label101 = New System.Windows.Forms.Label
        Me.tb_stans_manuel_uk = New System.Windows.Forms.TextBox
        Me.tb_rette_uk = New System.Windows.Forms.TextBox
        Me.Label102 = New System.Windows.Forms.Label
        Me.gb_gruppe3 = New System.Windows.Forms.GroupBox
        Me.cb_spotweld = New System.Windows.Forms.CheckBox
        Me.Label34 = New System.Windows.Forms.Label
        Me.tb_numberofspotweldseams = New System.Windows.Forms.TextBox
        Me.Label203 = New System.Windows.Forms.Label
        Me.tb_numberofspots = New System.Windows.Forms.TextBox
        Me.Label202 = New System.Windows.Forms.Label
        Me.Label201 = New System.Windows.Forms.Label
        Me.Label128 = New System.Windows.Forms.Label
        Me.lb_spotweld = New System.Windows.Forms.Label
        Me.tb_spotweld_uk = New System.Windows.Forms.TextBox
        Me.gb_gruppe4 = New System.Windows.Forms.GroupBox
        Me.rb_migmag = New System.Windows.Forms.RadioButton
        Me.rb_tig = New System.Windows.Forms.RadioButton
        Me.cb_weld = New System.Windows.Forms.CheckBox
        Me.cb_grind_weld = New System.Windows.Forms.CheckBox
        Me.cb_tackweld = New System.Windows.Forms.CheckBox
        Me.Label194 = New System.Windows.Forms.Label
        Me.Label197 = New System.Windows.Forms.Label
        Me.Label200 = New System.Windows.Forms.Label
        Me.Label192 = New System.Windows.Forms.Label
        Me.Label189 = New System.Windows.Forms.Label
        Me.tb_numberofwelds = New System.Windows.Forms.TextBox
        Me.Label150 = New System.Windows.Forms.Label
        Me.tb_weldlength = New System.Windows.Forms.TextBox
        Me.Label132 = New System.Windows.Forms.Label
        Me.lb_grind_weld = New System.Windows.Forms.Label
        Me.lb_weld = New System.Windows.Forms.Label
        Me.lb_tackweld = New System.Windows.Forms.Label
        Me.tb_grind_weld_uk = New System.Windows.Forms.TextBox
        Me.tb_weld_uk = New System.Windows.Forms.TextBox
        Me.tb_tackweld_uk = New System.Windows.Forms.TextBox
        Me.GroupBox15 = New System.Windows.Forms.GroupBox
        Me.Label152 = New System.Windows.Forms.Label
        Me.Label153 = New System.Windows.Forms.Label
        Me.Label154 = New System.Windows.Forms.Label
        Me.Label155 = New System.Windows.Forms.Label
        Me.Label156 = New System.Windows.Forms.Label
        Me.Label157 = New System.Windows.Forms.Label
        Me.Label158 = New System.Windows.Forms.Label
        Me.Label159 = New System.Windows.Forms.Label
        Me.TextBox78 = New System.Windows.Forms.TextBox
        Me.TextBox79 = New System.Windows.Forms.TextBox
        Me.TextBox80 = New System.Windows.Forms.TextBox
        Me.TextBox81 = New System.Windows.Forms.TextBox
        Me.Label160 = New System.Windows.Forms.Label
        Me.Label161 = New System.Windows.Forms.Label
        Me.Label162 = New System.Windows.Forms.Label
        Me.Label163 = New System.Windows.Forms.Label
        Me.Label164 = New System.Windows.Forms.Label
        Me.Label165 = New System.Windows.Forms.Label
        Me.Label166 = New System.Windows.Forms.Label
        Me.Label167 = New System.Windows.Forms.Label
        Me.Label168 = New System.Windows.Forms.Label
        Me.Label169 = New System.Windows.Forms.Label
        Me.Label170 = New System.Windows.Forms.Label
        Me.TextBox82 = New System.Windows.Forms.TextBox
        Me.TextBox83 = New System.Windows.Forms.TextBox
        Me.TextBox84 = New System.Windows.Forms.TextBox
        Me.Label171 = New System.Windows.Forms.Label
        Me.TextBox85 = New System.Windows.Forms.TextBox
        Me.TextBox86 = New System.Windows.Forms.TextBox
        Me.Label172 = New System.Windows.Forms.Label
        Me.TextBox87 = New System.Windows.Forms.TextBox
        Me.TextBox88 = New System.Windows.Forms.TextBox
        Me.Label173 = New System.Windows.Forms.Label
        Me.TextBox89 = New System.Windows.Forms.TextBox
        Me.Label174 = New System.Windows.Forms.Label
        Me.Label175 = New System.Windows.Forms.Label
        Me.TextBox90 = New System.Windows.Forms.TextBox
        Me.TextBox91 = New System.Windows.Forms.TextBox
        Me.Label176 = New System.Windows.Forms.Label
        Me.gb_gruppe5 = New System.Windows.Forms.GroupBox
        Me.Label63 = New System.Windows.Forms.Label
        Me.Label137 = New System.Windows.Forms.Label
        Me.lb_kontrol = New System.Windows.Forms.Label
        Me.tb_kontrol_uk = New System.Windows.Forms.TextBox
        Me.Label133 = New System.Windows.Forms.Label
        Me.Label134 = New System.Windows.Forms.Label
        Me.lb_kontor = New System.Windows.Forms.Label
        Me.tb_kontor_uk = New System.Windows.Forms.TextBox
        Me.gb_admin = New System.Windows.Forms.GroupBox
        Me.tb_timesats_C = New System.Windows.Forms.TextBox
        Me.tb_timesats_B = New System.Windows.Forms.TextBox
        Me.Label58 = New System.Windows.Forms.Label
        Me.tb_timesats_D = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label43 = New System.Windows.Forms.Label
        Me.tb_timesats_mand = New System.Windows.Forms.TextBox
        Me.Label87 = New System.Windows.Forms.Label
        Me.Label40 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.lb_pos_ht = New System.Windows.Forms.Label
        Me.Label88 = New System.Windows.Forms.Label
        Me.lb_hovedtegning = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.gb_overfladebeh = New System.Windows.Forms.GroupBox
        Me.Label205 = New System.Windows.Forms.Label
        Me.cb_1side_2 = New System.Windows.Forms.CheckBox
        Me.cb_1side_3 = New System.Windows.Forms.CheckBox
        Me.cb_1side_1 = New System.Windows.Forms.CheckBox
        Me.Label42 = New System.Windows.Forms.Label
        Me.tb_overfl_pris2_uk = New System.Windows.Forms.TextBox
        Me.tb_overfl_pris3_uk = New System.Windows.Forms.TextBox
        Me.tb_overfl_pris1_uk = New System.Windows.Forms.TextBox
        Me.cb_overfl_beh4 = New System.Windows.Forms.ComboBox
        Me.cb_overfl_beh3 = New System.Windows.Forms.ComboBox
        Me.cb_overfl_beh2 = New System.Windows.Forms.ComboBox
        Me.cb_overfl_beh1 = New System.Windows.Forms.ComboBox
        Me.cb_overfl_leverand�r4 = New System.Windows.Forms.ComboBox
        Me.cb_overfl_leverand�r3 = New System.Windows.Forms.ComboBox
        Me.cb_overfl_leverand�r2 = New System.Windows.Forms.ComboBox
        Me.cb_overfl_leverand�r1 = New System.Windows.Forms.ComboBox
        Me.tb_overfl_pris100_4 = New System.Windows.Forms.Label
        Me.tb_overfl_avance4 = New System.Windows.Forms.TextBox
        Me.tb_overfl_pris4 = New System.Windows.Forms.TextBox
        Me.tb_overfl_afd�k4 = New System.Windows.Forms.TextBox
        Me.tb_overfl_opstart4 = New System.Windows.Forms.TextBox
        Me.tb_overfl_pris100_3 = New System.Windows.Forms.Label
        Me.tb_overfl_avance3 = New System.Windows.Forms.TextBox
        Me.tb_overfl_pris3 = New System.Windows.Forms.TextBox
        Me.tb_overfl_afd�k3 = New System.Windows.Forms.TextBox
        Me.tb_overfl_opstart3 = New System.Windows.Forms.TextBox
        Me.tb_overfl_pris100_2 = New System.Windows.Forms.Label
        Me.tb_overfl_avance2 = New System.Windows.Forms.TextBox
        Me.tb_overfl_pris2 = New System.Windows.Forms.TextBox
        Me.tb_overfl_afd�k2 = New System.Windows.Forms.TextBox
        Me.tb_overfl_opstart2 = New System.Windows.Forms.TextBox
        Me.Label140 = New System.Windows.Forms.Label
        Me.tb_overfl_pris100_1 = New System.Windows.Forms.Label
        Me.Label130 = New System.Windows.Forms.Label
        Me.tb_overfl_avance1 = New System.Windows.Forms.TextBox
        Me.Label67 = New System.Windows.Forms.Label
        Me.Label66 = New System.Windows.Forms.Label
        Me.Label65 = New System.Windows.Forms.Label
        Me.Label62 = New System.Windows.Forms.Label
        Me.Label61 = New System.Windows.Forms.Label
        Me.tb_overfl_pris1 = New System.Windows.Forms.TextBox
        Me.tb_overfl_afd�k1 = New System.Windows.Forms.TextBox
        Me.tb_overfl_opstart1 = New System.Windows.Forms.TextBox
        Me.gb_indk�b = New System.Windows.Forms.GroupBox
        Me.tb_bukmax_y = New System.Windows.Forms.TextBox
        Me.tb_bukmax_x = New System.Windows.Forms.TextBox
        Me.Label70 = New System.Windows.Forms.Label
        Me.gb_buk = New System.Windows.Forms.GroupBox
        Me.Label44 = New System.Windows.Forms.Label
        Me.Label204 = New System.Windows.Forms.Label
        Me.lb_nettoareal = New System.Windows.Forms.Label
        Me.tb_buk_opst_uk = New System.Windows.Forms.TextBox
        Me.Label30 = New System.Windows.Forms.Label
        Me.lb_buk_opst = New System.Windows.Forms.Label
        Me.Label96 = New System.Windows.Forms.Label
        Me.Label95 = New System.Windows.Forms.Label
        Me.Label94 = New System.Windows.Forms.Label
        Me.Label93 = New System.Windows.Forms.Label
        Me.lb_buk_tid = New System.Windows.Forms.Label
        Me.tb_buk_uk = New System.Windows.Forms.TextBox
        Me.lb_udfold_y = New System.Windows.Forms.Label
        Me.TextBox77 = New System.Windows.Forms.TextBox
        Me.lb_udfold_x = New System.Windows.Forms.Label
        Me.TextBox76 = New System.Windows.Forms.TextBox
        Me.Label84 = New System.Windows.Forms.Label
        Me.TextBox75 = New System.Windows.Forms.TextBox
        Me.Label83 = New System.Windows.Forms.Label
        Me.TextBox74 = New System.Windows.Forms.TextBox
        Me.tb_buk11_x = New System.Windows.Forms.TextBox
        Me.TextBox73 = New System.Windows.Forms.TextBox
        Me.tb_buk11_y = New System.Windows.Forms.TextBox
        Me.Label82 = New System.Windows.Forms.Label
        Me.tb_buk10_x = New System.Windows.Forms.TextBox
        Me.TextBox72 = New System.Windows.Forms.TextBox
        Me.tb_buk10_y = New System.Windows.Forms.TextBox
        Me.Label81 = New System.Windows.Forms.Label
        Me.tb_buk9_x = New System.Windows.Forms.TextBox
        Me.tb_buk9_y = New System.Windows.Forms.TextBox
        Me.Label80 = New System.Windows.Forms.Label
        Me.tb_buk8_x = New System.Windows.Forms.TextBox
        Me.tb_buk8_y = New System.Windows.Forms.TextBox
        Me.Label79 = New System.Windows.Forms.Label
        Me.tb_buk7_x = New System.Windows.Forms.TextBox
        Me.tb_buk7_y = New System.Windows.Forms.TextBox
        Me.Label77 = New System.Windows.Forms.Label
        Me.tb_buk6_x = New System.Windows.Forms.TextBox
        Me.tb_buk6_y = New System.Windows.Forms.TextBox
        Me.Label75 = New System.Windows.Forms.Label
        Me.tb_buk5_x = New System.Windows.Forms.TextBox
        Me.tb_buk5_y = New System.Windows.Forms.TextBox
        Me.Label74 = New System.Windows.Forms.Label
        Me.tb_buk4_x = New System.Windows.Forms.TextBox
        Me.tb_buk4_y = New System.Windows.Forms.TextBox
        Me.Label73 = New System.Windows.Forms.Label
        Me.tb_buk3_x = New System.Windows.Forms.TextBox
        Me.tb_buk3_y = New System.Windows.Forms.TextBox
        Me.Label72 = New System.Windows.Forms.Label
        Me.tb_buk2_x = New System.Windows.Forms.TextBox
        Me.tb_buk2_y = New System.Windows.Forms.TextBox
        Me.Label71 = New System.Windows.Forms.Label
        Me.tb_buk1_x = New System.Windows.Forms.TextBox
        Me.tb_buk1_y = New System.Windows.Forms.TextBox
        Me.TextBox67 = New System.Windows.Forms.TextBox
        Me.TextBox68 = New System.Windows.Forms.TextBox
        Me.TextBox69 = New System.Windows.Forms.TextBox
        Me.TextBox70 = New System.Windows.Forms.TextBox
        Me.TextBox71 = New System.Windows.Forms.TextBox
        Me.cb_Tegning = New System.Windows.Forms.ComboBox
        Me.gb_hul = New System.Windows.Forms.GroupBox
        Me.Label90 = New System.Windows.Forms.Label
        Me.Label107 = New System.Windows.Forms.Label
        Me.Label108 = New System.Windows.Forms.Label
        Me.Label86 = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.tb_toolshift = New System.Windows.Forms.TextBox
        Me.Label99 = New System.Windows.Forms.Label
        Me.tb_slag_til_huller = New System.Windows.Forms.TextBox
        Me.tb_opstart_kr_uk = New System.Windows.Forms.TextBox
        Me.tb_Program_kr_uk = New System.Windows.Forms.TextBox
        Me.Label91 = New System.Windows.Forms.Label
        Me.gb_pristabel = New System.Windows.Forms.GroupBox
        Me.lb_r�varerstk5 = New System.Windows.Forms.Label
        Me.lb_r�varerstk4 = New System.Windows.Forms.Label
        Me.lb_r�varerstk3 = New System.Windows.Forms.Label
        Me.lb_r�varerstk2 = New System.Windows.Forms.Label
        Me.lb_r�varer1 = New System.Windows.Forms.Label
        Me.lb_mand5_tid = New System.Windows.Forms.Label
        Me.lb_CNC5_tid = New System.Windows.Forms.Label
        Me.lb_mand4_tid = New System.Windows.Forms.Label
        Me.lb_CNC4_tid = New System.Windows.Forms.Label
        Me.lb_mand3_tid = New System.Windows.Forms.Label
        Me.lb_CNC3_tid = New System.Windows.Forms.Label
        Me.lb_CNC2_tid = New System.Windows.Forms.Label
        Me.lb_mand2_tid = New System.Windows.Forms.Label
        Me.lb_CNC1_tid = New System.Windows.Forms.Label
        Me.lb_mand1_tid = New System.Windows.Forms.Label
        Me.Label118 = New System.Windows.Forms.Label
        Me.Label117 = New System.Windows.Forms.Label
        Me.Label116 = New System.Windows.Forms.Label
        Me.Label115 = New System.Windows.Forms.Label
        Me.lb_timer2 = New System.Windows.Forms.Label
        Me.lb_timer3 = New System.Windows.Forms.Label
        Me.lb_timer4 = New System.Windows.Forms.Label
        Me.lb_timer1 = New System.Windows.Forms.Label
        Me.Label122 = New System.Windows.Forms.Label
        Me.Label121 = New System.Windows.Forms.Label
        Me.Label120 = New System.Windows.Forms.Label
        Me.Label119 = New System.Windows.Forms.Label
        Me.gb_opstart = New System.Windows.Forms.GroupBox
        Me.tb_antal_program_uk = New System.Windows.Forms.TextBox
        Me.tb_antal_opstart_uk = New System.Windows.Forms.TextBox
        Me.Label126 = New System.Windows.Forms.Label
        Me.lb_opstart_kr = New System.Windows.Forms.Label
        Me.lb_antal_program = New System.Windows.Forms.Label
        Me.gb_matr = New System.Windows.Forms.GroupBox
        Me.Label149 = New System.Windows.Forms.Label
        Me.tb_sv�rhed_uk = New System.Windows.Forms.TextBox
        Me.lb_faktor = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.lb_sv�rhed = New System.Windows.Forms.Label
        Me.cb_frav�lg = New System.Windows.Forms.CheckBox
        Me.lb_spildnetto = New System.Windows.Forms.Label
        Me.Lb_Kilopris = New System.Windows.Forms.Label
        Me.Label92 = New System.Windows.Forms.Label
        Me.Lb_matrgruppe = New System.Windows.Forms.Label
        Me.Lb_klasse = New System.Windows.Forms.Label
        Me.Label89 = New System.Windows.Forms.Label
        Me.lb_emnev�gt = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.lb_modulstr = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.lb_spildtype = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.lb_pladeformatY = New System.Windows.Forms.Label
        Me.lb_spild = New System.Windows.Forms.Label
        Me.lb_emner_prplade = New System.Windows.Forms.Label
        Me.lb_pladeformatX = New System.Windows.Forms.Label
        Me.lb_antalplader = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.bu_udskriv = New System.Windows.Forms.Button
        Me.MetalTilbudDataSet1 = New Metaltilbud1.MetalTilbudDataSet
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label123 = New System.Windows.Forms.Label
        Me.Label131 = New System.Windows.Forms.Label
        Me.tb_slag_til_huller_B = New System.Windows.Forms.TextBox
        Me.Label135 = New System.Windows.Forms.Label
        Me.tb_toolshift_B = New System.Windows.Forms.TextBox
        Me.Label136 = New System.Windows.Forms.Label
        Me.tb_combiCNC_tid_uk = New System.Windows.Forms.TextBox
        Me.Label109 = New System.Windows.Forms.Label
        Me.lb_Combi_opstart = New System.Windows.Forms.Label
        Me.tb_hulantal_3B = New System.Windows.Forms.TextBox
        Me.Label111 = New System.Windows.Forms.Label
        Me.Label112 = New System.Windows.Forms.Label
        Me.Label113 = New System.Windows.Forms.Label
        Me.tb_hulantal_2B = New System.Windows.Forms.TextBox
        Me.Label114 = New System.Windows.Forms.Label
        Me.lb_CombiCNC_tid = New System.Windows.Forms.Label
        Me.tb_cuttinglength_B = New System.Windows.Forms.TextBox
        Me.tb_combi_opstart_uk = New System.Windows.Forms.TextBox
        Me.Label125 = New System.Windows.Forms.Label
        Me.tb_hulantal_1B = New System.Windows.Forms.TextBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.tb_klip_tid_uk = New System.Windows.Forms.TextBox
        Me.lb_klip_opstart = New System.Windows.Forms.Label
        Me.Label127 = New System.Windows.Forms.Label
        Me.Label129 = New System.Windows.Forms.Label
        Me.lb_klip_tid = New System.Windows.Forms.Label
        Me.tb_klip_opstart_uk = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label110 = New System.Windows.Forms.Label
        Me.Label124 = New System.Windows.Forms.Label
        Me.Label138 = New System.Windows.Forms.Label
        Me.lb_r�kkeantal = New System.Windows.Forms.Label
        Me.gb_forbrug = New System.Windows.Forms.GroupBox
        Me.Label199 = New System.Windows.Forms.Label
        Me.tb_svejsestag_kr_uk = New System.Windows.Forms.TextBox
        Me.tb_tilsatsmatr_kr_uk = New System.Windows.Forms.TextBox
        Me.tb_pressnut_kr_uk = New System.Windows.Forms.TextBox
        Me.Label196 = New System.Windows.Forms.Label
        Me.lb_tilsatsmatr_kr = New System.Windows.Forms.Label
        Me.Label198 = New System.Windows.Forms.Label
        Me.Label193 = New System.Windows.Forms.Label
        Me.lb_svejsestag_kr = New System.Windows.Forms.Label
        Me.Label195 = New System.Windows.Forms.Label
        Me.Label191 = New System.Windows.Forms.Label
        Me.lb_pressnut_kr = New System.Windows.Forms.Label
        Me.Label190 = New System.Windows.Forms.Label
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.tb_Kilopris_uk = New System.Windows.Forms.TextBox
        Me.Label177 = New System.Windows.Forms.Label
        Me.Label178 = New System.Windows.Forms.Label
        Me.gb_gruppe1.SuspendLayout()
        Me.gb_gruppe2.SuspendLayout()
        Me.gb_gevind.SuspendLayout()
        Me.gb_unders�nk.SuspendLayout()
        Me.gb_gruppe3.SuspendLayout()
        Me.gb_gruppe4.SuspendLayout()
        Me.GroupBox15.SuspendLayout()
        Me.gb_gruppe5.SuspendLayout()
        Me.gb_admin.SuspendLayout()
        Me.gb_overfladebeh.SuspendLayout()
        Me.gb_buk.SuspendLayout()
        Me.gb_hul.SuspendLayout()
        Me.gb_pristabel.SuspendLayout()
        Me.gb_opstart.SuspendLayout()
        Me.gb_matr.SuspendLayout()
        CType(Me.MetalTilbudDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.gb_forbrug.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Location = New System.Drawing.Point(995, 457)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(97, 13)
        Me.Label78.TabIndex = 218
        Me.Label78.Text = "BEM�RKNINGER"
        '
        'rtb_bem
        '
        Me.rtb_bem.Location = New System.Drawing.Point(992, 472)
        Me.rtb_bem.Name = "rtb_bem"
        Me.rtb_bem.Size = New System.Drawing.Size(272, 448)
        Me.rtb_bem.TabIndex = 362
        Me.rtb_bem.Text = ""
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Location = New System.Drawing.Point(140, 8)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(59, 13)
        Me.Label76.TabIndex = 214
        Me.Label76.Text = "Ordre str. 1"
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.Location = New System.Drawing.Point(18, 35)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(48, 13)
        Me.Label68.TabIndex = 207
        Me.Label68.Text = "Operat�r"
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Location = New System.Drawing.Point(19, 16)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(30, 13)
        Me.Label69.TabIndex = 206
        Me.Label69.Text = "Dato"
        '
        'lb_operat�r
        '
        Me.lb_operat�r.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_operat�r.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_operat�r.Location = New System.Drawing.Point(72, 33)
        Me.lb_operat�r.Name = "lb_operat�r"
        Me.lb_operat�r.Size = New System.Drawing.Size(131, 20)
        Me.lb_operat�r.TabIndex = 205
        '
        'lb_dato
        '
        Me.lb_dato.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_dato.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_dato.Location = New System.Drawing.Point(72, 13)
        Me.lb_dato.Name = "lb_dato"
        Me.lb_dato.Size = New System.Drawing.Size(131, 20)
        Me.lb_dato.TabIndex = 204
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(1, 135)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(78, 13)
        Me.Label56.TabIndex = 203
        Me.Label56.Text = "Programmer kr."
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(782, 158)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(89, 13)
        Me.Label57.TabIndex = 202
        Me.Label57.Text = "Programmer antal"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(41, 215)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(98, 13)
        Me.Label39.TabIndex = 201
        Me.Label39.Text = "Afgivet tilbud      kr."
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(13, 192)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(126, 13)
        Me.Label50.TabIndex = 200
        Me.Label50.Text = "Salgspris Opst.+Prog.  kr."
        '
        'tb_opstart_afgivettilbud
        '
        Me.tb_opstart_afgivettilbud.ForeColor = System.Drawing.Color.DarkRed
        Me.tb_opstart_afgivettilbud.Location = New System.Drawing.Point(141, 212)
        Me.tb_opstart_afgivettilbud.Name = "tb_opstart_afgivettilbud"
        Me.tb_opstart_afgivettilbud.Size = New System.Drawing.Size(53, 20)
        Me.tb_opstart_afgivettilbud.TabIndex = 92
        Me.tb_opstart_afgivettilbud.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(124, 179)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(15, 13)
        Me.Label51.TabIndex = 199
        Me.Label51.Text = "%"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(38, 177)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(47, 13)
        Me.Label54.TabIndex = 197
        Me.Label54.Text = "Avance "
        '
        'tb_opstart_avance
        '
        Me.tb_opstart_avance.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_opstart_avance.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_opstart_avance.Location = New System.Drawing.Point(91, 174)
        Me.tb_opstart_avance.Name = "tb_opstart_avance"
        Me.tb_opstart_avance.Size = New System.Drawing.Size(35, 20)
        Me.tb_opstart_avance.TabIndex = 136
        Me.tb_opstart_avance.Text = "20"
        Me.tb_opstart_avance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(3, 158)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(136, 13)
        Me.Label55.TabIndex = 196
        Me.Label55.Text = "Opstart+programmer ialt  kr."
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(24, 74)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(56, 13)
        Me.Label59.TabIndex = 195
        Me.Label59.Text = "Opstart kr."
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(2, 55)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(80, 13)
        Me.Label60.TabIndex = 194
        Me.Label60.Text = "Opstart 1. gang"
        '
        'lb_opst_prog_brutto
        '
        Me.lb_opst_prog_brutto.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_opst_prog_brutto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_opst_prog_brutto.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lb_opst_prog_brutto.ForeColor = System.Drawing.Color.Blue
        Me.lb_opst_prog_brutto.Location = New System.Drawing.Point(141, 187)
        Me.lb_opst_prog_brutto.Name = "lb_opst_prog_brutto"
        Me.lb_opst_prog_brutto.Size = New System.Drawing.Size(53, 20)
        Me.lb_opst_prog_brutto.TabIndex = 193
        Me.lb_opst_prog_brutto.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_opstart_program
        '
        Me.lb_opstart_program.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_opstart_program.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_opstart_program.Location = New System.Drawing.Point(141, 156)
        Me.lb_opstart_program.Name = "lb_opstart_program"
        Me.lb_opstart_program.Size = New System.Drawing.Size(53, 20)
        Me.lb_opstart_program.TabIndex = 192
        Me.lb_opstart_program.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_program_kr
        '
        Me.lb_program_kr.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_program_kr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_program_kr.Location = New System.Drawing.Point(82, 134)
        Me.lb_program_kr.Name = "lb_program_kr"
        Me.lb_program_kr.Size = New System.Drawing.Size(53, 20)
        Me.lb_program_kr.TabIndex = 189
        Me.lb_program_kr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_antal_opstart
        '
        Me.lb_antal_opstart.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_antal_opstart.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_antal_opstart.Location = New System.Drawing.Point(82, 53)
        Me.lb_antal_opstart.Name = "lb_antal_opstart"
        Me.lb_antal_opstart.Size = New System.Drawing.Size(53, 20)
        Me.lb_antal_opstart.TabIndex = 188
        Me.lb_antal_opstart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(8, 215)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(98, 13)
        Me.Label38.TabIndex = 187
        Me.Label38.Text = "Afgivet tilbud      kr."
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(2, 192)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(105, 13)
        Me.Label37.TabIndex = 186
        Me.Label37.Text = "Salgspris  stk/ialt  kr."
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tb_tilbud2
        '
        Me.tb_tilbud2.BackColor = System.Drawing.Color.White
        Me.tb_tilbud2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_tilbud2.ForeColor = System.Drawing.Color.DarkRed
        Me.tb_tilbud2.Location = New System.Drawing.Point(241, 210)
        Me.tb_tilbud2.Name = "tb_tilbud2"
        Me.tb_tilbud2.Size = New System.Drawing.Size(126, 20)
        Me.tb_tilbud2.TabIndex = 88
        Me.tb_tilbud2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_tilbud3
        '
        Me.tb_tilbud3.BackColor = System.Drawing.Color.White
        Me.tb_tilbud3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_tilbud3.ForeColor = System.Drawing.Color.DarkRed
        Me.tb_tilbud3.Location = New System.Drawing.Point(373, 210)
        Me.tb_tilbud3.Name = "tb_tilbud3"
        Me.tb_tilbud3.Size = New System.Drawing.Size(126, 20)
        Me.tb_tilbud3.TabIndex = 89
        Me.tb_tilbud3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_tilbud4
        '
        Me.tb_tilbud4.BackColor = System.Drawing.Color.White
        Me.tb_tilbud4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_tilbud4.ForeColor = System.Drawing.Color.DarkRed
        Me.tb_tilbud4.Location = New System.Drawing.Point(505, 210)
        Me.tb_tilbud4.Name = "tb_tilbud4"
        Me.tb_tilbud4.Size = New System.Drawing.Size(126, 20)
        Me.tb_tilbud4.TabIndex = 90
        Me.tb_tilbud4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_tilbud5
        '
        Me.tb_tilbud5.BackColor = System.Drawing.Color.White
        Me.tb_tilbud5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_tilbud5.ForeColor = System.Drawing.Color.DarkRed
        Me.tb_tilbud5.Location = New System.Drawing.Point(637, 210)
        Me.tb_tilbud5.Name = "tb_tilbud5"
        Me.tb_tilbud5.Size = New System.Drawing.Size(126, 20)
        Me.tb_tilbud5.TabIndex = 91
        Me.tb_tilbud5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_tilbud1
        '
        Me.tb_tilbud1.BackColor = System.Drawing.Color.White
        Me.tb_tilbud1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_tilbud1.ForeColor = System.Drawing.Color.DarkRed
        Me.tb_tilbud1.Location = New System.Drawing.Point(109, 210)
        Me.tb_tilbud1.Name = "tb_tilbud1"
        Me.tb_tilbud1.Size = New System.Drawing.Size(126, 20)
        Me.tb_tilbud1.TabIndex = 87
        Me.tb_tilbud1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(88, 173)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(15, 13)
        Me.Label36.TabIndex = 185
        Me.Label36.Text = "%"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(2, 173)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(47, 13)
        Me.Label35.TabIndex = 184
        Me.Label35.Text = "Avance "
        '
        'tb_avance
        '
        Me.tb_avance.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_avance.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_avance.Location = New System.Drawing.Point(55, 170)
        Me.tb_avance.Name = "tb_avance"
        Me.tb_avance.Size = New System.Drawing.Size(35, 20)
        Me.tb_avance.TabIndex = 135
        Me.tb_avance.Text = "20"
        Me.tb_avance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(2, 154)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(107, 13)
        Me.Label49.TabIndex = 183
        Me.Label49.Text = "Samlet  stk/ialt      kr."
        Me.Label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(3, 134)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(104, 13)
        Me.Label48.TabIndex = 182
        Me.Label48.Text = "R�varer stk/ialt    kr."
        Me.Label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(29, 114)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(79, 13)
        Me.Label47.TabIndex = 181
        Me.Label47.Text = "Indk�b         kr."
        Me.Label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(29, 94)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(79, 13)
        Me.Label53.TabIndex = 180
        Me.Label53.Text = "Timer ialt      kr."
        Me.Label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(2, 73)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(103, 13)
        Me.Label52.TabIndex = 179
        Me.Label52.Text = "CNC timer   kr. -timer"
        Me.Label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(2, 54)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(105, 13)
        Me.Label46.TabIndex = 178
        Me.Label46.Text = "Mand timer   kr.-timer"
        Me.Label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(70, 27)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(30, 13)
        Me.Label45.TabIndex = 177
        Me.Label45.Text = "antal"
        '
        'lb_salg2
        '
        Me.lb_salg2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_salg2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_salg2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lb_salg2.ForeColor = System.Drawing.Color.Blue
        Me.lb_salg2.Location = New System.Drawing.Point(240, 185)
        Me.lb_salg2.Name = "lb_salg2"
        Me.lb_salg2.Size = New System.Drawing.Size(126, 20)
        Me.lb_salg2.TabIndex = 176
        Me.lb_salg2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_salg3
        '
        Me.lb_salg3.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_salg3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_salg3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lb_salg3.ForeColor = System.Drawing.Color.Blue
        Me.lb_salg3.Location = New System.Drawing.Point(372, 185)
        Me.lb_salg3.Name = "lb_salg3"
        Me.lb_salg3.Size = New System.Drawing.Size(126, 20)
        Me.lb_salg3.TabIndex = 175
        Me.lb_salg3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_salg4
        '
        Me.lb_salg4.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_salg4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_salg4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lb_salg4.ForeColor = System.Drawing.Color.Blue
        Me.lb_salg4.Location = New System.Drawing.Point(504, 185)
        Me.lb_salg4.Name = "lb_salg4"
        Me.lb_salg4.Size = New System.Drawing.Size(126, 20)
        Me.lb_salg4.TabIndex = 174
        Me.lb_salg4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_salg5
        '
        Me.lb_salg5.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_salg5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_salg5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lb_salg5.ForeColor = System.Drawing.Color.Blue
        Me.lb_salg5.Location = New System.Drawing.Point(636, 185)
        Me.lb_salg5.Name = "lb_salg5"
        Me.lb_salg5.Size = New System.Drawing.Size(126, 20)
        Me.lb_salg5.TabIndex = 173
        Me.lb_salg5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_salg1
        '
        Me.lb_salg1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_salg1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_salg1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lb_salg1.ForeColor = System.Drawing.Color.Blue
        Me.lb_salg1.Location = New System.Drawing.Point(109, 185)
        Me.lb_salg1.Name = "lb_salg1"
        Me.lb_salg1.Size = New System.Drawing.Size(126, 20)
        Me.lb_salg1.TabIndex = 172
        Me.lb_salg1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_samlet2
        '
        Me.lb_samlet2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_samlet2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_samlet2.Location = New System.Drawing.Point(240, 154)
        Me.lb_samlet2.Name = "lb_samlet2"
        Me.lb_samlet2.Size = New System.Drawing.Size(126, 20)
        Me.lb_samlet2.TabIndex = 171
        Me.lb_samlet2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_samlet3
        '
        Me.lb_samlet3.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_samlet3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_samlet3.Location = New System.Drawing.Point(372, 154)
        Me.lb_samlet3.Name = "lb_samlet3"
        Me.lb_samlet3.Size = New System.Drawing.Size(126, 20)
        Me.lb_samlet3.TabIndex = 170
        Me.lb_samlet3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_samlet4
        '
        Me.lb_samlet4.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_samlet4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_samlet4.Location = New System.Drawing.Point(504, 154)
        Me.lb_samlet4.Name = "lb_samlet4"
        Me.lb_samlet4.Size = New System.Drawing.Size(126, 20)
        Me.lb_samlet4.TabIndex = 169
        Me.lb_samlet4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_samlet5
        '
        Me.lb_samlet5.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_samlet5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_samlet5.Location = New System.Drawing.Point(636, 154)
        Me.lb_samlet5.Name = "lb_samlet5"
        Me.lb_samlet5.Size = New System.Drawing.Size(126, 20)
        Me.lb_samlet5.TabIndex = 168
        Me.lb_samlet5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_samlet1
        '
        Me.lb_samlet1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_samlet1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_samlet1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lb_samlet1.Location = New System.Drawing.Point(109, 154)
        Me.lb_samlet1.Name = "lb_samlet1"
        Me.lb_samlet1.Size = New System.Drawing.Size(126, 20)
        Me.lb_samlet1.TabIndex = 167
        Me.lb_samlet1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_cnc2
        '
        Me.lb_cnc2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_cnc2.Location = New System.Drawing.Point(240, 73)
        Me.lb_cnc2.Name = "lb_cnc2"
        Me.lb_cnc2.Size = New System.Drawing.Size(76, 20)
        Me.lb_cnc2.TabIndex = 166
        Me.lb_cnc2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_cnc3
        '
        Me.lb_cnc3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_cnc3.Location = New System.Drawing.Point(372, 73)
        Me.lb_cnc3.Name = "lb_cnc3"
        Me.lb_cnc3.Size = New System.Drawing.Size(76, 20)
        Me.lb_cnc3.TabIndex = 165
        Me.lb_cnc3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_cnc4
        '
        Me.lb_cnc4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_cnc4.Location = New System.Drawing.Point(504, 73)
        Me.lb_cnc4.Name = "lb_cnc4"
        Me.lb_cnc4.Size = New System.Drawing.Size(76, 20)
        Me.lb_cnc4.TabIndex = 164
        Me.lb_cnc4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_cnc5
        '
        Me.lb_cnc5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_cnc5.Location = New System.Drawing.Point(636, 73)
        Me.lb_cnc5.Name = "lb_cnc5"
        Me.lb_cnc5.Size = New System.Drawing.Size(76, 20)
        Me.lb_cnc5.TabIndex = 163
        Me.lb_cnc5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_cnc1
        '
        Me.lb_cnc1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_cnc1.Location = New System.Drawing.Point(109, 73)
        Me.lb_cnc1.Name = "lb_cnc1"
        Me.lb_cnc1.Size = New System.Drawing.Size(76, 20)
        Me.lb_cnc1.TabIndex = 162
        Me.lb_cnc1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label25
        '
        Me.Label25.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label25.Location = New System.Drawing.Point(240, 93)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(126, 20)
        Me.Label25.TabIndex = 161
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label26
        '
        Me.Label26.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label26.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label26.Location = New System.Drawing.Point(372, 93)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(126, 20)
        Me.Label26.TabIndex = 160
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label27
        '
        Me.Label27.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label27.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label27.Location = New System.Drawing.Point(504, 93)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(126, 20)
        Me.Label27.TabIndex = 159
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_timer5
        '
        Me.lb_timer5.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_timer5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_timer5.Location = New System.Drawing.Point(636, 94)
        Me.lb_timer5.Name = "lb_timer5"
        Me.lb_timer5.Size = New System.Drawing.Size(126, 20)
        Me.lb_timer5.TabIndex = 158
        Me.lb_timer5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label29
        '
        Me.Label29.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label29.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label29.Location = New System.Drawing.Point(109, 93)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(126, 20)
        Me.Label29.TabIndex = 157
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_indk�b2
        '
        Me.lb_indk�b2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_indk�b2.Location = New System.Drawing.Point(240, 114)
        Me.lb_indk�b2.Name = "lb_indk�b2"
        Me.lb_indk�b2.Size = New System.Drawing.Size(126, 20)
        Me.lb_indk�b2.TabIndex = 156
        Me.lb_indk�b2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_indk�b3
        '
        Me.lb_indk�b3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_indk�b3.Location = New System.Drawing.Point(372, 114)
        Me.lb_indk�b3.Name = "lb_indk�b3"
        Me.lb_indk�b3.Size = New System.Drawing.Size(126, 20)
        Me.lb_indk�b3.TabIndex = 155
        Me.lb_indk�b3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_indk�b4
        '
        Me.lb_indk�b4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_indk�b4.Location = New System.Drawing.Point(504, 114)
        Me.lb_indk�b4.Name = "lb_indk�b4"
        Me.lb_indk�b4.Size = New System.Drawing.Size(126, 20)
        Me.lb_indk�b4.TabIndex = 154
        Me.lb_indk�b4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_indk�b5
        '
        Me.lb_indk�b5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_indk�b5.Location = New System.Drawing.Point(636, 114)
        Me.lb_indk�b5.Name = "lb_indk�b5"
        Me.lb_indk�b5.Size = New System.Drawing.Size(126, 20)
        Me.lb_indk�b5.TabIndex = 153
        Me.lb_indk�b5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_indk�b1
        '
        Me.lb_indk�b1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_indk�b1.Location = New System.Drawing.Point(109, 114)
        Me.lb_indk�b1.Name = "lb_indk�b1"
        Me.lb_indk�b1.Size = New System.Drawing.Size(126, 20)
        Me.lb_indk�b1.TabIndex = 152
        Me.lb_indk�b1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_r�varer2
        '
        Me.lb_r�varer2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_r�varer2.Location = New System.Drawing.Point(303, 134)
        Me.lb_r�varer2.Name = "lb_r�varer2"
        Me.lb_r�varer2.Size = New System.Drawing.Size(63, 20)
        Me.lb_r�varer2.TabIndex = 151
        Me.lb_r�varer2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_r�varer3
        '
        Me.lb_r�varer3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_r�varer3.Location = New System.Drawing.Point(435, 134)
        Me.lb_r�varer3.Name = "lb_r�varer3"
        Me.lb_r�varer3.Size = New System.Drawing.Size(63, 20)
        Me.lb_r�varer3.TabIndex = 150
        Me.lb_r�varer3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_r�varer4
        '
        Me.lb_r�varer4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_r�varer4.Location = New System.Drawing.Point(567, 134)
        Me.lb_r�varer4.Name = "lb_r�varer4"
        Me.lb_r�varer4.Size = New System.Drawing.Size(63, 20)
        Me.lb_r�varer4.TabIndex = 149
        Me.lb_r�varer4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_r�varer5
        '
        Me.lb_r�varer5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_r�varer5.Location = New System.Drawing.Point(699, 134)
        Me.lb_r�varer5.Name = "lb_r�varer5"
        Me.lb_r�varer5.Size = New System.Drawing.Size(63, 20)
        Me.lb_r�varer5.TabIndex = 148
        Me.lb_r�varer5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_r�varerstk1
        '
        Me.lb_r�varerstk1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_r�varerstk1.Location = New System.Drawing.Point(109, 134)
        Me.lb_r�varerstk1.Name = "lb_r�varerstk1"
        Me.lb_r�varerstk1.Size = New System.Drawing.Size(63, 20)
        Me.lb_r�varerstk1.TabIndex = 147
        Me.lb_r�varerstk1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_mand2
        '
        Me.lb_mand2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_mand2.Location = New System.Drawing.Point(240, 53)
        Me.lb_mand2.Name = "lb_mand2"
        Me.lb_mand2.Size = New System.Drawing.Size(76, 20)
        Me.lb_mand2.TabIndex = 146
        Me.lb_mand2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_mand3
        '
        Me.lb_mand3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_mand3.Location = New System.Drawing.Point(372, 53)
        Me.lb_mand3.Name = "lb_mand3"
        Me.lb_mand3.Size = New System.Drawing.Size(76, 20)
        Me.lb_mand3.TabIndex = 143
        Me.lb_mand3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_mand4
        '
        Me.lb_mand4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_mand4.Location = New System.Drawing.Point(504, 53)
        Me.lb_mand4.Name = "lb_mand4"
        Me.lb_mand4.Size = New System.Drawing.Size(76, 20)
        Me.lb_mand4.TabIndex = 142
        Me.lb_mand4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_mand5
        '
        Me.lb_mand5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_mand5.Location = New System.Drawing.Point(636, 53)
        Me.lb_mand5.Name = "lb_mand5"
        Me.lb_mand5.Size = New System.Drawing.Size(76, 20)
        Me.lb_mand5.TabIndex = 140
        Me.lb_mand5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_mand1
        '
        Me.lb_mand1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_mand1.Location = New System.Drawing.Point(109, 53)
        Me.lb_mand1.Name = "lb_mand1"
        Me.lb_mand1.Size = New System.Drawing.Size(76, 20)
        Me.lb_mand1.TabIndex = 198
        Me.lb_mand1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tb_antal2
        '
        Me.tb_antal2.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_antal2.Location = New System.Drawing.Point(240, 24)
        Me.tb_antal2.Name = "tb_antal2"
        Me.tb_antal2.Size = New System.Drawing.Size(126, 20)
        Me.tb_antal2.TabIndex = 83
        Me.tb_antal2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_antal3
        '
        Me.tb_antal3.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_antal3.Location = New System.Drawing.Point(372, 24)
        Me.tb_antal3.Name = "tb_antal3"
        Me.tb_antal3.Size = New System.Drawing.Size(126, 20)
        Me.tb_antal3.TabIndex = 84
        Me.tb_antal3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_antal4
        '
        Me.tb_antal4.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_antal4.Location = New System.Drawing.Point(504, 24)
        Me.tb_antal4.Name = "tb_antal4"
        Me.tb_antal4.Size = New System.Drawing.Size(126, 20)
        Me.tb_antal4.TabIndex = 85
        Me.tb_antal4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_antal5
        '
        Me.tb_antal5.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_antal5.Location = New System.Drawing.Point(636, 24)
        Me.tb_antal5.Name = "tb_antal5"
        Me.tb_antal5.Size = New System.Drawing.Size(126, 20)
        Me.tb_antal5.TabIndex = 86
        Me.tb_antal5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_antal1
        '
        Me.tb_antal1.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_antal1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_antal1.Location = New System.Drawing.Point(108, 24)
        Me.tb_antal1.Name = "tb_antal1"
        Me.tb_antal1.ReadOnly = True
        Me.tb_antal1.Size = New System.Drawing.Size(126, 20)
        Me.tb_antal1.TabIndex = 82
        Me.tb_antal1.Text = "100"
        Me.tb_antal1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(1149, 10)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(32, 13)
        Me.Label4.TabIndex = 132
        Me.Label4.Text = "REV." & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'tb_revision
        '
        Me.tb_revision.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_revision.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_revision.Location = New System.Drawing.Point(1187, 2)
        Me.tb_revision.Name = "tb_revision"
        Me.tb_revision.Size = New System.Drawing.Size(77, 24)
        Me.tb_revision.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(802, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 26)
        Me.Label3.TabIndex = 129
        Me.Label3.Text = "TEGN.NR" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(344, 10)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(81, 26)
        Me.Label2.TabIndex = 127
        Me.Label2.Text = "BEN�VNELSE" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'tb_emne
        '
        Me.tb_emne.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_emne.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_emne.Location = New System.Drawing.Point(428, 2)
        Me.tb_emne.Name = "tb_emne"
        Me.tb_emne.Size = New System.Drawing.Size(370, 24)
        Me.tb_emne.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 13)
        Me.Label1.TabIndex = 124
        Me.Label1.Text = "KUNDE"
        '
        'cb_kunde
        '
        Me.cb_kunde.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_kunde.Font = New System.Drawing.Font("SansSerif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cb_kunde.IntegralHeight = False
        Me.cb_kunde.ItemHeight = 17
        Me.cb_kunde.Location = New System.Drawing.Point(54, 2)
        Me.cb_kunde.Name = "cb_kunde"
        Me.cb_kunde.Size = New System.Drawing.Size(284, 25)
        Me.cb_kunde.Sorted = True
        Me.cb_kunde.TabIndex = 1
        '
        'bu_Reset
        '
        Me.bu_Reset.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.bu_Reset.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bu_Reset.Location = New System.Drawing.Point(992, 928)
        Me.bu_Reset.Name = "bu_Reset"
        Me.bu_Reset.Size = New System.Drawing.Size(62, 54)
        Me.bu_Reset.TabIndex = 219
        Me.bu_Reset.Text = "RESET"
        Me.bu_Reset.UseVisualStyleBackColor = False
        '
        'rb_netto
        '
        Me.rb_netto.AutoSize = True
        Me.rb_netto.Checked = True
        Me.rb_netto.Location = New System.Drawing.Point(14, 284)
        Me.rb_netto.Name = "rb_netto"
        Me.rb_netto.Size = New System.Drawing.Size(100, 17)
        Me.rb_netto.TabIndex = 250
        Me.rb_netto.TabStop = True
        Me.rb_netto.Text = "R�vare NETTO"
        Me.rb_netto.UseVisualStyleBackColor = True
        '
        'rb_brutto
        '
        Me.rb_brutto.AutoSize = True
        Me.rb_brutto.Location = New System.Drawing.Point(133, 284)
        Me.rb_brutto.Name = "rb_brutto"
        Me.rb_brutto.Size = New System.Drawing.Size(108, 17)
        Me.rb_brutto.TabIndex = 249
        Me.rb_brutto.Text = "R�vare BRUTTO"
        Me.rb_brutto.UseVisualStyleBackColor = True
        '
        'lb_tykkelse
        '
        Me.lb_tykkelse.AutoSize = True
        Me.lb_tykkelse.Location = New System.Drawing.Point(7, 53)
        Me.lb_tykkelse.Name = "lb_tykkelse"
        Me.lb_tykkelse.Size = New System.Drawing.Size(57, 13)
        Me.lb_tykkelse.TabIndex = 302
        Me.lb_tykkelse.Text = "pl.tykkelse"
        '
        'tb_pladetykkelse
        '
        Me.tb_pladetykkelse.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_pladetykkelse.Location = New System.Drawing.Point(95, 50)
        Me.tb_pladetykkelse.Name = "tb_pladetykkelse"
        Me.tb_pladetykkelse.Size = New System.Drawing.Size(54, 20)
        Me.tb_pladetykkelse.TabIndex = 6
        Me.tb_pladetykkelse.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'cb_materiale
        '
        Me.cb_materiale.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_materiale.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cb_materiale.FormattingEnabled = True
        Me.cb_materiale.IntegralHeight = False
        Me.cb_materiale.Location = New System.Drawing.Point(6, 19)
        Me.cb_materiale.MaxDropDownItems = 15
        Me.cb_materiale.Name = "cb_materiale"
        Me.cb_materiale.Size = New System.Drawing.Size(259, 21)
        Me.cb_materiale.TabIndex = 5
        '
        'gb_gruppe1
        '
        Me.gb_gruppe1.BackColor = System.Drawing.Color.LavenderBlush
        Me.gb_gruppe1.Controls.Add(Me.lb_laser_opstart)
        Me.gb_gruppe1.Controls.Add(Me.Label85)
        Me.gb_gruppe1.Controls.Add(Me.lb_laserCNC_tid)
        Me.gb_gruppe1.Controls.Add(Me.tb_hulantal_3C)
        Me.gb_gruppe1.Controls.Add(Me.tb_laserCNC_tid_uk)
        Me.gb_gruppe1.Controls.Add(Me.tb_laser_opstart_uk)
        Me.gb_gruppe1.Controls.Add(Me.Label97)
        Me.gb_gruppe1.Controls.Add(Me.Label64)
        Me.gb_gruppe1.Controls.Add(Me.Label98)
        Me.gb_gruppe1.Controls.Add(Me.tb_hulantal_2C)
        Me.gb_gruppe1.Controls.Add(Me.tb_hulantal_1C)
        Me.gb_gruppe1.Controls.Add(Me.lb_opstart)
        Me.gb_gruppe1.Controls.Add(Me.Label32)
        Me.gb_gruppe1.Controls.Add(Me.tb_cuttinglength_C)
        Me.gb_gruppe1.Controls.Add(Me.Label31)
        Me.gb_gruppe1.Location = New System.Drawing.Point(263, 294)
        Me.gb_gruppe1.Name = "gb_gruppe1"
        Me.gb_gruppe1.Size = New System.Drawing.Size(250, 151)
        Me.gb_gruppe1.TabIndex = 222
        Me.gb_gruppe1.TabStop = False
        '
        'lb_laser_opstart
        '
        Me.lb_laser_opstart.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_laser_opstart.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_laser_opstart.Location = New System.Drawing.Point(132, 122)
        Me.lb_laser_opstart.Name = "lb_laser_opstart"
        Me.lb_laser_opstart.Size = New System.Drawing.Size(53, 20)
        Me.lb_laser_opstart.TabIndex = 261
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.Location = New System.Drawing.Point(5, 58)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(113, 13)
        Me.Label85.TabIndex = 255
        Me.Label85.Text = "Antal huller (�51-�100)"
        '
        'lb_laserCNC_tid
        '
        Me.lb_laserCNC_tid.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_laserCNC_tid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_laserCNC_tid.Location = New System.Drawing.Point(132, 98)
        Me.lb_laserCNC_tid.Name = "lb_laserCNC_tid"
        Me.lb_laserCNC_tid.Size = New System.Drawing.Size(53, 20)
        Me.lb_laserCNC_tid.TabIndex = 258
        '
        'tb_hulantal_3C
        '
        Me.tb_hulantal_3C.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_hulantal_3C.Location = New System.Drawing.Point(132, 53)
        Me.tb_hulantal_3C.Name = "tb_hulantal_3C"
        Me.tb_hulantal_3C.Size = New System.Drawing.Size(53, 20)
        Me.tb_hulantal_3C.TabIndex = 37
        '
        'tb_laserCNC_tid_uk
        '
        Me.tb_laserCNC_tid_uk.Location = New System.Drawing.Point(191, 98)
        Me.tb_laserCNC_tid_uk.Name = "tb_laserCNC_tid_uk"
        Me.tb_laserCNC_tid_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_laserCNC_tid_uk.TabIndex = 255
        '
        'tb_laser_opstart_uk
        '
        Me.tb_laser_opstart_uk.Location = New System.Drawing.Point(191, 122)
        Me.tb_laser_opstart_uk.Name = "tb_laser_opstart_uk"
        Me.tb_laser_opstart_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_laser_opstart_uk.TabIndex = 256
        '
        'Label97
        '
        Me.Label97.AutoSize = True
        Me.Label97.Location = New System.Drawing.Point(188, 82)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(60, 13)
        Me.Label97.TabIndex = 246
        Me.Label97.Text = "Underkend"
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(5, 39)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(107, 13)
        Me.Label64.TabIndex = 253
        Me.Label64.Text = "Antal huller (�11-�50)"
        '
        'Label98
        '
        Me.Label98.AutoSize = True
        Me.Label98.Location = New System.Drawing.Point(22, 101)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(91, 13)
        Me.Label98.TabIndex = 247
        Me.Label98.Text = "CNC min./100 stk"
        '
        'tb_hulantal_2C
        '
        Me.tb_hulantal_2C.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_hulantal_2C.Location = New System.Drawing.Point(132, 33)
        Me.tb_hulantal_2C.Name = "tb_hulantal_2C"
        Me.tb_hulantal_2C.Size = New System.Drawing.Size(53, 20)
        Me.tb_hulantal_2C.TabIndex = 36
        '
        'tb_hulantal_1C
        '
        Me.tb_hulantal_1C.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_hulantal_1C.Location = New System.Drawing.Point(132, 13)
        Me.tb_hulantal_1C.Name = "tb_hulantal_1C"
        Me.tb_hulantal_1C.Size = New System.Drawing.Size(53, 20)
        Me.tb_hulantal_1C.TabIndex = 35
        '
        'lb_opstart
        '
        Me.lb_opstart.AutoSize = True
        Me.lb_opstart.Location = New System.Drawing.Point(22, 125)
        Me.lb_opstart.Name = "lb_opstart"
        Me.lb_opstart.Size = New System.Drawing.Size(63, 13)
        Me.lb_opstart.TabIndex = 253
        Me.lb_opstart.Text = "Opstart min."
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(5, 77)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(114, 13)
        Me.Label32.TabIndex = 250
        Me.Label32.Text = "Sk�rel�ngde (>�100)"
        '
        'tb_cuttinglength_C
        '
        Me.tb_cuttinglength_C.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_cuttinglength_C.Location = New System.Drawing.Point(132, 73)
        Me.tb_cuttinglength_C.Name = "tb_cuttinglength_C"
        Me.tb_cuttinglength_C.Size = New System.Drawing.Size(53, 20)
        Me.tb_cuttinglength_C.TabIndex = 38
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(5, 20)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(101, 13)
        Me.Label31.TabIndex = 248
        Me.Label31.Text = "Antal huller (�2-�10)"
        '
        'rb_C_laser
        '
        Me.rb_C_laser.AutoSize = True
        Me.rb_C_laser.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.rb_C_laser.Location = New System.Drawing.Point(264, 279)
        Me.rb_C_laser.Name = "rb_C_laser"
        Me.rb_C_laser.Size = New System.Drawing.Size(57, 17)
        Me.rb_C_laser.TabIndex = 34
        Me.rb_C_laser.TabStop = True
        Me.rb_C_laser.Text = "C-laser"
        Me.rb_C_laser.UseVisualStyleBackColor = False
        '
        'lb_gruppe1_opstart
        '
        Me.lb_gruppe1_opstart.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_gruppe1_opstart.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_gruppe1_opstart.Location = New System.Drawing.Point(133, 93)
        Me.lb_gruppe1_opstart.Name = "lb_gruppe1_opstart"
        Me.lb_gruppe1_opstart.Size = New System.Drawing.Size(53, 20)
        Me.lb_gruppe1_opstart.TabIndex = 254
        '
        'tb_gruppe1_opstart_uk
        '
        Me.tb_gruppe1_opstart_uk.Location = New System.Drawing.Point(192, 93)
        Me.tb_gruppe1_opstart_uk.Name = "tb_gruppe1_opstart_uk"
        Me.tb_gruppe1_opstart_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_gruppe1_opstart_uk.TabIndex = 245
        '
        'rb_B_kombi
        '
        Me.rb_B_kombi.AutoSize = True
        Me.rb_B_kombi.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.rb_B_kombi.Location = New System.Drawing.Point(263, 455)
        Me.rb_B_kombi.Name = "rb_B_kombi"
        Me.rb_B_kombi.Size = New System.Drawing.Size(63, 17)
        Me.rb_B_kombi.TabIndex = 39
        Me.rb_B_kombi.TabStop = True
        Me.rb_B_kombi.Text = "B-kombi"
        Me.rb_B_kombi.UseVisualStyleBackColor = False
        '
        'lb_gruppe1_tid
        '
        Me.lb_gruppe1_tid.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_gruppe1_tid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_gruppe1_tid.Location = New System.Drawing.Point(133, 69)
        Me.lb_gruppe1_tid.Name = "lb_gruppe1_tid"
        Me.lb_gruppe1_tid.Size = New System.Drawing.Size(53, 20)
        Me.lb_gruppe1_tid.TabIndex = 251
        '
        'rb_klip
        '
        Me.rb_klip.AutoSize = True
        Me.rb_klip.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.rb_klip.Location = New System.Drawing.Point(263, 673)
        Me.rb_klip.Name = "rb_klip"
        Me.rb_klip.Size = New System.Drawing.Size(42, 17)
        Me.rb_klip.TabIndex = 46
        Me.rb_klip.TabStop = True
        Me.rb_klip.Text = "Klip"
        Me.rb_klip.UseVisualStyleBackColor = False
        '
        'rb_D_stans
        '
        Me.rb_D_stans.AutoSize = True
        Me.rb_D_stans.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.rb_D_stans.Checked = True
        Me.rb_D_stans.Location = New System.Drawing.Point(8, 618)
        Me.rb_D_stans.Name = "rb_D_stans"
        Me.rb_D_stans.Size = New System.Drawing.Size(61, 17)
        Me.rb_D_stans.TabIndex = 31
        Me.rb_D_stans.TabStop = True
        Me.rb_D_stans.Text = "D-stans"
        Me.rb_D_stans.UseVisualStyleBackColor = False
        '
        'tb_CNCmin_uk
        '
        Me.tb_CNCmin_uk.Location = New System.Drawing.Point(192, 69)
        Me.tb_CNCmin_uk.Name = "tb_CNCmin_uk"
        Me.tb_CNCmin_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_CNCmin_uk.TabIndex = 244
        '
        'gb_gruppe2
        '
        Me.gb_gruppe2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.gb_gruppe2.Controls.Add(Me.Label146)
        Me.gb_gruppe2.Controls.Add(Me.gb_gevind)
        Me.gb_gruppe2.Controls.Add(Me.gb_unders�nk)
        Me.gb_gruppe2.Controls.Add(Me.cb_steelmaster)
        Me.gb_gruppe2.Controls.Add(Me.cb_brush)
        Me.gb_gruppe2.Controls.Add(Me.cb_vibrationsafgr)
        Me.gb_gruppe2.Controls.Add(Me.cb_rette)
        Me.gb_gruppe2.Controls.Add(Me.cb_afgrat)
        Me.gb_gruppe2.Controls.Add(Me.Label41)
        Me.gb_gruppe2.Controls.Add(Me.Label147)
        Me.gb_gruppe2.Controls.Add(Me.tb_boltesvejs_antal)
        Me.gb_gruppe2.Controls.Add(Me.tb_presm�trik_antal)
        Me.gb_gruppe2.Controls.Add(Me.lb_grinding)
        Me.gb_gruppe2.Controls.Add(Me.lb_afgrat)
        Me.gb_gruppe2.Controls.Add(Me.lb_stans_manuel)
        Me.gb_gruppe2.Controls.Add(Me.lb_rette)
        Me.gb_gruppe2.Controls.Add(Me.lb_vibration)
        Me.gb_gruppe2.Controls.Add(Me.lb_brush)
        Me.gb_gruppe2.Controls.Add(Me.lb_boltesvejs)
        Me.gb_gruppe2.Controls.Add(Me.lb_pressnut)
        Me.gb_gruppe2.Controls.Add(Me.Label100)
        Me.gb_gruppe2.Controls.Add(Me.tb_vibration_uk)
        Me.gb_gruppe2.Controls.Add(Me.tb_boltesvejs_uk)
        Me.gb_gruppe2.Controls.Add(Me.tb_afgrat_uk)
        Me.gb_gruppe2.Controls.Add(Me.Label106)
        Me.gb_gruppe2.Controls.Add(Me.tb_pressnut_uk)
        Me.gb_gruppe2.Controls.Add(Me.tb_grinding_uk)
        Me.gb_gruppe2.Controls.Add(Me.Label105)
        Me.gb_gruppe2.Controls.Add(Me.tb_brush_uk)
        Me.gb_gruppe2.Controls.Add(Me.Label104)
        Me.gb_gruppe2.Controls.Add(Me.Label103)
        Me.gb_gruppe2.Controls.Add(Me.Label101)
        Me.gb_gruppe2.Controls.Add(Me.tb_stans_manuel_uk)
        Me.gb_gruppe2.Controls.Add(Me.tb_rette_uk)
        Me.gb_gruppe2.Controls.Add(Me.Label102)
        Me.gb_gruppe2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.gb_gruppe2.Location = New System.Drawing.Point(518, 270)
        Me.gb_gruppe2.Name = "gb_gruppe2"
        Me.gb_gruppe2.Size = New System.Drawing.Size(253, 486)
        Me.gb_gruppe2.TabIndex = 470
        Me.gb_gruppe2.TabStop = False
        Me.gb_gruppe2.Text = "Gruppe 2"
        '
        'Label146
        '
        Me.Label146.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label146.Location = New System.Drawing.Point(22, 164)
        Me.Label146.Name = "Label146"
        Me.Label146.Size = New System.Drawing.Size(74, 23)
        Me.Label146.TabIndex = 292
        Me.Label146.Text = "Svejsestag" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "antal pr emne"
        '
        'gb_gevind
        '
        Me.gb_gevind.Controls.Add(Me.Label22)
        Me.gb_gevind.Controls.Add(Me.tb_m6)
        Me.gb_gevind.Controls.Add(Me.Label180)
        Me.gb_gevind.Controls.Add(Me.Label23)
        Me.gb_gevind.Controls.Add(Me.Label179)
        Me.gb_gevind.Controls.Add(Me.tb_m8)
        Me.gb_gevind.Controls.Add(Me.Label24)
        Me.gb_gevind.Controls.Add(Me.tb_m10)
        Me.gb_gevind.Controls.Add(Me.Label28)
        Me.gb_gevind.Controls.Add(Me.tb_m5)
        Me.gb_gevind.Controls.Add(Me.Label139)
        Me.gb_gevind.Controls.Add(Me.tb_m2_5)
        Me.gb_gevind.Controls.Add(Me.Label141)
        Me.gb_gevind.Controls.Add(Me.tb_m3)
        Me.gb_gevind.Controls.Add(Me.Label142)
        Me.gb_gevind.Controls.Add(Me.tb_m4)
        Me.gb_gevind.Controls.Add(Me.Label143)
        Me.gb_gevind.Controls.Add(Me.Label144)
        Me.gb_gevind.Controls.Add(Me.Label145)
        Me.gb_gevind.Controls.Add(Me.tb_m2)
        Me.gb_gevind.Controls.Add(Me.lb_gevind_antal)
        Me.gb_gevind.Controls.Add(Me.Label151)
        Me.gb_gevind.Controls.Add(Me.lb_gevind)
        Me.gb_gevind.Controls.Add(Me.tb_gevind_uk)
        Me.gb_gevind.Location = New System.Drawing.Point(3, 191)
        Me.gb_gevind.Name = "gb_gevind"
        Me.gb_gevind.Size = New System.Drawing.Size(120, 292)
        Me.gb_gevind.TabIndex = 291
        Me.gb_gevind.TabStop = False
        Me.gb_gevind.Text = "GEVIND"
        '
        'Label22
        '
        Me.Label22.Location = New System.Drawing.Point(3, 147)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(39, 20)
        Me.Label22.TabIndex = 287
        Me.Label22.Text = "M6"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tb_m6
        '
        Me.tb_m6.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_m6.Location = New System.Drawing.Point(60, 147)
        Me.tb_m6.Name = "tb_m6"
        Me.tb_m6.Size = New System.Drawing.Size(48, 20)
        Me.tb_m6.TabIndex = 59
        '
        'Label180
        '
        Me.Label180.AutoSize = True
        Me.Label180.Location = New System.Drawing.Point(0, 271)
        Me.Label180.Name = "Label180"
        Me.Label180.Size = New System.Drawing.Size(60, 13)
        Me.Label180.TabIndex = 289
        Me.Label180.Text = "Underkend"
        '
        'Label23
        '
        Me.Label23.Location = New System.Drawing.Point(3, 167)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(39, 20)
        Me.Label23.TabIndex = 286
        Me.Label23.Text = "M8"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label179
        '
        Me.Label179.Location = New System.Drawing.Point(3, 232)
        Me.Label179.Name = "Label179"
        Me.Label179.Size = New System.Drawing.Size(55, 30)
        Me.Label179.TabIndex = 288
        Me.Label179.Text = "min./100 stk"
        Me.Label179.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tb_m8
        '
        Me.tb_m8.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_m8.Location = New System.Drawing.Point(60, 167)
        Me.tb_m8.Name = "tb_m8"
        Me.tb_m8.Size = New System.Drawing.Size(48, 20)
        Me.tb_m8.TabIndex = 60
        '
        'Label24
        '
        Me.Label24.Location = New System.Drawing.Point(3, 187)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(39, 20)
        Me.Label24.TabIndex = 285
        Me.Label24.Text = "M10"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tb_m10
        '
        Me.tb_m10.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_m10.Location = New System.Drawing.Point(60, 188)
        Me.tb_m10.Name = "tb_m10"
        Me.tb_m10.Size = New System.Drawing.Size(48, 20)
        Me.tb_m10.TabIndex = 61
        '
        'Label28
        '
        Me.Label28.Location = New System.Drawing.Point(3, 127)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(39, 20)
        Me.Label28.TabIndex = 284
        Me.Label28.Text = "M5"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tb_m5
        '
        Me.tb_m5.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_m5.Location = New System.Drawing.Point(60, 127)
        Me.tb_m5.Name = "tb_m5"
        Me.tb_m5.Size = New System.Drawing.Size(48, 20)
        Me.tb_m5.TabIndex = 58
        '
        'Label139
        '
        Me.Label139.Location = New System.Drawing.Point(3, 67)
        Me.Label139.Name = "Label139"
        Me.Label139.Size = New System.Drawing.Size(39, 20)
        Me.Label139.TabIndex = 283
        Me.Label139.Text = "M2,5"
        Me.Label139.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tb_m2_5
        '
        Me.tb_m2_5.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_m2_5.Location = New System.Drawing.Point(60, 67)
        Me.tb_m2_5.Name = "tb_m2_5"
        Me.tb_m2_5.Size = New System.Drawing.Size(48, 20)
        Me.tb_m2_5.TabIndex = 55
        '
        'Label141
        '
        Me.Label141.Location = New System.Drawing.Point(3, 87)
        Me.Label141.Name = "Label141"
        Me.Label141.Size = New System.Drawing.Size(39, 20)
        Me.Label141.TabIndex = 282
        Me.Label141.Text = "M3"
        Me.Label141.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tb_m3
        '
        Me.tb_m3.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_m3.Location = New System.Drawing.Point(60, 87)
        Me.tb_m3.Name = "tb_m3"
        Me.tb_m3.Size = New System.Drawing.Size(48, 20)
        Me.tb_m3.TabIndex = 56
        '
        'Label142
        '
        Me.Label142.Location = New System.Drawing.Point(3, 107)
        Me.Label142.Name = "Label142"
        Me.Label142.Size = New System.Drawing.Size(39, 20)
        Me.Label142.TabIndex = 279
        Me.Label142.Text = "M4"
        Me.Label142.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tb_m4
        '
        Me.tb_m4.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_m4.Location = New System.Drawing.Point(60, 107)
        Me.tb_m4.Name = "tb_m4"
        Me.tb_m4.Size = New System.Drawing.Size(48, 20)
        Me.tb_m4.TabIndex = 57
        '
        'Label143
        '
        Me.Label143.Location = New System.Drawing.Point(58, 13)
        Me.Label143.Name = "Label143"
        Me.Label143.Size = New System.Drawing.Size(51, 33)
        Me.Label143.TabIndex = 276
        Me.Label143.Text = "Antal pr emne"
        Me.Label143.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label144
        '
        Me.Label144.Location = New System.Drawing.Point(9, 17)
        Me.Label144.Name = "Label144"
        Me.Label144.Size = New System.Drawing.Size(43, 30)
        Me.Label144.TabIndex = 273
        Me.Label144.Text = "Gevind str."
        Me.Label144.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label145
        '
        Me.Label145.Location = New System.Drawing.Point(4, 47)
        Me.Label145.Name = "Label145"
        Me.Label145.Size = New System.Drawing.Size(39, 20)
        Me.Label145.TabIndex = 272
        Me.Label145.Text = "M2"
        Me.Label145.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tb_m2
        '
        Me.tb_m2.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_m2.Location = New System.Drawing.Point(60, 47)
        Me.tb_m2.Name = "tb_m2"
        Me.tb_m2.Size = New System.Drawing.Size(48, 20)
        Me.tb_m2.TabIndex = 54
        '
        'lb_gevind_antal
        '
        Me.lb_gevind_antal.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_gevind_antal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_gevind_antal.Location = New System.Drawing.Point(60, 210)
        Me.lb_gevind_antal.Name = "lb_gevind_antal"
        Me.lb_gevind_antal.Size = New System.Drawing.Size(48, 20)
        Me.lb_gevind_antal.TabIndex = 266
        '
        'Label151
        '
        Me.Label151.AutoSize = True
        Me.Label151.Location = New System.Drawing.Point(10, 212)
        Me.Label151.Name = "Label151"
        Me.Label151.Size = New System.Drawing.Size(46, 13)
        Me.Label151.TabIndex = 264
        Me.Label151.Text = "antal ialt"
        '
        'lb_gevind
        '
        Me.lb_gevind.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_gevind.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_gevind.Location = New System.Drawing.Point(60, 240)
        Me.lb_gevind.Name = "lb_gevind"
        Me.lb_gevind.Size = New System.Drawing.Size(53, 20)
        Me.lb_gevind.TabIndex = 244
        '
        'tb_gevind_uk
        '
        Me.tb_gevind_uk.Location = New System.Drawing.Point(59, 268)
        Me.tb_gevind_uk.Name = "tb_gevind_uk"
        Me.tb_gevind_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_gevind_uk.TabIndex = 252
        '
        'gb_unders�nk
        '
        Me.gb_unders�nk.Controls.Add(Me.Label183)
        Me.gb_unders�nk.Controls.Add(Me.tb_2)
        Me.gb_unders�nk.Controls.Add(Me.Label184)
        Me.gb_unders�nk.Controls.Add(Me.tb_3)
        Me.gb_unders�nk.Controls.Add(Me.Label185)
        Me.gb_unders�nk.Controls.Add(Me.tb_4)
        Me.gb_unders�nk.Controls.Add(Me.Label186)
        Me.gb_unders�nk.Controls.Add(Me.Label187)
        Me.gb_unders�nk.Controls.Add(Me.Label188)
        Me.gb_unders�nk.Controls.Add(Me.tb_1)
        Me.gb_unders�nk.Controls.Add(Me.Label182)
        Me.gb_unders�nk.Controls.Add(Me.Label181)
        Me.gb_unders�nk.Controls.Add(Me.lb_unders�nk_antal)
        Me.gb_unders�nk.Controls.Add(Me.Label148)
        Me.gb_unders�nk.Controls.Add(Me.lb_countersink)
        Me.gb_unders�nk.Controls.Add(Me.tb_countersink_uk)
        Me.gb_unders�nk.Location = New System.Drawing.Point(121, 191)
        Me.gb_unders�nk.Name = "gb_unders�nk"
        Me.gb_unders�nk.Size = New System.Drawing.Size(127, 292)
        Me.gb_unders�nk.TabIndex = 290
        Me.gb_unders�nk.TabStop = False
        Me.gb_unders�nk.Text = "UNDERS�NKNING"
        '
        'Label183
        '
        Me.Label183.Location = New System.Drawing.Point(-3, 70)
        Me.Label183.Name = "Label183"
        Me.Label183.Size = New System.Drawing.Size(94, 20)
        Me.Label183.TabIndex = 300
        Me.Label183.Text = "6-10 mm (M3-M5)"
        Me.Label183.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tb_2
        '
        Me.tb_2.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_2.Location = New System.Drawing.Point(90, 70)
        Me.tb_2.Name = "tb_2"
        Me.tb_2.Size = New System.Drawing.Size(35, 20)
        Me.tb_2.TabIndex = 63
        '
        'Label184
        '
        Me.Label184.Location = New System.Drawing.Point(-4, 95)
        Me.Label184.Name = "Label184"
        Me.Label184.Size = New System.Drawing.Size(95, 20)
        Me.Label184.TabIndex = 299
        Me.Label184.Text = "10-15 mm (M6-M8)"
        Me.Label184.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tb_3
        '
        Me.tb_3.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_3.Location = New System.Drawing.Point(90, 95)
        Me.tb_3.Name = "tb_3"
        Me.tb_3.Size = New System.Drawing.Size(35, 20)
        Me.tb_3.TabIndex = 64
        '
        'Label185
        '
        Me.Label185.Location = New System.Drawing.Point(17, 115)
        Me.Label185.Name = "Label185"
        Me.Label185.Size = New System.Drawing.Size(69, 29)
        Me.Label185.TabIndex = 298
        Me.Label185.Text = "over 15 mm (M10-M12)"
        Me.Label185.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tb_4
        '
        Me.tb_4.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_4.Location = New System.Drawing.Point(90, 120)
        Me.tb_4.Name = "tb_4"
        Me.tb_4.Size = New System.Drawing.Size(35, 20)
        Me.tb_4.TabIndex = 65
        '
        'Label186
        '
        Me.Label186.Location = New System.Drawing.Point(82, 16)
        Me.Label186.Name = "Label186"
        Me.Label186.Size = New System.Drawing.Size(43, 27)
        Me.Label186.TabIndex = 296
        Me.Label186.Text = "Antal pr emne"
        Me.Label186.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label187
        '
        Me.Label187.Location = New System.Drawing.Point(13, 20)
        Me.Label187.Name = "Label187"
        Me.Label187.Size = New System.Drawing.Size(76, 29)
        Me.Label187.TabIndex = 294
        Me.Label187.Text = "Diameter (Gevind str.)"
        Me.Label187.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label188
        '
        Me.Label188.Location = New System.Drawing.Point(-3, 45)
        Me.Label188.Name = "Label188"
        Me.Label188.Size = New System.Drawing.Size(94, 20)
        Me.Label188.TabIndex = 292
        Me.Label188.Text = "4-5 mm (M2-M2.5)"
        Me.Label188.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tb_1
        '
        Me.tb_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_1.Location = New System.Drawing.Point(90, 45)
        Me.tb_1.Name = "tb_1"
        Me.tb_1.Size = New System.Drawing.Size(35, 20)
        Me.tb_1.TabIndex = 62
        '
        'Label182
        '
        Me.Label182.AutoSize = True
        Me.Label182.Location = New System.Drawing.Point(7, 269)
        Me.Label182.Name = "Label182"
        Me.Label182.Size = New System.Drawing.Size(60, 13)
        Me.Label182.TabIndex = 290
        Me.Label182.Text = "Underkend"
        '
        'Label181
        '
        Me.Label181.Location = New System.Drawing.Point(8, 234)
        Me.Label181.Name = "Label181"
        Me.Label181.Size = New System.Drawing.Size(55, 30)
        Me.Label181.TabIndex = 289
        Me.Label181.Text = "min./100 stk"
        Me.Label181.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_unders�nk_antal
        '
        Me.lb_unders�nk_antal.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_unders�nk_antal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_unders�nk_antal.Location = New System.Drawing.Point(90, 145)
        Me.lb_unders�nk_antal.Name = "lb_unders�nk_antal"
        Me.lb_unders�nk_antal.Size = New System.Drawing.Size(35, 20)
        Me.lb_unders�nk_antal.TabIndex = 268
        '
        'Label148
        '
        Me.Label148.AutoSize = True
        Me.Label148.Location = New System.Drawing.Point(44, 147)
        Me.Label148.Name = "Label148"
        Me.Label148.Size = New System.Drawing.Size(46, 13)
        Me.Label148.TabIndex = 261
        Me.Label148.Text = "antal ialt"
        '
        'lb_countersink
        '
        Me.lb_countersink.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_countersink.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_countersink.Location = New System.Drawing.Point(68, 239)
        Me.lb_countersink.Name = "lb_countersink"
        Me.lb_countersink.Size = New System.Drawing.Size(53, 20)
        Me.lb_countersink.TabIndex = 243
        '
        'tb_countersink_uk
        '
        Me.tb_countersink_uk.Location = New System.Drawing.Point(67, 267)
        Me.tb_countersink_uk.Name = "tb_countersink_uk"
        Me.tb_countersink_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_countersink_uk.TabIndex = 251
        '
        'cb_steelmaster
        '
        Me.cb_steelmaster.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_steelmaster.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cb_steelmaster.Location = New System.Drawing.Point(105, 45)
        Me.cb_steelmaster.Name = "cb_steelmaster"
        Me.cb_steelmaster.Size = New System.Drawing.Size(16, 19)
        Me.cb_steelmaster.TabIndex = 48
        Me.cb_steelmaster.UseVisualStyleBackColor = False
        '
        'cb_brush
        '
        Me.cb_brush.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_brush.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cb_brush.Location = New System.Drawing.Point(105, 65)
        Me.cb_brush.Name = "cb_brush"
        Me.cb_brush.Size = New System.Drawing.Size(16, 19)
        Me.cb_brush.TabIndex = 49
        Me.cb_brush.UseVisualStyleBackColor = False
        '
        'cb_vibrationsafgr
        '
        Me.cb_vibrationsafgr.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_vibrationsafgr.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cb_vibrationsafgr.Enabled = False
        Me.cb_vibrationsafgr.Location = New System.Drawing.Point(105, 85)
        Me.cb_vibrationsafgr.Name = "cb_vibrationsafgr"
        Me.cb_vibrationsafgr.Size = New System.Drawing.Size(16, 19)
        Me.cb_vibrationsafgr.TabIndex = 50
        Me.cb_vibrationsafgr.UseVisualStyleBackColor = False
        '
        'cb_rette
        '
        Me.cb_rette.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_rette.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cb_rette.Location = New System.Drawing.Point(105, 105)
        Me.cb_rette.Name = "cb_rette"
        Me.cb_rette.Size = New System.Drawing.Size(16, 19)
        Me.cb_rette.TabIndex = 51
        Me.cb_rette.UseVisualStyleBackColor = False
        '
        'cb_afgrat
        '
        Me.cb_afgrat.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_afgrat.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cb_afgrat.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cb_afgrat.Location = New System.Drawing.Point(105, 23)
        Me.cb_afgrat.Name = "cb_afgrat"
        Me.cb_afgrat.Size = New System.Drawing.Size(16, 19)
        Me.cb_afgrat.TabIndex = 47
        Me.cb_afgrat.UseVisualStyleBackColor = False
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(124, 9)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(66, 13)
        Me.Label41.TabIndex = 269
        Me.Label41.Text = "min./100 stk"
        '
        'Label147
        '
        Me.Label147.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label147.Location = New System.Drawing.Point(22, 139)
        Me.Label147.Name = "Label147"
        Me.Label147.Size = New System.Drawing.Size(74, 23)
        Me.Label147.TabIndex = 259
        Me.Label147.Text = "Presm�trik/stag" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "antal pr emne"
        '
        'tb_boltesvejs_antal
        '
        Me.tb_boltesvejs_antal.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_boltesvejs_antal.Location = New System.Drawing.Point(95, 164)
        Me.tb_boltesvejs_antal.Name = "tb_boltesvejs_antal"
        Me.tb_boltesvejs_antal.Size = New System.Drawing.Size(31, 20)
        Me.tb_boltesvejs_antal.TabIndex = 53
        '
        'tb_presm�trik_antal
        '
        Me.tb_presm�trik_antal.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_presm�trik_antal.Location = New System.Drawing.Point(95, 144)
        Me.tb_presm�trik_antal.Name = "tb_presm�trik_antal"
        Me.tb_presm�trik_antal.Size = New System.Drawing.Size(31, 20)
        Me.tb_presm�trik_antal.TabIndex = 52
        '
        'lb_grinding
        '
        Me.lb_grinding.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_grinding.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_grinding.Location = New System.Drawing.Point(132, 45)
        Me.lb_grinding.Name = "lb_grinding"
        Me.lb_grinding.Size = New System.Drawing.Size(53, 20)
        Me.lb_grinding.TabIndex = 241
        Me.lb_grinding.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_afgrat
        '
        Me.lb_afgrat.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_afgrat.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_afgrat.Location = New System.Drawing.Point(132, 25)
        Me.lb_afgrat.Name = "lb_afgrat"
        Me.lb_afgrat.Size = New System.Drawing.Size(53, 20)
        Me.lb_afgrat.TabIndex = 240
        Me.lb_afgrat.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_stans_manuel
        '
        Me.lb_stans_manuel.BackColor = System.Drawing.Color.WhiteSmoke
        Me.lb_stans_manuel.Enabled = False
        Me.lb_stans_manuel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lb_stans_manuel.Location = New System.Drawing.Point(132, 125)
        Me.lb_stans_manuel.Name = "lb_stans_manuel"
        Me.lb_stans_manuel.Size = New System.Drawing.Size(53, 18)
        Me.lb_stans_manuel.TabIndex = 245
        Me.lb_stans_manuel.Visible = False
        '
        'lb_rette
        '
        Me.lb_rette.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_rette.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_rette.Location = New System.Drawing.Point(132, 105)
        Me.lb_rette.Name = "lb_rette"
        Me.lb_rette.Size = New System.Drawing.Size(53, 20)
        Me.lb_rette.TabIndex = 244
        Me.lb_rette.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_vibration
        '
        Me.lb_vibration.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_vibration.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_vibration.Location = New System.Drawing.Point(132, 85)
        Me.lb_vibration.Name = "lb_vibration"
        Me.lb_vibration.Size = New System.Drawing.Size(53, 20)
        Me.lb_vibration.TabIndex = 243
        Me.lb_vibration.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_brush
        '
        Me.lb_brush.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_brush.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_brush.Location = New System.Drawing.Point(132, 65)
        Me.lb_brush.Name = "lb_brush"
        Me.lb_brush.Size = New System.Drawing.Size(53, 20)
        Me.lb_brush.TabIndex = 242
        Me.lb_brush.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_boltesvejs
        '
        Me.lb_boltesvejs.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_boltesvejs.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_boltesvejs.Location = New System.Drawing.Point(132, 164)
        Me.lb_boltesvejs.Name = "lb_boltesvejs"
        Me.lb_boltesvejs.Size = New System.Drawing.Size(53, 20)
        Me.lb_boltesvejs.TabIndex = 246
        Me.lb_boltesvejs.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_pressnut
        '
        Me.lb_pressnut.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_pressnut.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_pressnut.Location = New System.Drawing.Point(132, 144)
        Me.lb_pressnut.Name = "lb_pressnut"
        Me.lb_pressnut.Size = New System.Drawing.Size(53, 20)
        Me.lb_pressnut.TabIndex = 245
        Me.lb_pressnut.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label100
        '
        Me.Label100.AutoSize = True
        Me.Label100.Location = New System.Drawing.Point(187, 9)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(60, 13)
        Me.Label100.TabIndex = 242
        Me.Label100.Text = "Underkend"
        '
        'tb_vibration_uk
        '
        Me.tb_vibration_uk.Location = New System.Drawing.Point(190, 85)
        Me.tb_vibration_uk.Name = "tb_vibration_uk"
        Me.tb_vibration_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_vibration_uk.TabIndex = 430
        '
        'tb_boltesvejs_uk
        '
        Me.tb_boltesvejs_uk.Location = New System.Drawing.Point(190, 164)
        Me.tb_boltesvejs_uk.Name = "tb_boltesvejs_uk"
        Me.tb_boltesvejs_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_boltesvejs_uk.TabIndex = 254
        '
        'tb_afgrat_uk
        '
        Me.tb_afgrat_uk.Location = New System.Drawing.Point(190, 25)
        Me.tb_afgrat_uk.Name = "tb_afgrat_uk"
        Me.tb_afgrat_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_afgrat_uk.TabIndex = 400
        '
        'Label106
        '
        Me.Label106.AutoSize = True
        Me.Label106.Location = New System.Drawing.Point(4, 28)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(85, 13)
        Me.Label106.TabIndex = 235
        Me.Label106.Text = "Manuel Afgrat/fil"
        '
        'tb_pressnut_uk
        '
        Me.tb_pressnut_uk.Location = New System.Drawing.Point(190, 144)
        Me.tb_pressnut_uk.Name = "tb_pressnut_uk"
        Me.tb_pressnut_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_pressnut_uk.TabIndex = 460
        '
        'tb_grinding_uk
        '
        Me.tb_grinding_uk.Location = New System.Drawing.Point(190, 45)
        Me.tb_grinding_uk.Name = "tb_grinding_uk"
        Me.tb_grinding_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_grinding_uk.TabIndex = 410
        '
        'Label105
        '
        Me.Label105.AutoSize = True
        Me.Label105.Location = New System.Drawing.Point(4, 48)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(62, 13)
        Me.Label105.TabIndex = 238
        Me.Label105.Text = "Steelmaster"
        '
        'tb_brush_uk
        '
        Me.tb_brush_uk.Location = New System.Drawing.Point(190, 65)
        Me.tb_brush_uk.Name = "tb_brush_uk"
        Me.tb_brush_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_brush_uk.TabIndex = 420
        '
        'Label104
        '
        Me.Label104.AutoSize = True
        Me.Label104.Location = New System.Drawing.Point(4, 68)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(84, 13)
        Me.Label104.TabIndex = 241
        Me.Label104.Text = "B�rsteafgratning"
        '
        'Label103
        '
        Me.Label103.AutoSize = True
        Me.Label103.Location = New System.Drawing.Point(4, 88)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(89, 13)
        Me.Label103.TabIndex = 244
        Me.Label103.Text = "Vibrationsafgratn."
        '
        'Label101
        '
        Me.Label101.AutoSize = True
        Me.Label101.Location = New System.Drawing.Point(4, 128)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(71, 13)
        Me.Label101.TabIndex = 250
        Me.Label101.Text = "Stans manuel"
        '
        'tb_stans_manuel_uk
        '
        Me.tb_stans_manuel_uk.Location = New System.Drawing.Point(190, 125)
        Me.tb_stans_manuel_uk.Name = "tb_stans_manuel_uk"
        Me.tb_stans_manuel_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_stans_manuel_uk.TabIndex = 450
        '
        'tb_rette_uk
        '
        Me.tb_rette_uk.Location = New System.Drawing.Point(190, 105)
        Me.tb_rette_uk.Name = "tb_rette_uk"
        Me.tb_rette_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_rette_uk.TabIndex = 440
        '
        'Label102
        '
        Me.Label102.AutoSize = True
        Me.Label102.Location = New System.Drawing.Point(4, 108)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(72, 13)
        Me.Label102.TabIndex = 247
        Me.Label102.Text = "Rettemaskine"
        '
        'gb_gruppe3
        '
        Me.gb_gruppe3.BackColor = System.Drawing.Color.Honeydew
        Me.gb_gruppe3.Controls.Add(Me.cb_spotweld)
        Me.gb_gruppe3.Controls.Add(Me.Label34)
        Me.gb_gruppe3.Controls.Add(Me.tb_numberofspotweldseams)
        Me.gb_gruppe3.Controls.Add(Me.Label203)
        Me.gb_gruppe3.Controls.Add(Me.tb_numberofspots)
        Me.gb_gruppe3.Controls.Add(Me.Label202)
        Me.gb_gruppe3.Controls.Add(Me.Label201)
        Me.gb_gruppe3.Controls.Add(Me.Label128)
        Me.gb_gruppe3.Controls.Add(Me.lb_spotweld)
        Me.gb_gruppe3.Controls.Add(Me.tb_spotweld_uk)
        Me.gb_gruppe3.Location = New System.Drawing.Point(775, 274)
        Me.gb_gruppe3.Name = "gb_gruppe3"
        Me.gb_gruppe3.Size = New System.Drawing.Size(211, 99)
        Me.gb_gruppe3.TabIndex = 224
        Me.gb_gruppe3.TabStop = False
        Me.gb_gruppe3.Text = "Gruppe 3  Punktsvejsning"
        '
        'cb_spotweld
        '
        Me.cb_spotweld.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_spotweld.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cb_spotweld.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cb_spotweld.Location = New System.Drawing.Point(74, 73)
        Me.cb_spotweld.Name = "cb_spotweld"
        Me.cb_spotweld.Size = New System.Drawing.Size(16, 19)
        Me.cb_spotweld.TabIndex = 68
        Me.cb_spotweld.UseVisualStyleBackColor = False
        '
        'Label34
        '
        Me.Label34.Location = New System.Drawing.Point(4, 16)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(140, 14)
        Me.Label34.TabIndex = 281
        Me.Label34.Text = "antal svejses�mme pr emne"
        Me.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tb_numberofspotweldseams
        '
        Me.tb_numberofspotweldseams.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_numberofspotweldseams.Location = New System.Drawing.Point(155, 12)
        Me.tb_numberofspotweldseams.Name = "tb_numberofspotweldseams"
        Me.tb_numberofspotweldseams.Size = New System.Drawing.Size(53, 20)
        Me.tb_numberofspotweldseams.TabIndex = 66
        Me.tb_numberofspotweldseams.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label203
        '
        Me.Label203.Location = New System.Drawing.Point(2, 37)
        Me.Label203.Name = "Label203"
        Me.Label203.Size = New System.Drawing.Size(154, 14)
        Me.Label203.TabIndex = 279
        Me.Label203.Text = "antal punktsvejsninger pr emne"
        Me.Label203.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tb_numberofspots
        '
        Me.tb_numberofspots.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_numberofspots.Location = New System.Drawing.Point(155, 33)
        Me.tb_numberofspots.Name = "tb_numberofspots"
        Me.tb_numberofspots.Size = New System.Drawing.Size(53, 20)
        Me.tb_numberofspots.TabIndex = 67
        Me.tb_numberofspots.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label202
        '
        Me.Label202.AutoSize = True
        Me.Label202.Location = New System.Drawing.Point(86, 58)
        Me.Label202.Name = "Label202"
        Me.Label202.Size = New System.Drawing.Size(66, 13)
        Me.Label202.TabIndex = 277
        Me.Label202.Text = "min./100 stk"
        '
        'Label201
        '
        Me.Label201.AutoSize = True
        Me.Label201.Location = New System.Drawing.Point(2, 76)
        Me.Label201.Name = "Label201"
        Me.Label201.Size = New System.Drawing.Size(67, 13)
        Me.Label201.TabIndex = 276
        Me.Label201.Text = "punktsvejsn."
        '
        'Label128
        '
        Me.Label128.AutoSize = True
        Me.Label128.Location = New System.Drawing.Point(151, 58)
        Me.Label128.Name = "Label128"
        Me.Label128.Size = New System.Drawing.Size(60, 13)
        Me.Label128.TabIndex = 250
        Me.Label128.Text = "Underkend"
        '
        'lb_spotweld
        '
        Me.lb_spotweld.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_spotweld.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_spotweld.Location = New System.Drawing.Point(95, 73)
        Me.lb_spotweld.Name = "lb_spotweld"
        Me.lb_spotweld.Size = New System.Drawing.Size(53, 20)
        Me.lb_spotweld.TabIndex = 249
        '
        'tb_spotweld_uk
        '
        Me.tb_spotweld_uk.Location = New System.Drawing.Point(154, 74)
        Me.tb_spotweld_uk.Name = "tb_spotweld_uk"
        Me.tb_spotweld_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_spotweld_uk.TabIndex = 501
        '
        'gb_gruppe4
        '
        Me.gb_gruppe4.BackColor = System.Drawing.Color.Honeydew
        Me.gb_gruppe4.Controls.Add(Me.rb_migmag)
        Me.gb_gruppe4.Controls.Add(Me.rb_tig)
        Me.gb_gruppe4.Controls.Add(Me.cb_weld)
        Me.gb_gruppe4.Controls.Add(Me.cb_grind_weld)
        Me.gb_gruppe4.Controls.Add(Me.cb_tackweld)
        Me.gb_gruppe4.Controls.Add(Me.Label194)
        Me.gb_gruppe4.Controls.Add(Me.Label197)
        Me.gb_gruppe4.Controls.Add(Me.Label200)
        Me.gb_gruppe4.Controls.Add(Me.Label192)
        Me.gb_gruppe4.Controls.Add(Me.Label189)
        Me.gb_gruppe4.Controls.Add(Me.tb_numberofwelds)
        Me.gb_gruppe4.Controls.Add(Me.Label150)
        Me.gb_gruppe4.Controls.Add(Me.tb_weldlength)
        Me.gb_gruppe4.Controls.Add(Me.Label132)
        Me.gb_gruppe4.Controls.Add(Me.lb_grind_weld)
        Me.gb_gruppe4.Controls.Add(Me.lb_weld)
        Me.gb_gruppe4.Controls.Add(Me.lb_tackweld)
        Me.gb_gruppe4.Controls.Add(Me.tb_grind_weld_uk)
        Me.gb_gruppe4.Controls.Add(Me.tb_weld_uk)
        Me.gb_gruppe4.Controls.Add(Me.tb_tackweld_uk)
        Me.gb_gruppe4.Controls.Add(Me.GroupBox15)
        Me.gb_gruppe4.Location = New System.Drawing.Point(775, 375)
        Me.gb_gruppe4.Name = "gb_gruppe4"
        Me.gb_gruppe4.Size = New System.Drawing.Size(210, 164)
        Me.gb_gruppe4.TabIndex = 225
        Me.gb_gruppe4.TabStop = False
        Me.gb_gruppe4.Text = "Gruppe 4  Svejsning"
        '
        'rb_migmag
        '
        Me.rb_migmag.AutoSize = True
        Me.rb_migmag.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.rb_migmag.Location = New System.Drawing.Point(75, 58)
        Me.rb_migmag.Name = "rb_migmag"
        Me.rb_migmag.Size = New System.Drawing.Size(74, 17)
        Me.rb_migmag.TabIndex = 72
        Me.rb_migmag.TabStop = True
        Me.rb_migmag.Text = "MIG/MAG"
        Me.rb_migmag.UseVisualStyleBackColor = False
        '
        'rb_tig
        '
        Me.rb_tig.AutoSize = True
        Me.rb_tig.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.rb_tig.Checked = True
        Me.rb_tig.Location = New System.Drawing.Point(12, 58)
        Me.rb_tig.Name = "rb_tig"
        Me.rb_tig.Size = New System.Drawing.Size(43, 17)
        Me.rb_tig.TabIndex = 71
        Me.rb_tig.TabStop = True
        Me.rb_tig.Text = "TIG"
        Me.rb_tig.UseVisualStyleBackColor = False
        '
        'cb_weld
        '
        Me.cb_weld.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_weld.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cb_weld.Location = New System.Drawing.Point(74, 116)
        Me.cb_weld.Name = "cb_weld"
        Me.cb_weld.Size = New System.Drawing.Size(16, 19)
        Me.cb_weld.TabIndex = 74
        Me.cb_weld.UseVisualStyleBackColor = False
        '
        'cb_grind_weld
        '
        Me.cb_grind_weld.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_grind_weld.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cb_grind_weld.Location = New System.Drawing.Point(74, 136)
        Me.cb_grind_weld.Name = "cb_grind_weld"
        Me.cb_grind_weld.Size = New System.Drawing.Size(16, 19)
        Me.cb_grind_weld.TabIndex = 75
        Me.cb_grind_weld.UseVisualStyleBackColor = False
        '
        'cb_tackweld
        '
        Me.cb_tackweld.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_tackweld.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cb_tackweld.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cb_tackweld.Location = New System.Drawing.Point(74, 96)
        Me.cb_tackweld.Name = "cb_tackweld"
        Me.cb_tackweld.Size = New System.Drawing.Size(16, 19)
        Me.cb_tackweld.TabIndex = 73
        Me.cb_tackweld.UseVisualStyleBackColor = False
        '
        'Label194
        '
        Me.Label194.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label194.Location = New System.Drawing.Point(2, 84)
        Me.Label194.Name = "Label194"
        Me.Label194.Size = New System.Drawing.Size(71, 26)
        Me.Label194.TabIndex = 274
        Me.Label194.Text = "kun       h�fte svejsn."
        '
        'Label197
        '
        Me.Label197.AutoSize = True
        Me.Label197.Location = New System.Drawing.Point(2, 119)
        Me.Label197.Name = "Label197"
        Me.Label197.Size = New System.Drawing.Size(71, 13)
        Me.Label197.TabIndex = 275
        Me.Label197.Text = "fuld svejsning"
        '
        'Label200
        '
        Me.Label200.AutoSize = True
        Me.Label200.Location = New System.Drawing.Point(2, 139)
        Me.Label200.Name = "Label200"
        Me.Label200.Size = New System.Drawing.Size(64, 13)
        Me.Label200.TabIndex = 276
        Me.Label200.Text = "slibe svejsn."
        '
        'Label192
        '
        Me.Label192.AutoSize = True
        Me.Label192.Location = New System.Drawing.Point(86, 79)
        Me.Label192.Name = "Label192"
        Me.Label192.Size = New System.Drawing.Size(66, 13)
        Me.Label192.TabIndex = 270
        Me.Label192.Text = "min./100 stk"
        '
        'Label189
        '
        Me.Label189.Location = New System.Drawing.Point(2, 16)
        Me.Label189.Name = "Label189"
        Me.Label189.Size = New System.Drawing.Size(140, 14)
        Me.Label189.TabIndex = 260
        Me.Label189.Text = "antal svejses�mme pr emne"
        Me.Label189.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tb_numberofwelds
        '
        Me.tb_numberofwelds.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_numberofwelds.Location = New System.Drawing.Point(145, 12)
        Me.tb_numberofwelds.Name = "tb_numberofwelds"
        Me.tb_numberofwelds.Size = New System.Drawing.Size(60, 20)
        Me.tb_numberofwelds.TabIndex = 69
        Me.tb_numberofwelds.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label150
        '
        Me.Label150.Location = New System.Drawing.Point(5, 36)
        Me.Label150.Name = "Label150"
        Me.Label150.Size = New System.Drawing.Size(140, 15)
        Me.Label150.TabIndex = 258
        Me.Label150.Text = "svejsel�ngde pr emne i mm"
        Me.Label150.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tb_weldlength
        '
        Me.tb_weldlength.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_weldlength.Location = New System.Drawing.Point(145, 34)
        Me.tb_weldlength.Name = "tb_weldlength"
        Me.tb_weldlength.Size = New System.Drawing.Size(60, 20)
        Me.tb_weldlength.TabIndex = 70
        Me.tb_weldlength.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label132
        '
        Me.Label132.AutoSize = True
        Me.Label132.Location = New System.Drawing.Point(149, 80)
        Me.Label132.Name = "Label132"
        Me.Label132.Size = New System.Drawing.Size(60, 13)
        Me.Label132.TabIndex = 256
        Me.Label132.Text = "Underkend"
        '
        'lb_grind_weld
        '
        Me.lb_grind_weld.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_grind_weld.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_grind_weld.Location = New System.Drawing.Point(95, 135)
        Me.lb_grind_weld.Name = "lb_grind_weld"
        Me.lb_grind_weld.Size = New System.Drawing.Size(53, 20)
        Me.lb_grind_weld.TabIndex = 255
        Me.lb_grind_weld.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_weld
        '
        Me.lb_weld.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_weld.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_weld.Location = New System.Drawing.Point(95, 115)
        Me.lb_weld.Name = "lb_weld"
        Me.lb_weld.Size = New System.Drawing.Size(53, 20)
        Me.lb_weld.TabIndex = 254
        Me.lb_weld.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_tackweld
        '
        Me.lb_tackweld.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_tackweld.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_tackweld.Location = New System.Drawing.Point(95, 95)
        Me.lb_tackweld.Name = "lb_tackweld"
        Me.lb_tackweld.Size = New System.Drawing.Size(53, 20)
        Me.lb_tackweld.TabIndex = 253
        Me.lb_tackweld.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tb_grind_weld_uk
        '
        Me.tb_grind_weld_uk.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.tb_grind_weld_uk.Location = New System.Drawing.Point(154, 136)
        Me.tb_grind_weld_uk.Name = "tb_grind_weld_uk"
        Me.tb_grind_weld_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_grind_weld_uk.TabIndex = 153
        '
        'tb_weld_uk
        '
        Me.tb_weld_uk.Location = New System.Drawing.Point(154, 116)
        Me.tb_weld_uk.Name = "tb_weld_uk"
        Me.tb_weld_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_weld_uk.TabIndex = 152
        '
        'tb_tackweld_uk
        '
        Me.tb_tackweld_uk.Location = New System.Drawing.Point(154, 96)
        Me.tb_tackweld_uk.Name = "tb_tackweld_uk"
        Me.tb_tackweld_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_tackweld_uk.TabIndex = 151
        '
        'GroupBox15
        '
        Me.GroupBox15.BackColor = System.Drawing.Color.LightGray
        Me.GroupBox15.Controls.Add(Me.Label152)
        Me.GroupBox15.Controls.Add(Me.Label153)
        Me.GroupBox15.Controls.Add(Me.Label154)
        Me.GroupBox15.Controls.Add(Me.Label155)
        Me.GroupBox15.Controls.Add(Me.Label156)
        Me.GroupBox15.Controls.Add(Me.Label157)
        Me.GroupBox15.Controls.Add(Me.Label158)
        Me.GroupBox15.Controls.Add(Me.Label159)
        Me.GroupBox15.Controls.Add(Me.TextBox78)
        Me.GroupBox15.Controls.Add(Me.TextBox79)
        Me.GroupBox15.Controls.Add(Me.TextBox80)
        Me.GroupBox15.Controls.Add(Me.TextBox81)
        Me.GroupBox15.Controls.Add(Me.Label160)
        Me.GroupBox15.Controls.Add(Me.Label161)
        Me.GroupBox15.Controls.Add(Me.Label162)
        Me.GroupBox15.Controls.Add(Me.Label163)
        Me.GroupBox15.Controls.Add(Me.Label164)
        Me.GroupBox15.Controls.Add(Me.Label165)
        Me.GroupBox15.Controls.Add(Me.Label166)
        Me.GroupBox15.Controls.Add(Me.Label167)
        Me.GroupBox15.Controls.Add(Me.Label168)
        Me.GroupBox15.Controls.Add(Me.Label169)
        Me.GroupBox15.Controls.Add(Me.Label170)
        Me.GroupBox15.Controls.Add(Me.TextBox82)
        Me.GroupBox15.Controls.Add(Me.TextBox83)
        Me.GroupBox15.Controls.Add(Me.TextBox84)
        Me.GroupBox15.Controls.Add(Me.Label171)
        Me.GroupBox15.Controls.Add(Me.TextBox85)
        Me.GroupBox15.Controls.Add(Me.TextBox86)
        Me.GroupBox15.Controls.Add(Me.Label172)
        Me.GroupBox15.Controls.Add(Me.TextBox87)
        Me.GroupBox15.Controls.Add(Me.TextBox88)
        Me.GroupBox15.Controls.Add(Me.Label173)
        Me.GroupBox15.Controls.Add(Me.TextBox89)
        Me.GroupBox15.Controls.Add(Me.Label174)
        Me.GroupBox15.Controls.Add(Me.Label175)
        Me.GroupBox15.Controls.Add(Me.TextBox90)
        Me.GroupBox15.Controls.Add(Me.TextBox91)
        Me.GroupBox15.Controls.Add(Me.Label176)
        Me.GroupBox15.Location = New System.Drawing.Point(-267, -61)
        Me.GroupBox15.Name = "GroupBox15"
        Me.GroupBox15.Size = New System.Drawing.Size(249, 365)
        Me.GroupBox15.TabIndex = 223
        Me.GroupBox15.TabStop = False
        Me.GroupBox15.Text = "Gruppe 2"
        '
        'Label152
        '
        Me.Label152.AutoSize = True
        Me.Label152.Location = New System.Drawing.Point(62, 169)
        Me.Label152.Name = "Label152"
        Me.Label152.Size = New System.Drawing.Size(30, 13)
        Me.Label152.TabIndex = 264
        Me.Label152.Text = "antal"
        '
        'Label153
        '
        Me.Label153.AutoSize = True
        Me.Label153.Location = New System.Drawing.Point(62, 188)
        Me.Label153.Name = "Label153"
        Me.Label153.Size = New System.Drawing.Size(30, 13)
        Me.Label153.TabIndex = 263
        Me.Label153.Text = "antal"
        '
        'Label154
        '
        Me.Label154.AutoSize = True
        Me.Label154.Location = New System.Drawing.Point(62, 208)
        Me.Label154.Name = "Label154"
        Me.Label154.Size = New System.Drawing.Size(30, 13)
        Me.Label154.TabIndex = 262
        Me.Label154.Text = "antal"
        '
        'Label155
        '
        Me.Label155.AutoSize = True
        Me.Label155.Location = New System.Drawing.Point(63, 149)
        Me.Label155.Name = "Label155"
        Me.Label155.Size = New System.Drawing.Size(30, 13)
        Me.Label155.TabIndex = 261
        Me.Label155.Text = "antal"
        '
        'Label156
        '
        Me.Label156.AutoSize = True
        Me.Label156.Location = New System.Drawing.Point(3, 149)
        Me.Label156.Name = "Label156"
        Me.Label156.Size = New System.Drawing.Size(63, 13)
        Me.Label156.TabIndex = 257
        Me.Label156.Text = "Unders�nk"
        '
        'Label157
        '
        Me.Label157.AutoSize = True
        Me.Label157.Location = New System.Drawing.Point(3, 169)
        Me.Label157.Name = "Label157"
        Me.Label157.Size = New System.Drawing.Size(41, 13)
        Me.Label157.TabIndex = 258
        Me.Label157.Text = "Gevind"
        '
        'Label158
        '
        Me.Label158.AutoSize = True
        Me.Label158.Location = New System.Drawing.Point(3, 209)
        Me.Label158.Name = "Label158"
        Me.Label158.Size = New System.Drawing.Size(55, 13)
        Me.Label158.TabIndex = 260
        Me.Label158.Text = "Boltesvejs"
        '
        'Label159
        '
        Me.Label159.AutoSize = True
        Me.Label159.Location = New System.Drawing.Point(3, 189)
        Me.Label159.Name = "Label159"
        Me.Label159.Size = New System.Drawing.Size(56, 13)
        Me.Label159.TabIndex = 259
        Me.Label159.Text = "Presm�trik"
        '
        'TextBox78
        '
        Me.TextBox78.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.TextBox78.Location = New System.Drawing.Point(95, 205)
        Me.TextBox78.Name = "TextBox78"
        Me.TextBox78.Size = New System.Drawing.Size(31, 20)
        Me.TextBox78.TabIndex = 256
        '
        'TextBox79
        '
        Me.TextBox79.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.TextBox79.Location = New System.Drawing.Point(95, 185)
        Me.TextBox79.Name = "TextBox79"
        Me.TextBox79.Size = New System.Drawing.Size(31, 20)
        Me.TextBox79.TabIndex = 255
        '
        'TextBox80
        '
        Me.TextBox80.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.TextBox80.Location = New System.Drawing.Point(95, 165)
        Me.TextBox80.Name = "TextBox80"
        Me.TextBox80.Size = New System.Drawing.Size(31, 20)
        Me.TextBox80.TabIndex = 254
        '
        'TextBox81
        '
        Me.TextBox81.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.TextBox81.Location = New System.Drawing.Point(95, 145)
        Me.TextBox81.Name = "TextBox81"
        Me.TextBox81.Size = New System.Drawing.Size(31, 20)
        Me.TextBox81.TabIndex = 253
        '
        'Label160
        '
        Me.Label160.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label160.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label160.Location = New System.Drawing.Point(132, 45)
        Me.Label160.Name = "Label160"
        Me.Label160.Size = New System.Drawing.Size(53, 20)
        Me.Label160.TabIndex = 252
        '
        'Label161
        '
        Me.Label161.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label161.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label161.Location = New System.Drawing.Point(132, 25)
        Me.Label161.Name = "Label161"
        Me.Label161.Size = New System.Drawing.Size(53, 20)
        Me.Label161.TabIndex = 251
        '
        'Label162
        '
        Me.Label162.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label162.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label162.Location = New System.Drawing.Point(132, 125)
        Me.Label162.Name = "Label162"
        Me.Label162.Size = New System.Drawing.Size(53, 20)
        Me.Label162.TabIndex = 250
        '
        'Label163
        '
        Me.Label163.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label163.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label163.Location = New System.Drawing.Point(132, 105)
        Me.Label163.Name = "Label163"
        Me.Label163.Size = New System.Drawing.Size(53, 20)
        Me.Label163.TabIndex = 249
        '
        'Label164
        '
        Me.Label164.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label164.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label164.Location = New System.Drawing.Point(132, 85)
        Me.Label164.Name = "Label164"
        Me.Label164.Size = New System.Drawing.Size(53, 20)
        Me.Label164.TabIndex = 248
        '
        'Label165
        '
        Me.Label165.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label165.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label165.Location = New System.Drawing.Point(132, 65)
        Me.Label165.Name = "Label165"
        Me.Label165.Size = New System.Drawing.Size(53, 20)
        Me.Label165.TabIndex = 247
        '
        'Label166
        '
        Me.Label166.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label166.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label166.Location = New System.Drawing.Point(132, 205)
        Me.Label166.Name = "Label166"
        Me.Label166.Size = New System.Drawing.Size(53, 20)
        Me.Label166.TabIndex = 246
        '
        'Label167
        '
        Me.Label167.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label167.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label167.Location = New System.Drawing.Point(132, 185)
        Me.Label167.Name = "Label167"
        Me.Label167.Size = New System.Drawing.Size(53, 20)
        Me.Label167.TabIndex = 245
        '
        'Label168
        '
        Me.Label168.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label168.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label168.Location = New System.Drawing.Point(132, 165)
        Me.Label168.Name = "Label168"
        Me.Label168.Size = New System.Drawing.Size(53, 20)
        Me.Label168.TabIndex = 244
        '
        'Label169
        '
        Me.Label169.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label169.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label169.Location = New System.Drawing.Point(132, 145)
        Me.Label169.Name = "Label169"
        Me.Label169.Size = New System.Drawing.Size(53, 20)
        Me.Label169.TabIndex = 243
        '
        'Label170
        '
        Me.Label170.AutoSize = True
        Me.Label170.Location = New System.Drawing.Point(188, 9)
        Me.Label170.Name = "Label170"
        Me.Label170.Size = New System.Drawing.Size(60, 13)
        Me.Label170.TabIndex = 242
        Me.Label170.Text = "Underkend"
        '
        'TextBox82
        '
        Me.TextBox82.Location = New System.Drawing.Point(190, 85)
        Me.TextBox82.Name = "TextBox82"
        Me.TextBox82.Size = New System.Drawing.Size(53, 20)
        Me.TextBox82.TabIndex = 44
        '
        'TextBox83
        '
        Me.TextBox83.Location = New System.Drawing.Point(190, 205)
        Me.TextBox83.Name = "TextBox83"
        Me.TextBox83.Size = New System.Drawing.Size(53, 20)
        Me.TextBox83.TabIndex = 60
        '
        'TextBox84
        '
        Me.TextBox84.Location = New System.Drawing.Point(190, 25)
        Me.TextBox84.Name = "TextBox84"
        Me.TextBox84.Size = New System.Drawing.Size(53, 20)
        Me.TextBox84.TabIndex = 41
        '
        'Label171
        '
        Me.Label171.AutoSize = True
        Me.Label171.Location = New System.Drawing.Point(4, 28)
        Me.Label171.Name = "Label171"
        Me.Label171.Size = New System.Drawing.Size(47, 13)
        Me.Label171.TabIndex = 35
        Me.Label171.Text = "Afgrat/fil"
        '
        'TextBox85
        '
        Me.TextBox85.Location = New System.Drawing.Point(190, 185)
        Me.TextBox85.Name = "TextBox85"
        Me.TextBox85.Size = New System.Drawing.Size(53, 20)
        Me.TextBox85.TabIndex = 57
        '
        'TextBox86
        '
        Me.TextBox86.Location = New System.Drawing.Point(190, 45)
        Me.TextBox86.Name = "TextBox86"
        Me.TextBox86.Size = New System.Drawing.Size(53, 20)
        Me.TextBox86.TabIndex = 42
        '
        'Label172
        '
        Me.Label172.AutoSize = True
        Me.Label172.Location = New System.Drawing.Point(4, 48)
        Me.Label172.Name = "Label172"
        Me.Label172.Size = New System.Drawing.Size(77, 13)
        Me.Label172.TabIndex = 38
        Me.Label172.Text = "Grindingmaster"
        '
        'TextBox87
        '
        Me.TextBox87.Location = New System.Drawing.Point(190, 165)
        Me.TextBox87.Name = "TextBox87"
        Me.TextBox87.Size = New System.Drawing.Size(53, 20)
        Me.TextBox87.TabIndex = 54
        '
        'TextBox88
        '
        Me.TextBox88.Location = New System.Drawing.Point(190, 65)
        Me.TextBox88.Name = "TextBox88"
        Me.TextBox88.Size = New System.Drawing.Size(53, 20)
        Me.TextBox88.TabIndex = 43
        '
        'Label173
        '
        Me.Label173.AutoSize = True
        Me.Label173.Location = New System.Drawing.Point(4, 68)
        Me.Label173.Name = "Label173"
        Me.Label173.Size = New System.Drawing.Size(84, 13)
        Me.Label173.TabIndex = 41
        Me.Label173.Text = "B�rsteafgratning"
        '
        'TextBox89
        '
        Me.TextBox89.Location = New System.Drawing.Point(190, 145)
        Me.TextBox89.Name = "TextBox89"
        Me.TextBox89.Size = New System.Drawing.Size(53, 20)
        Me.TextBox89.TabIndex = 51
        '
        'Label174
        '
        Me.Label174.AutoSize = True
        Me.Label174.Location = New System.Drawing.Point(4, 88)
        Me.Label174.Name = "Label174"
        Me.Label174.Size = New System.Drawing.Size(89, 13)
        Me.Label174.TabIndex = 44
        Me.Label174.Text = "Vibrationsafgratn."
        '
        'Label175
        '
        Me.Label175.AutoSize = True
        Me.Label175.Location = New System.Drawing.Point(4, 128)
        Me.Label175.Name = "Label175"
        Me.Label175.Size = New System.Drawing.Size(71, 13)
        Me.Label175.TabIndex = 50
        Me.Label175.Text = "Stans manuel"
        '
        'TextBox90
        '
        Me.TextBox90.Location = New System.Drawing.Point(190, 125)
        Me.TextBox90.Name = "TextBox90"
        Me.TextBox90.Size = New System.Drawing.Size(53, 20)
        Me.TextBox90.TabIndex = 46
        '
        'TextBox91
        '
        Me.TextBox91.Location = New System.Drawing.Point(190, 105)
        Me.TextBox91.Name = "TextBox91"
        Me.TextBox91.Size = New System.Drawing.Size(53, 20)
        Me.TextBox91.TabIndex = 45
        '
        'Label176
        '
        Me.Label176.AutoSize = True
        Me.Label176.Location = New System.Drawing.Point(4, 108)
        Me.Label176.Name = "Label176"
        Me.Label176.Size = New System.Drawing.Size(72, 13)
        Me.Label176.TabIndex = 47
        Me.Label176.Text = "Rettemaskine"
        '
        'gb_gruppe5
        '
        Me.gb_gruppe5.BackColor = System.Drawing.Color.WhiteSmoke
        Me.gb_gruppe5.Controls.Add(Me.Label63)
        Me.gb_gruppe5.Controls.Add(Me.Label137)
        Me.gb_gruppe5.Controls.Add(Me.lb_kontrol)
        Me.gb_gruppe5.Controls.Add(Me.tb_kontrol_uk)
        Me.gb_gruppe5.Controls.Add(Me.Label133)
        Me.gb_gruppe5.Controls.Add(Me.Label134)
        Me.gb_gruppe5.Controls.Add(Me.lb_kontor)
        Me.gb_gruppe5.Controls.Add(Me.tb_kontor_uk)
        Me.gb_gruppe5.Location = New System.Drawing.Point(775, 537)
        Me.gb_gruppe5.Name = "gb_gruppe5"
        Me.gb_gruppe5.Size = New System.Drawing.Size(210, 72)
        Me.gb_gruppe5.TabIndex = 226
        Me.gb_gruppe5.TabStop = False
        Me.gb_gruppe5.Text = "Gruppe 5"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(97, 7)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(44, 13)
        Me.Label63.TabIndex = 249
        Me.Label63.Text = "minutter"
        '
        'Label137
        '
        Me.Label137.Location = New System.Drawing.Point(36, 44)
        Me.Label137.Name = "Label137"
        Me.Label137.Size = New System.Drawing.Size(58, 20)
        Me.Label137.TabIndex = 248
        Me.Label137.Text = "Kontrol"
        Me.Label137.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_kontrol
        '
        Me.lb_kontrol.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_kontrol.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_kontrol.Location = New System.Drawing.Point(94, 46)
        Me.lb_kontrol.Name = "lb_kontrol"
        Me.lb_kontrol.Size = New System.Drawing.Size(53, 20)
        Me.lb_kontrol.TabIndex = 247
        Me.lb_kontrol.Text = "60"
        Me.lb_kontrol.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tb_kontrol_uk
        '
        Me.tb_kontrol_uk.Location = New System.Drawing.Point(153, 46)
        Me.tb_kontrol_uk.Name = "tb_kontrol_uk"
        Me.tb_kontrol_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_kontrol_uk.TabIndex = 77
        '
        'Label133
        '
        Me.Label133.AutoSize = True
        Me.Label133.Location = New System.Drawing.Point(149, 7)
        Me.Label133.Name = "Label133"
        Me.Label133.Size = New System.Drawing.Size(60, 13)
        Me.Label133.TabIndex = 245
        Me.Label133.Text = "Underkend"
        '
        'Label134
        '
        Me.Label134.Location = New System.Drawing.Point(36, 23)
        Me.Label134.Name = "Label134"
        Me.Label134.Size = New System.Drawing.Size(58, 20)
        Me.Label134.TabIndex = 244
        Me.Label134.Text = "Kontor"
        Me.Label134.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_kontor
        '
        Me.lb_kontor.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_kontor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_kontor.Location = New System.Drawing.Point(94, 23)
        Me.lb_kontor.Name = "lb_kontor"
        Me.lb_kontor.Size = New System.Drawing.Size(53, 20)
        Me.lb_kontor.TabIndex = 243
        Me.lb_kontor.Text = "60"
        Me.lb_kontor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tb_kontor_uk
        '
        Me.tb_kontor_uk.Location = New System.Drawing.Point(153, 23)
        Me.tb_kontor_uk.Name = "tb_kontor_uk"
        Me.tb_kontor_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_kontor_uk.TabIndex = 76
        '
        'gb_admin
        '
        Me.gb_admin.BackColor = System.Drawing.Color.WhiteSmoke
        Me.gb_admin.Controls.Add(Me.tb_timesats_C)
        Me.gb_admin.Controls.Add(Me.tb_timesats_B)
        Me.gb_admin.Controls.Add(Me.Label58)
        Me.gb_admin.Controls.Add(Me.tb_timesats_D)
        Me.gb_admin.Controls.Add(Me.Label11)
        Me.gb_admin.Controls.Add(Me.Label43)
        Me.gb_admin.Controls.Add(Me.tb_timesats_mand)
        Me.gb_admin.Controls.Add(Me.Label87)
        Me.gb_admin.Controls.Add(Me.Label40)
        Me.gb_admin.Controls.Add(Me.lb_operat�r)
        Me.gb_admin.Controls.Add(Me.Label68)
        Me.gb_admin.Controls.Add(Me.Label12)
        Me.gb_admin.Controls.Add(Me.lb_dato)
        Me.gb_admin.Controls.Add(Me.Label69)
        Me.gb_admin.Controls.Add(Me.lb_pos_ht)
        Me.gb_admin.Controls.Add(Me.Label88)
        Me.gb_admin.Controls.Add(Me.lb_hovedtegning)
        Me.gb_admin.Location = New System.Drawing.Point(775, 608)
        Me.gb_admin.Name = "gb_admin"
        Me.gb_admin.Size = New System.Drawing.Size(210, 148)
        Me.gb_admin.TabIndex = 227
        Me.gb_admin.TabStop = False
        Me.gb_admin.Text = "Admin"
        '
        'tb_timesats_C
        '
        Me.tb_timesats_C.Location = New System.Drawing.Point(157, 124)
        Me.tb_timesats_C.Name = "tb_timesats_C"
        Me.tb_timesats_C.Size = New System.Drawing.Size(50, 20)
        Me.tb_timesats_C.TabIndex = 275
        Me.tb_timesats_C.Text = "1900"
        Me.tb_timesats_C.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_timesats_B
        '
        Me.tb_timesats_B.Location = New System.Drawing.Point(102, 124)
        Me.tb_timesats_B.Name = "tb_timesats_B"
        Me.tb_timesats_B.Size = New System.Drawing.Size(50, 20)
        Me.tb_timesats_B.TabIndex = 272
        Me.tb_timesats_B.Text = "1490"
        Me.tb_timesats_B.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(163, 108)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(39, 13)
        Me.Label58.TabIndex = 276
        Me.Label58.Text = "C-laser"
        '
        'tb_timesats_D
        '
        Me.tb_timesats_D.Location = New System.Drawing.Point(53, 124)
        Me.tb_timesats_D.Name = "tb_timesats_D"
        Me.tb_timesats_D.Size = New System.Drawing.Size(45, 20)
        Me.tb_timesats_D.TabIndex = 269
        Me.tb_timesats_D.Text = "850"
        Me.tb_timesats_D.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(72, 96)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(65, 13)
        Me.Label11.TabIndex = 268
        Me.Label11.Text = "Timesats Kr."
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(105, 108)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(45, 13)
        Me.Label43.TabIndex = 273
        Me.Label43.Text = "B-kombi"
        '
        'tb_timesats_mand
        '
        Me.tb_timesats_mand.Location = New System.Drawing.Point(3, 124)
        Me.tb_timesats_mand.Name = "tb_timesats_mand"
        Me.tb_timesats_mand.Size = New System.Drawing.Size(45, 20)
        Me.tb_timesats_mand.TabIndex = 266
        Me.tb_timesats_mand.Text = "475"
        Me.tb_timesats_mand.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.Location = New System.Drawing.Point(14, 77)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(111, 13)
        Me.Label87.TabIndex = 235
        Me.Label87.Text = "Pos. p� hovedtegning"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(53, 108)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(47, 13)
        Me.Label40.TabIndex = 270
        Me.Label40.Text = "D-trumpf"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(11, 108)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(33, 13)
        Me.Label12.TabIndex = 267
        Me.Label12.Text = "mand"
        '
        'lb_pos_ht
        '
        Me.lb_pos_ht.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_pos_ht.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_pos_ht.Location = New System.Drawing.Point(129, 75)
        Me.lb_pos_ht.Name = "lb_pos_ht"
        Me.lb_pos_ht.Size = New System.Drawing.Size(74, 20)
        Me.lb_pos_ht.TabIndex = 233
        '
        'Label88
        '
        Me.Label88.AutoSize = True
        Me.Label88.Location = New System.Drawing.Point(-1, 56)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(74, 13)
        Me.Label88.TabIndex = 234
        Me.Label88.Text = "Hovedtegning"
        '
        'lb_hovedtegning
        '
        Me.lb_hovedtegning.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_hovedtegning.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_hovedtegning.Location = New System.Drawing.Point(75, 55)
        Me.lb_hovedtegning.Name = "lb_hovedtegning"
        Me.lb_hovedtegning.Size = New System.Drawing.Size(128, 20)
        Me.lb_hovedtegning.TabIndex = 232
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(150, 139)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(35, 13)
        Me.Label10.TabIndex = 265
        Me.Label10.Text = "1 til 6"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(8, 101)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(83, 13)
        Me.Label7.TabIndex = 262
        Me.Label7.Text = "Materialegruppe"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(7, 140)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(77, 13)
        Me.Label6.TabIndex = 261
        Me.Label6.Text = "Sv�rhedsgrad"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(8, 81)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(75, 13)
        Me.Label5.TabIndex = 260
        Me.Label5.Text = "Modulst�rrelse"
        '
        'gb_overfladebeh
        '
        Me.gb_overfladebeh.BackColor = System.Drawing.Color.Beige
        Me.gb_overfladebeh.Controls.Add(Me.Label205)
        Me.gb_overfladebeh.Controls.Add(Me.cb_1side_2)
        Me.gb_overfladebeh.Controls.Add(Me.cb_1side_3)
        Me.gb_overfladebeh.Controls.Add(Me.cb_1side_1)
        Me.gb_overfladebeh.Controls.Add(Me.Label42)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_pris2_uk)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_pris3_uk)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_pris1_uk)
        Me.gb_overfladebeh.Controls.Add(Me.cb_overfl_beh4)
        Me.gb_overfladebeh.Controls.Add(Me.cb_overfl_beh3)
        Me.gb_overfladebeh.Controls.Add(Me.cb_overfl_beh2)
        Me.gb_overfladebeh.Controls.Add(Me.cb_overfl_beh1)
        Me.gb_overfladebeh.Controls.Add(Me.cb_overfl_leverand�r4)
        Me.gb_overfladebeh.Controls.Add(Me.cb_overfl_leverand�r3)
        Me.gb_overfladebeh.Controls.Add(Me.cb_overfl_leverand�r2)
        Me.gb_overfladebeh.Controls.Add(Me.cb_overfl_leverand�r1)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_pris100_4)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_avance4)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_pris4)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_afd�k4)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_opstart4)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_pris100_3)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_avance3)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_pris3)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_afd�k3)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_opstart3)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_pris100_2)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_avance2)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_pris2)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_afd�k2)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_opstart2)
        Me.gb_overfladebeh.Controls.Add(Me.Label140)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_pris100_1)
        Me.gb_overfladebeh.Controls.Add(Me.Label130)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_avance1)
        Me.gb_overfladebeh.Controls.Add(Me.Label67)
        Me.gb_overfladebeh.Controls.Add(Me.Label66)
        Me.gb_overfladebeh.Controls.Add(Me.Label65)
        Me.gb_overfladebeh.Controls.Add(Me.Label62)
        Me.gb_overfladebeh.Controls.Add(Me.Label61)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_pris1)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_afd�k1)
        Me.gb_overfladebeh.Controls.Add(Me.tb_overfl_opstart1)
        Me.gb_overfladebeh.Location = New System.Drawing.Point(8, 760)
        Me.gb_overfladebeh.Name = "gb_overfladebeh"
        Me.gb_overfladebeh.Size = New System.Drawing.Size(978, 109)
        Me.gb_overfladebeh.TabIndex = 228
        Me.gb_overfladebeh.TabStop = False
        '
        'Label205
        '
        Me.Label205.AutoSize = True
        Me.Label205.Location = New System.Drawing.Point(480, 6)
        Me.Label205.Name = "Label205"
        Me.Label205.Size = New System.Drawing.Size(35, 13)
        Me.Label205.TabIndex = 308
        Me.Label205.Text = "1 side"
        '
        'cb_1side_2
        '
        Me.cb_1side_2.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_1side_2.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cb_1side_2.Location = New System.Drawing.Point(491, 42)
        Me.cb_1side_2.Name = "cb_1side_2"
        Me.cb_1side_2.Size = New System.Drawing.Size(16, 19)
        Me.cb_1side_2.TabIndex = 305
        Me.cb_1side_2.UseVisualStyleBackColor = False
        '
        'cb_1side_3
        '
        Me.cb_1side_3.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_1side_3.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cb_1side_3.Location = New System.Drawing.Point(491, 62)
        Me.cb_1side_3.Name = "cb_1side_3"
        Me.cb_1side_3.Size = New System.Drawing.Size(16, 19)
        Me.cb_1side_3.TabIndex = 306
        Me.cb_1side_3.UseVisualStyleBackColor = False
        '
        'cb_1side_1
        '
        Me.cb_1side_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_1side_1.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cb_1side_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cb_1side_1.Location = New System.Drawing.Point(491, 20)
        Me.cb_1side_1.Name = "cb_1side_1"
        Me.cb_1side_1.Size = New System.Drawing.Size(16, 19)
        Me.cb_1side_1.TabIndex = 304
        Me.cb_1side_1.UseVisualStyleBackColor = False
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(764, 7)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(60, 13)
        Me.Label42.TabIndex = 303
        Me.Label42.Text = "Underkend"
        '
        'tb_overfl_pris2_uk
        '
        Me.tb_overfl_pris2_uk.Location = New System.Drawing.Point(760, 40)
        Me.tb_overfl_pris2_uk.Name = "tb_overfl_pris2_uk"
        Me.tb_overfl_pris2_uk.Size = New System.Drawing.Size(73, 20)
        Me.tb_overfl_pris2_uk.TabIndex = 302
        '
        'tb_overfl_pris3_uk
        '
        Me.tb_overfl_pris3_uk.Location = New System.Drawing.Point(760, 59)
        Me.tb_overfl_pris3_uk.Name = "tb_overfl_pris3_uk"
        Me.tb_overfl_pris3_uk.Size = New System.Drawing.Size(73, 20)
        Me.tb_overfl_pris3_uk.TabIndex = 301
        '
        'tb_overfl_pris1_uk
        '
        Me.tb_overfl_pris1_uk.Location = New System.Drawing.Point(760, 21)
        Me.tb_overfl_pris1_uk.Name = "tb_overfl_pris1_uk"
        Me.tb_overfl_pris1_uk.Size = New System.Drawing.Size(73, 20)
        Me.tb_overfl_pris1_uk.TabIndex = 299
        '
        'cb_overfl_beh4
        '
        Me.cb_overfl_beh4.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_overfl_beh4.FormattingEnabled = True
        Me.cb_overfl_beh4.Location = New System.Drawing.Point(7, 83)
        Me.cb_overfl_beh4.Name = "cb_overfl_beh4"
        Me.cb_overfl_beh4.Size = New System.Drawing.Size(290, 21)
        Me.cb_overfl_beh4.TabIndex = 81
        '
        'cb_overfl_beh3
        '
        Me.cb_overfl_beh3.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_overfl_beh3.FormattingEnabled = True
        Me.cb_overfl_beh3.Location = New System.Drawing.Point(7, 59)
        Me.cb_overfl_beh3.Name = "cb_overfl_beh3"
        Me.cb_overfl_beh3.Size = New System.Drawing.Size(290, 21)
        Me.cb_overfl_beh3.TabIndex = 80
        '
        'cb_overfl_beh2
        '
        Me.cb_overfl_beh2.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_overfl_beh2.FormattingEnabled = True
        Me.cb_overfl_beh2.Location = New System.Drawing.Point(7, 40)
        Me.cb_overfl_beh2.Name = "cb_overfl_beh2"
        Me.cb_overfl_beh2.Size = New System.Drawing.Size(290, 21)
        Me.cb_overfl_beh2.TabIndex = 79
        '
        'cb_overfl_beh1
        '
        Me.cb_overfl_beh1.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_overfl_beh1.FormattingEnabled = True
        Me.cb_overfl_beh1.Location = New System.Drawing.Point(7, 21)
        Me.cb_overfl_beh1.Name = "cb_overfl_beh1"
        Me.cb_overfl_beh1.Size = New System.Drawing.Size(290, 21)
        Me.cb_overfl_beh1.TabIndex = 78
        '
        'cb_overfl_leverand�r4
        '
        Me.cb_overfl_leverand�r4.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_overfl_leverand�r4.FormattingEnabled = True
        Me.cb_overfl_leverand�r4.Location = New System.Drawing.Point(297, 83)
        Me.cb_overfl_leverand�r4.Name = "cb_overfl_leverand�r4"
        Me.cb_overfl_leverand�r4.Size = New System.Drawing.Size(191, 21)
        Me.cb_overfl_leverand�r4.TabIndex = 294
        '
        'cb_overfl_leverand�r3
        '
        Me.cb_overfl_leverand�r3.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_overfl_leverand�r3.FormattingEnabled = True
        Me.cb_overfl_leverand�r3.Location = New System.Drawing.Point(297, 59)
        Me.cb_overfl_leverand�r3.Name = "cb_overfl_leverand�r3"
        Me.cb_overfl_leverand�r3.Size = New System.Drawing.Size(191, 21)
        Me.cb_overfl_leverand�r3.TabIndex = 293
        '
        'cb_overfl_leverand�r2
        '
        Me.cb_overfl_leverand�r2.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_overfl_leverand�r2.FormattingEnabled = True
        Me.cb_overfl_leverand�r2.Location = New System.Drawing.Point(297, 40)
        Me.cb_overfl_leverand�r2.Name = "cb_overfl_leverand�r2"
        Me.cb_overfl_leverand�r2.Size = New System.Drawing.Size(191, 21)
        Me.cb_overfl_leverand�r2.TabIndex = 292
        '
        'cb_overfl_leverand�r1
        '
        Me.cb_overfl_leverand�r1.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_overfl_leverand�r1.FormattingEnabled = True
        Me.cb_overfl_leverand�r1.Location = New System.Drawing.Point(297, 21)
        Me.cb_overfl_leverand�r1.Name = "cb_overfl_leverand�r1"
        Me.cb_overfl_leverand�r1.Size = New System.Drawing.Size(191, 21)
        Me.cb_overfl_leverand�r1.TabIndex = 291
        '
        'tb_overfl_pris100_4
        '
        Me.tb_overfl_pris100_4.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.tb_overfl_pris100_4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tb_overfl_pris100_4.Location = New System.Drawing.Point(895, 83)
        Me.tb_overfl_pris100_4.Name = "tb_overfl_pris100_4"
        Me.tb_overfl_pris100_4.Size = New System.Drawing.Size(70, 20)
        Me.tb_overfl_pris100_4.TabIndex = 290
        Me.tb_overfl_pris100_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tb_overfl_avance4
        '
        Me.tb_overfl_avance4.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_overfl_avance4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_overfl_avance4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.tb_overfl_avance4.Location = New System.Drawing.Point(840, 83)
        Me.tb_overfl_avance4.Name = "tb_overfl_avance4"
        Me.tb_overfl_avance4.Size = New System.Drawing.Size(50, 20)
        Me.tb_overfl_avance4.TabIndex = 289
        Me.tb_overfl_avance4.Text = "15"
        Me.tb_overfl_avance4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_overfl_pris4
        '
        Me.tb_overfl_pris4.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_overfl_pris4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.tb_overfl_pris4.Location = New System.Drawing.Point(677, 83)
        Me.tb_overfl_pris4.Name = "tb_overfl_pris4"
        Me.tb_overfl_pris4.Size = New System.Drawing.Size(81, 20)
        Me.tb_overfl_pris4.TabIndex = 288
        Me.tb_overfl_pris4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_overfl_afd�k4
        '
        Me.tb_overfl_afd�k4.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_overfl_afd�k4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.tb_overfl_afd�k4.Location = New System.Drawing.Point(595, 83)
        Me.tb_overfl_afd�k4.Name = "tb_overfl_afd�k4"
        Me.tb_overfl_afd�k4.Size = New System.Drawing.Size(81, 20)
        Me.tb_overfl_afd�k4.TabIndex = 287
        Me.tb_overfl_afd�k4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_overfl_opstart4
        '
        Me.tb_overfl_opstart4.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_overfl_opstart4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.tb_overfl_opstart4.Location = New System.Drawing.Point(513, 83)
        Me.tb_overfl_opstart4.Name = "tb_overfl_opstart4"
        Me.tb_overfl_opstart4.Size = New System.Drawing.Size(81, 20)
        Me.tb_overfl_opstart4.TabIndex = 286
        Me.tb_overfl_opstart4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_overfl_pris100_3
        '
        Me.tb_overfl_pris100_3.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.tb_overfl_pris100_3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tb_overfl_pris100_3.Location = New System.Drawing.Point(895, 59)
        Me.tb_overfl_pris100_3.Name = "tb_overfl_pris100_3"
        Me.tb_overfl_pris100_3.Size = New System.Drawing.Size(70, 20)
        Me.tb_overfl_pris100_3.TabIndex = 283
        Me.tb_overfl_pris100_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tb_overfl_avance3
        '
        Me.tb_overfl_avance3.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_overfl_avance3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_overfl_avance3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.tb_overfl_avance3.Location = New System.Drawing.Point(840, 59)
        Me.tb_overfl_avance3.Name = "tb_overfl_avance3"
        Me.tb_overfl_avance3.Size = New System.Drawing.Size(50, 20)
        Me.tb_overfl_avance3.TabIndex = 282
        Me.tb_overfl_avance3.Text = "15"
        Me.tb_overfl_avance3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_overfl_pris3
        '
        Me.tb_overfl_pris3.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.tb_overfl_pris3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.tb_overfl_pris3.Location = New System.Drawing.Point(677, 59)
        Me.tb_overfl_pris3.Name = "tb_overfl_pris3"
        Me.tb_overfl_pris3.ReadOnly = True
        Me.tb_overfl_pris3.Size = New System.Drawing.Size(81, 20)
        Me.tb_overfl_pris3.TabIndex = 281
        Me.tb_overfl_pris3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_overfl_afd�k3
        '
        Me.tb_overfl_afd�k3.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.tb_overfl_afd�k3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.tb_overfl_afd�k3.Location = New System.Drawing.Point(595, 59)
        Me.tb_overfl_afd�k3.Name = "tb_overfl_afd�k3"
        Me.tb_overfl_afd�k3.Size = New System.Drawing.Size(81, 20)
        Me.tb_overfl_afd�k3.TabIndex = 280
        Me.tb_overfl_afd�k3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_overfl_opstart3
        '
        Me.tb_overfl_opstart3.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.tb_overfl_opstart3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.tb_overfl_opstart3.Location = New System.Drawing.Point(513, 59)
        Me.tb_overfl_opstart3.Name = "tb_overfl_opstart3"
        Me.tb_overfl_opstart3.Size = New System.Drawing.Size(81, 20)
        Me.tb_overfl_opstart3.TabIndex = 279
        Me.tb_overfl_opstart3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_overfl_pris100_2
        '
        Me.tb_overfl_pris100_2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.tb_overfl_pris100_2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tb_overfl_pris100_2.Location = New System.Drawing.Point(895, 40)
        Me.tb_overfl_pris100_2.Name = "tb_overfl_pris100_2"
        Me.tb_overfl_pris100_2.Size = New System.Drawing.Size(70, 20)
        Me.tb_overfl_pris100_2.TabIndex = 276
        Me.tb_overfl_pris100_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tb_overfl_avance2
        '
        Me.tb_overfl_avance2.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_overfl_avance2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_overfl_avance2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.tb_overfl_avance2.Location = New System.Drawing.Point(840, 40)
        Me.tb_overfl_avance2.Name = "tb_overfl_avance2"
        Me.tb_overfl_avance2.Size = New System.Drawing.Size(50, 20)
        Me.tb_overfl_avance2.TabIndex = 275
        Me.tb_overfl_avance2.Text = "15"
        Me.tb_overfl_avance2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_overfl_pris2
        '
        Me.tb_overfl_pris2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.tb_overfl_pris2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.tb_overfl_pris2.Location = New System.Drawing.Point(677, 40)
        Me.tb_overfl_pris2.Name = "tb_overfl_pris2"
        Me.tb_overfl_pris2.ReadOnly = True
        Me.tb_overfl_pris2.Size = New System.Drawing.Size(81, 20)
        Me.tb_overfl_pris2.TabIndex = 274
        Me.tb_overfl_pris2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_overfl_afd�k2
        '
        Me.tb_overfl_afd�k2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.tb_overfl_afd�k2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.tb_overfl_afd�k2.Location = New System.Drawing.Point(595, 40)
        Me.tb_overfl_afd�k2.Name = "tb_overfl_afd�k2"
        Me.tb_overfl_afd�k2.Size = New System.Drawing.Size(81, 20)
        Me.tb_overfl_afd�k2.TabIndex = 273
        Me.tb_overfl_afd�k2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_overfl_opstart2
        '
        Me.tb_overfl_opstart2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.tb_overfl_opstart2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.tb_overfl_opstart2.Location = New System.Drawing.Point(513, 40)
        Me.tb_overfl_opstart2.Name = "tb_overfl_opstart2"
        Me.tb_overfl_opstart2.Size = New System.Drawing.Size(81, 20)
        Me.tb_overfl_opstart2.TabIndex = 272
        Me.tb_overfl_opstart2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label140
        '
        Me.Label140.AutoSize = True
        Me.Label140.Location = New System.Drawing.Point(895, 6)
        Me.Label140.Name = "Label140"
        Me.Label140.Size = New System.Drawing.Size(75, 13)
        Me.Label140.TabIndex = 269
        Me.Label140.Text = "kr stk ved 100"
        '
        'tb_overfl_pris100_1
        '
        Me.tb_overfl_pris100_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.tb_overfl_pris100_1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tb_overfl_pris100_1.Location = New System.Drawing.Point(895, 21)
        Me.tb_overfl_pris100_1.Name = "tb_overfl_pris100_1"
        Me.tb_overfl_pris100_1.Size = New System.Drawing.Size(70, 20)
        Me.tb_overfl_pris100_1.TabIndex = 268
        Me.tb_overfl_pris100_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label130
        '
        Me.Label130.AutoSize = True
        Me.Label130.Location = New System.Drawing.Point(840, 6)
        Me.Label130.Name = "Label130"
        Me.Label130.Size = New System.Drawing.Size(55, 13)
        Me.Label130.TabIndex = 267
        Me.Label130.Text = "Avance %"
        '
        'tb_overfl_avance1
        '
        Me.tb_overfl_avance1.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_overfl_avance1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_overfl_avance1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.tb_overfl_avance1.Location = New System.Drawing.Point(840, 21)
        Me.tb_overfl_avance1.Name = "tb_overfl_avance1"
        Me.tb_overfl_avance1.Size = New System.Drawing.Size(50, 20)
        Me.tb_overfl_avance1.TabIndex = 266
        Me.tb_overfl_avance1.Text = "15"
        Me.tb_overfl_avance1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Location = New System.Drawing.Point(689, 7)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(59, 13)
        Me.Label67.TabIndex = 265
        Me.Label67.Text = "Pris Kr./stk"
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Location = New System.Drawing.Point(594, 7)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(83, 13)
        Me.Label66.TabIndex = 264
        Me.Label66.Text = "Afd�kn. Kr./stk"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(523, 7)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(57, 13)
        Me.Label65.TabIndex = 263
        Me.Label65.Text = "Opstart Kr."
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(90, 8)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(141, 13)
        Me.Label62.TabIndex = 262
        Me.Label62.Text = "OVERFLADEBEHANDLING"
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(370, 8)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(81, 13)
        Me.Label61.TabIndex = 261
        Me.Label61.Text = "LEVERAND�R"
        '
        'tb_overfl_pris1
        '
        Me.tb_overfl_pris1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.tb_overfl_pris1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.tb_overfl_pris1.Location = New System.Drawing.Point(677, 21)
        Me.tb_overfl_pris1.Name = "tb_overfl_pris1"
        Me.tb_overfl_pris1.ReadOnly = True
        Me.tb_overfl_pris1.Size = New System.Drawing.Size(81, 20)
        Me.tb_overfl_pris1.TabIndex = 257
        Me.tb_overfl_pris1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_overfl_afd�k1
        '
        Me.tb_overfl_afd�k1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.tb_overfl_afd�k1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.tb_overfl_afd�k1.Location = New System.Drawing.Point(595, 21)
        Me.tb_overfl_afd�k1.Name = "tb_overfl_afd�k1"
        Me.tb_overfl_afd�k1.Size = New System.Drawing.Size(81, 20)
        Me.tb_overfl_afd�k1.TabIndex = 256
        Me.tb_overfl_afd�k1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_overfl_opstart1
        '
        Me.tb_overfl_opstart1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.tb_overfl_opstart1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.tb_overfl_opstart1.Location = New System.Drawing.Point(513, 21)
        Me.tb_overfl_opstart1.Name = "tb_overfl_opstart1"
        Me.tb_overfl_opstart1.Size = New System.Drawing.Size(81, 20)
        Me.tb_overfl_opstart1.TabIndex = 255
        Me.tb_overfl_opstart1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'gb_indk�b
        '
        Me.gb_indk�b.BackColor = System.Drawing.Color.WhiteSmoke
        Me.gb_indk�b.Location = New System.Drawing.Point(8, 876)
        Me.gb_indk�b.Name = "gb_indk�b"
        Me.gb_indk�b.Size = New System.Drawing.Size(978, 106)
        Me.gb_indk�b.TabIndex = 229
        Me.gb_indk�b.TabStop = False
        Me.gb_indk�b.Text = "Indk�b"
        Me.gb_indk�b.Visible = False
        '
        'tb_bukmax_y
        '
        Me.tb_bukmax_y.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_bukmax_y.Location = New System.Drawing.Point(141, 24)
        Me.tb_bukmax_y.Name = "tb_bukmax_y"
        Me.tb_bukmax_y.Size = New System.Drawing.Size(53, 20)
        Me.tb_bukmax_y.TabIndex = 19
        '
        'tb_bukmax_x
        '
        Me.tb_bukmax_x.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_bukmax_x.Location = New System.Drawing.Point(82, 24)
        Me.tb_bukmax_x.Name = "tb_bukmax_x"
        Me.tb_bukmax_x.Size = New System.Drawing.Size(53, 20)
        Me.tb_bukmax_x.TabIndex = 7
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.BackColor = System.Drawing.Color.White
        Me.Label70.Location = New System.Drawing.Point(6, 28)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(59, 13)
        Me.Label70.TabIndex = 300
        Me.Label70.Text = "St�rste m�l"
        '
        'gb_buk
        '
        Me.gb_buk.BackColor = System.Drawing.Color.LightCyan
        Me.gb_buk.Controls.Add(Me.Label44)
        Me.gb_buk.Controls.Add(Me.Label204)
        Me.gb_buk.Controls.Add(Me.lb_nettoareal)
        Me.gb_buk.Controls.Add(Me.tb_buk_opst_uk)
        Me.gb_buk.Controls.Add(Me.Label30)
        Me.gb_buk.Controls.Add(Me.lb_buk_opst)
        Me.gb_buk.Controls.Add(Me.Label96)
        Me.gb_buk.Controls.Add(Me.Label95)
        Me.gb_buk.Controls.Add(Me.Label94)
        Me.gb_buk.Controls.Add(Me.Label93)
        Me.gb_buk.Controls.Add(Me.lb_buk_tid)
        Me.gb_buk.Controls.Add(Me.tb_buk_uk)
        Me.gb_buk.Controls.Add(Me.lb_udfold_y)
        Me.gb_buk.Controls.Add(Me.TextBox77)
        Me.gb_buk.Controls.Add(Me.lb_udfold_x)
        Me.gb_buk.Controls.Add(Me.TextBox76)
        Me.gb_buk.Controls.Add(Me.Label84)
        Me.gb_buk.Controls.Add(Me.TextBox75)
        Me.gb_buk.Controls.Add(Me.Label83)
        Me.gb_buk.Controls.Add(Me.TextBox74)
        Me.gb_buk.Controls.Add(Me.tb_buk11_x)
        Me.gb_buk.Controls.Add(Me.TextBox73)
        Me.gb_buk.Controls.Add(Me.tb_buk11_y)
        Me.gb_buk.Controls.Add(Me.Label82)
        Me.gb_buk.Controls.Add(Me.tb_buk10_x)
        Me.gb_buk.Controls.Add(Me.TextBox72)
        Me.gb_buk.Controls.Add(Me.tb_buk10_y)
        Me.gb_buk.Controls.Add(Me.Label81)
        Me.gb_buk.Controls.Add(Me.tb_buk9_x)
        Me.gb_buk.Controls.Add(Me.tb_buk9_y)
        Me.gb_buk.Controls.Add(Me.Label80)
        Me.gb_buk.Controls.Add(Me.tb_buk8_x)
        Me.gb_buk.Controls.Add(Me.tb_buk8_y)
        Me.gb_buk.Controls.Add(Me.Label79)
        Me.gb_buk.Controls.Add(Me.tb_buk7_x)
        Me.gb_buk.Controls.Add(Me.tb_buk7_y)
        Me.gb_buk.Controls.Add(Me.Label77)
        Me.gb_buk.Controls.Add(Me.tb_buk6_x)
        Me.gb_buk.Controls.Add(Me.tb_buk6_y)
        Me.gb_buk.Controls.Add(Me.Label75)
        Me.gb_buk.Controls.Add(Me.tb_buk5_x)
        Me.gb_buk.Controls.Add(Me.tb_buk5_y)
        Me.gb_buk.Controls.Add(Me.Label74)
        Me.gb_buk.Controls.Add(Me.tb_buk4_x)
        Me.gb_buk.Controls.Add(Me.tb_buk4_y)
        Me.gb_buk.Controls.Add(Me.Label73)
        Me.gb_buk.Controls.Add(Me.tb_buk3_x)
        Me.gb_buk.Controls.Add(Me.tb_buk3_y)
        Me.gb_buk.Controls.Add(Me.Label72)
        Me.gb_buk.Controls.Add(Me.tb_buk2_x)
        Me.gb_buk.Controls.Add(Me.tb_buk2_y)
        Me.gb_buk.Controls.Add(Me.Label71)
        Me.gb_buk.Controls.Add(Me.tb_buk1_x)
        Me.gb_buk.Controls.Add(Me.tb_buk1_y)
        Me.gb_buk.Controls.Add(Me.Label70)
        Me.gb_buk.Controls.Add(Me.tb_bukmax_x)
        Me.gb_buk.Controls.Add(Me.tb_bukmax_y)
        Me.gb_buk.Controls.Add(Me.TextBox67)
        Me.gb_buk.Controls.Add(Me.TextBox68)
        Me.gb_buk.Controls.Add(Me.TextBox69)
        Me.gb_buk.Controls.Add(Me.TextBox70)
        Me.gb_buk.Controls.Add(Me.TextBox71)
        Me.gb_buk.Location = New System.Drawing.Point(8, 270)
        Me.gb_buk.Name = "gb_buk"
        Me.gb_buk.Size = New System.Drawing.Size(250, 342)
        Me.gb_buk.TabIndex = 221
        Me.gb_buk.TabStop = False
        Me.gb_buk.Text = "Buk"
        '
        'Label44
        '
        Me.Label44.Location = New System.Drawing.Point(200, 285)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(44, 27)
        Me.Label44.TabIndex = 2014
        Me.Label44.Text = "(maling) 1 side"
        Me.Label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label204
        '
        Me.Label204.Location = New System.Drawing.Point(200, 238)
        Me.Label204.Name = "Label204"
        Me.Label204.Size = New System.Drawing.Size(44, 27)
        Me.Label204.TabIndex = 2013
        Me.Label204.Text = "Areal  M2"
        Me.Label204.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_nettoareal
        '
        Me.lb_nettoareal.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_nettoareal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_nettoareal.Location = New System.Drawing.Point(199, 265)
        Me.lb_nettoareal.Name = "lb_nettoareal"
        Me.lb_nettoareal.Size = New System.Drawing.Size(47, 20)
        Me.lb_nettoareal.TabIndex = 2012
        '
        'tb_buk_opst_uk
        '
        Me.tb_buk_opst_uk.Location = New System.Drawing.Point(141, 318)
        Me.tb_buk_opst_uk.Name = "tb_buk_opst_uk"
        Me.tb_buk_opst_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk_opst_uk.TabIndex = 373
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(8, 322)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(70, 13)
        Me.Label30.TabIndex = 243
        Me.Label30.Text = "Opstilling buk"
        '
        'lb_buk_opst
        '
        Me.lb_buk_opst.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_buk_opst.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_buk_opst.Location = New System.Drawing.Point(82, 318)
        Me.lb_buk_opst.Name = "lb_buk_opst"
        Me.lb_buk_opst.Size = New System.Drawing.Size(53, 20)
        Me.lb_buk_opst.TabIndex = 242
        '
        'Label96
        '
        Me.Label96.AutoSize = True
        Me.Label96.Location = New System.Drawing.Point(164, 8)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(12, 13)
        Me.Label96.TabIndex = 207
        Me.Label96.Text = "y"
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Location = New System.Drawing.Point(107, 8)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(12, 13)
        Me.Label95.TabIndex = 206
        Me.Label95.Text = "x"
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.Location = New System.Drawing.Point(139, 285)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(60, 13)
        Me.Label94.TabIndex = 241
        Me.Label94.Text = "Underkend"
        '
        'Label93
        '
        Me.Label93.Location = New System.Drawing.Point(6, 295)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(70, 26)
        Me.Label93.TabIndex = 241
        Me.Label93.Text = "Buk min./100 stk"
        Me.Label93.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_buk_tid
        '
        Me.lb_buk_tid.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_buk_tid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_buk_tid.Location = New System.Drawing.Point(82, 298)
        Me.lb_buk_tid.Name = "lb_buk_tid"
        Me.lb_buk_tid.Size = New System.Drawing.Size(53, 20)
        Me.lb_buk_tid.TabIndex = 239
        '
        'tb_buk_uk
        '
        Me.tb_buk_uk.Location = New System.Drawing.Point(141, 298)
        Me.tb_buk_uk.Name = "tb_buk_uk"
        Me.tb_buk_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk_uk.TabIndex = 372
        '
        'lb_udfold_y
        '
        Me.lb_udfold_y.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_udfold_y.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_udfold_y.Location = New System.Drawing.Point(142, 265)
        Me.lb_udfold_y.Name = "lb_udfold_y"
        Me.lb_udfold_y.Size = New System.Drawing.Size(53, 20)
        Me.lb_udfold_y.TabIndex = 238
        '
        'TextBox77
        '
        Me.TextBox77.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.TextBox77.Location = New System.Drawing.Point(239, -114)
        Me.TextBox77.Name = "TextBox77"
        Me.TextBox77.Size = New System.Drawing.Size(126, 20)
        Me.TextBox77.TabIndex = 63
        '
        'lb_udfold_x
        '
        Me.lb_udfold_x.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_udfold_x.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_udfold_x.Location = New System.Drawing.Point(82, 266)
        Me.lb_udfold_x.Name = "lb_udfold_x"
        Me.lb_udfold_x.Size = New System.Drawing.Size(53, 20)
        Me.lb_udfold_x.TabIndex = 237
        '
        'TextBox76
        '
        Me.TextBox76.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.TextBox76.Location = New System.Drawing.Point(371, -114)
        Me.TextBox76.Name = "TextBox76"
        Me.TextBox76.Size = New System.Drawing.Size(126, 20)
        Me.TextBox76.TabIndex = 64
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.Location = New System.Drawing.Point(6, 273)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(58, 13)
        Me.Label84.TabIndex = 236
        Me.Label84.Text = "Udfoldning"
        '
        'TextBox75
        '
        Me.TextBox75.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.TextBox75.Location = New System.Drawing.Point(503, -114)
        Me.TextBox75.Name = "TextBox75"
        Me.TextBox75.Size = New System.Drawing.Size(126, 20)
        Me.TextBox75.TabIndex = 65
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Location = New System.Drawing.Point(6, 247)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(41, 13)
        Me.Label83.TabIndex = 235
        Me.Label83.Text = "Buk 11"
        '
        'TextBox74
        '
        Me.TextBox74.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.TextBox74.Location = New System.Drawing.Point(635, -114)
        Me.TextBox74.Name = "TextBox74"
        Me.TextBox74.Size = New System.Drawing.Size(126, 20)
        Me.TextBox74.TabIndex = 66
        '
        'tb_buk11_x
        '
        Me.tb_buk11_x.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk11_x.Location = New System.Drawing.Point(82, 243)
        Me.tb_buk11_x.Name = "tb_buk11_x"
        Me.tb_buk11_x.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk11_x.TabIndex = 18
        '
        'TextBox73
        '
        Me.TextBox73.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.TextBox73.Location = New System.Drawing.Point(107, -114)
        Me.TextBox73.Name = "TextBox73"
        Me.TextBox73.Size = New System.Drawing.Size(126, 20)
        Me.TextBox73.TabIndex = 62
        '
        'tb_buk11_y
        '
        Me.tb_buk11_y.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk11_y.Location = New System.Drawing.Point(141, 243)
        Me.tb_buk11_y.Name = "tb_buk11_y"
        Me.tb_buk11_y.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk11_y.TabIndex = 30
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Location = New System.Drawing.Point(6, 228)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(41, 13)
        Me.Label82.TabIndex = 232
        Me.Label82.Text = "Buk 10"
        '
        'tb_buk10_x
        '
        Me.tb_buk10_x.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk10_x.Location = New System.Drawing.Point(82, 224)
        Me.tb_buk10_x.Name = "tb_buk10_x"
        Me.tb_buk10_x.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk10_x.TabIndex = 17
        '
        'TextBox72
        '
        Me.TextBox72.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBox72.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox72.Location = New System.Drawing.Point(53, -154)
        Me.TextBox72.Name = "TextBox72"
        Me.TextBox72.Size = New System.Drawing.Size(35, 20)
        Me.TextBox72.TabIndex = 135
        Me.TextBox72.Text = "15"
        Me.TextBox72.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_buk10_y
        '
        Me.tb_buk10_y.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk10_y.Location = New System.Drawing.Point(141, 224)
        Me.tb_buk10_y.Name = "tb_buk10_y"
        Me.tb_buk10_y.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk10_y.TabIndex = 29
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Location = New System.Drawing.Point(6, 208)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(35, 13)
        Me.Label81.TabIndex = 229
        Me.Label81.Text = "Buk 9"
        '
        'tb_buk9_x
        '
        Me.tb_buk9_x.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk9_x.Location = New System.Drawing.Point(82, 204)
        Me.tb_buk9_x.Name = "tb_buk9_x"
        Me.tb_buk9_x.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk9_x.TabIndex = 16
        '
        'tb_buk9_y
        '
        Me.tb_buk9_y.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk9_y.Location = New System.Drawing.Point(141, 204)
        Me.tb_buk9_y.Name = "tb_buk9_y"
        Me.tb_buk9_y.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk9_y.TabIndex = 28
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Location = New System.Drawing.Point(6, 188)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(35, 13)
        Me.Label80.TabIndex = 226
        Me.Label80.Text = "Buk 8"
        '
        'tb_buk8_x
        '
        Me.tb_buk8_x.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk8_x.Location = New System.Drawing.Point(82, 184)
        Me.tb_buk8_x.Name = "tb_buk8_x"
        Me.tb_buk8_x.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk8_x.TabIndex = 15
        '
        'tb_buk8_y
        '
        Me.tb_buk8_y.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk8_y.Location = New System.Drawing.Point(141, 184)
        Me.tb_buk8_y.Name = "tb_buk8_y"
        Me.tb_buk8_y.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk8_y.TabIndex = 27
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Location = New System.Drawing.Point(6, 168)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(35, 13)
        Me.Label79.TabIndex = 223
        Me.Label79.Text = "Buk 7"
        '
        'tb_buk7_x
        '
        Me.tb_buk7_x.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk7_x.Location = New System.Drawing.Point(82, 164)
        Me.tb_buk7_x.Name = "tb_buk7_x"
        Me.tb_buk7_x.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk7_x.TabIndex = 14
        '
        'tb_buk7_y
        '
        Me.tb_buk7_y.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk7_y.Location = New System.Drawing.Point(141, 164)
        Me.tb_buk7_y.Name = "tb_buk7_y"
        Me.tb_buk7_y.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk7_y.TabIndex = 26
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Location = New System.Drawing.Point(6, 148)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(35, 13)
        Me.Label77.TabIndex = 220
        Me.Label77.Text = "Buk 6"
        '
        'tb_buk6_x
        '
        Me.tb_buk6_x.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk6_x.Location = New System.Drawing.Point(82, 144)
        Me.tb_buk6_x.Name = "tb_buk6_x"
        Me.tb_buk6_x.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk6_x.TabIndex = 13
        '
        'tb_buk6_y
        '
        Me.tb_buk6_y.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk6_y.Location = New System.Drawing.Point(141, 144)
        Me.tb_buk6_y.Name = "tb_buk6_y"
        Me.tb_buk6_y.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk6_y.TabIndex = 25
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Location = New System.Drawing.Point(6, 128)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(35, 13)
        Me.Label75.TabIndex = 217
        Me.Label75.Text = "Buk 5"
        '
        'tb_buk5_x
        '
        Me.tb_buk5_x.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk5_x.Location = New System.Drawing.Point(82, 124)
        Me.tb_buk5_x.Name = "tb_buk5_x"
        Me.tb_buk5_x.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk5_x.TabIndex = 12
        '
        'tb_buk5_y
        '
        Me.tb_buk5_y.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk5_y.Location = New System.Drawing.Point(141, 124)
        Me.tb_buk5_y.Name = "tb_buk5_y"
        Me.tb_buk5_y.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk5_y.TabIndex = 24
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Location = New System.Drawing.Point(6, 108)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(35, 13)
        Me.Label74.TabIndex = 214
        Me.Label74.Text = "Buk 4"
        '
        'tb_buk4_x
        '
        Me.tb_buk4_x.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk4_x.Location = New System.Drawing.Point(82, 104)
        Me.tb_buk4_x.Name = "tb_buk4_x"
        Me.tb_buk4_x.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk4_x.TabIndex = 11
        '
        'tb_buk4_y
        '
        Me.tb_buk4_y.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk4_y.Location = New System.Drawing.Point(141, 104)
        Me.tb_buk4_y.Name = "tb_buk4_y"
        Me.tb_buk4_y.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk4_y.TabIndex = 23
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Location = New System.Drawing.Point(6, 88)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(35, 13)
        Me.Label73.TabIndex = 2011
        Me.Label73.Text = "Buk 3"
        '
        'tb_buk3_x
        '
        Me.tb_buk3_x.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk3_x.Location = New System.Drawing.Point(82, 84)
        Me.tb_buk3_x.Name = "tb_buk3_x"
        Me.tb_buk3_x.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk3_x.TabIndex = 10
        '
        'tb_buk3_y
        '
        Me.tb_buk3_y.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk3_y.Location = New System.Drawing.Point(141, 84)
        Me.tb_buk3_y.Name = "tb_buk3_y"
        Me.tb_buk3_y.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk3_y.TabIndex = 22
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.Location = New System.Drawing.Point(6, 68)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(35, 13)
        Me.Label72.TabIndex = 208
        Me.Label72.Text = "Buk 2"
        '
        'tb_buk2_x
        '
        Me.tb_buk2_x.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk2_x.Location = New System.Drawing.Point(82, 64)
        Me.tb_buk2_x.Name = "tb_buk2_x"
        Me.tb_buk2_x.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk2_x.TabIndex = 9
        '
        'tb_buk2_y
        '
        Me.tb_buk2_y.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk2_y.Location = New System.Drawing.Point(141, 64)
        Me.tb_buk2_y.Name = "tb_buk2_y"
        Me.tb_buk2_y.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk2_y.TabIndex = 21
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Location = New System.Drawing.Point(6, 48)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(35, 13)
        Me.Label71.TabIndex = 205
        Me.Label71.Text = "Buk 1"
        '
        'tb_buk1_x
        '
        Me.tb_buk1_x.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk1_x.Location = New System.Drawing.Point(82, 44)
        Me.tb_buk1_x.Name = "tb_buk1_x"
        Me.tb_buk1_x.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk1_x.TabIndex = 8
        '
        'tb_buk1_y
        '
        Me.tb_buk1_y.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_buk1_y.Location = New System.Drawing.Point(141, 44)
        Me.tb_buk1_y.Name = "tb_buk1_y"
        Me.tb_buk1_y.Size = New System.Drawing.Size(53, 20)
        Me.tb_buk1_y.TabIndex = 20
        '
        'TextBox67
        '
        Me.TextBox67.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.TextBox67.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox67.Location = New System.Drawing.Point(106, -300)
        Me.TextBox67.Name = "TextBox67"
        Me.TextBox67.Size = New System.Drawing.Size(126, 20)
        Me.TextBox67.TabIndex = 5
        Me.TextBox67.Text = "100"
        Me.TextBox67.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox68
        '
        Me.TextBox68.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.TextBox68.Location = New System.Drawing.Point(634, -300)
        Me.TextBox68.Name = "TextBox68"
        Me.TextBox68.Size = New System.Drawing.Size(126, 20)
        Me.TextBox68.TabIndex = 9
        '
        'TextBox69
        '
        Me.TextBox69.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.TextBox69.Location = New System.Drawing.Point(502, -300)
        Me.TextBox69.Name = "TextBox69"
        Me.TextBox69.Size = New System.Drawing.Size(126, 20)
        Me.TextBox69.TabIndex = 8
        '
        'TextBox70
        '
        Me.TextBox70.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.TextBox70.Location = New System.Drawing.Point(370, -300)
        Me.TextBox70.Name = "TextBox70"
        Me.TextBox70.Size = New System.Drawing.Size(126, 20)
        Me.TextBox70.TabIndex = 7
        '
        'TextBox71
        '
        Me.TextBox71.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.TextBox71.Location = New System.Drawing.Point(238, -300)
        Me.TextBox71.Name = "TextBox71"
        Me.TextBox71.Size = New System.Drawing.Size(126, 20)
        Me.TextBox71.TabIndex = 6
        '
        'cb_Tegning
        '
        Me.cb_Tegning.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.cb_Tegning.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cb_Tegning.FormattingEnabled = True
        Me.cb_Tegning.IntegralHeight = False
        Me.cb_Tegning.Location = New System.Drawing.Point(862, 2)
        Me.cb_Tegning.Name = "cb_Tegning"
        Me.cb_Tegning.Size = New System.Drawing.Size(281, 26)
        Me.cb_Tegning.TabIndex = 3
        '
        'gb_hul
        '
        Me.gb_hul.BackColor = System.Drawing.Color.LavenderBlush
        Me.gb_hul.Controls.Add(Me.tb_CNCmin_uk)
        Me.gb_hul.Controls.Add(Me.Label90)
        Me.gb_hul.Controls.Add(Me.Label107)
        Me.gb_hul.Controls.Add(Me.lb_gruppe1_opstart)
        Me.gb_hul.Controls.Add(Me.Label108)
        Me.gb_hul.Controls.Add(Me.Label86)
        Me.gb_hul.Controls.Add(Me.Label33)
        Me.gb_hul.Controls.Add(Me.tb_toolshift)
        Me.gb_hul.Controls.Add(Me.Label99)
        Me.gb_hul.Controls.Add(Me.tb_slag_til_huller)
        Me.gb_hul.Controls.Add(Me.lb_gruppe1_tid)
        Me.gb_hul.Controls.Add(Me.tb_gruppe1_opstart_uk)
        Me.gb_hul.Location = New System.Drawing.Point(8, 632)
        Me.gb_hul.Name = "gb_hul"
        Me.gb_hul.Size = New System.Drawing.Size(250, 126)
        Me.gb_hul.TabIndex = 231
        Me.gb_hul.TabStop = False
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Location = New System.Drawing.Point(23, 100)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(63, 13)
        Me.Label90.TabIndex = 260
        Me.Label90.Text = "Opstart min."
        '
        'Label107
        '
        Me.Label107.AutoSize = True
        Me.Label107.Location = New System.Drawing.Point(23, 76)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(91, 13)
        Me.Label107.TabIndex = 257
        Me.Label107.Text = "CNC min./100 stk"
        '
        'Label108
        '
        Me.Label108.AutoSize = True
        Me.Label108.Location = New System.Drawing.Point(189, 57)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(60, 13)
        Me.Label108.TabIndex = 256
        Me.Label108.Text = "Underkend"
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.Location = New System.Drawing.Point(23, 46)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(91, 13)
        Me.Label86.TabIndex = 253
        Me.Label86.Text = "Antal slag til huller"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(135, 6)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(48, 13)
        Me.Label33.TabIndex = 251
        Me.Label33.Text = "pr. emne"
        '
        'tb_toolshift
        '
        Me.tb_toolshift.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_toolshift.Location = New System.Drawing.Point(133, 20)
        Me.tb_toolshift.Name = "tb_toolshift"
        Me.tb_toolshift.Size = New System.Drawing.Size(53, 20)
        Me.tb_toolshift.TabIndex = 32
        '
        'Label99
        '
        Me.Label99.AutoSize = True
        Me.Label99.Location = New System.Drawing.Point(23, 23)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(71, 13)
        Me.Label99.TabIndex = 245
        Me.Label99.Text = "V�rkt�jsskift "
        '
        'tb_slag_til_huller
        '
        Me.tb_slag_til_huller.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_slag_til_huller.Location = New System.Drawing.Point(133, 44)
        Me.tb_slag_til_huller.Name = "tb_slag_til_huller"
        Me.tb_slag_til_huller.Size = New System.Drawing.Size(53, 20)
        Me.tb_slag_til_huller.TabIndex = 33
        '
        'tb_opstart_kr_uk
        '
        Me.tb_opstart_kr_uk.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_opstart_kr_uk.Location = New System.Drawing.Point(141, 72)
        Me.tb_opstart_kr_uk.MaximumSize = New System.Drawing.Size(77, 20)
        Me.tb_opstart_kr_uk.Name = "tb_opstart_kr_uk"
        Me.tb_opstart_kr_uk.Size = New System.Drawing.Size(53, 21)
        Me.tb_opstart_kr_uk.TabIndex = 543
        Me.tb_opstart_kr_uk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_Program_kr_uk
        '
        Me.tb_Program_kr_uk.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_Program_kr_uk.Location = New System.Drawing.Point(141, 133)
        Me.tb_Program_kr_uk.MaximumSize = New System.Drawing.Size(77, 20)
        Me.tb_Program_kr_uk.Name = "tb_Program_kr_uk"
        Me.tb_Program_kr_uk.Size = New System.Drawing.Size(53, 21)
        Me.tb_Program_kr_uk.TabIndex = 545
        Me.tb_Program_kr_uk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.Location = New System.Drawing.Point(135, 37)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(60, 13)
        Me.Label91.TabIndex = 240
        Me.Label91.Text = "Underkend"
        '
        'gb_pristabel
        '
        Me.gb_pristabel.BackColor = System.Drawing.Color.Linen
        Me.gb_pristabel.Controls.Add(Me.lb_r�varerstk5)
        Me.gb_pristabel.Controls.Add(Me.lb_r�varerstk4)
        Me.gb_pristabel.Controls.Add(Me.lb_r�varerstk3)
        Me.gb_pristabel.Controls.Add(Me.lb_r�varerstk2)
        Me.gb_pristabel.Controls.Add(Me.lb_r�varer1)
        Me.gb_pristabel.Controls.Add(Me.lb_mand5_tid)
        Me.gb_pristabel.Controls.Add(Me.lb_CNC5_tid)
        Me.gb_pristabel.Controls.Add(Me.lb_mand4_tid)
        Me.gb_pristabel.Controls.Add(Me.lb_CNC4_tid)
        Me.gb_pristabel.Controls.Add(Me.lb_mand3_tid)
        Me.gb_pristabel.Controls.Add(Me.lb_CNC3_tid)
        Me.gb_pristabel.Controls.Add(Me.lb_CNC2_tid)
        Me.gb_pristabel.Controls.Add(Me.lb_mand2_tid)
        Me.gb_pristabel.Controls.Add(Me.lb_CNC1_tid)
        Me.gb_pristabel.Controls.Add(Me.lb_mand1_tid)
        Me.gb_pristabel.Controls.Add(Me.Label118)
        Me.gb_pristabel.Controls.Add(Me.Label117)
        Me.gb_pristabel.Controls.Add(Me.Label116)
        Me.gb_pristabel.Controls.Add(Me.Label115)
        Me.gb_pristabel.Controls.Add(Me.Label76)
        Me.gb_pristabel.Controls.Add(Me.Label38)
        Me.gb_pristabel.Controls.Add(Me.Label37)
        Me.gb_pristabel.Controls.Add(Me.tb_tilbud2)
        Me.gb_pristabel.Controls.Add(Me.tb_tilbud3)
        Me.gb_pristabel.Controls.Add(Me.tb_tilbud4)
        Me.gb_pristabel.Controls.Add(Me.tb_tilbud5)
        Me.gb_pristabel.Controls.Add(Me.tb_tilbud1)
        Me.gb_pristabel.Controls.Add(Me.Label36)
        Me.gb_pristabel.Controls.Add(Me.Label35)
        Me.gb_pristabel.Controls.Add(Me.tb_avance)
        Me.gb_pristabel.Controls.Add(Me.Label49)
        Me.gb_pristabel.Controls.Add(Me.Label48)
        Me.gb_pristabel.Controls.Add(Me.Label47)
        Me.gb_pristabel.Controls.Add(Me.Label53)
        Me.gb_pristabel.Controls.Add(Me.Label52)
        Me.gb_pristabel.Controls.Add(Me.Label46)
        Me.gb_pristabel.Controls.Add(Me.Label45)
        Me.gb_pristabel.Controls.Add(Me.lb_salg2)
        Me.gb_pristabel.Controls.Add(Me.lb_salg3)
        Me.gb_pristabel.Controls.Add(Me.lb_salg4)
        Me.gb_pristabel.Controls.Add(Me.lb_salg5)
        Me.gb_pristabel.Controls.Add(Me.lb_salg1)
        Me.gb_pristabel.Controls.Add(Me.lb_samlet2)
        Me.gb_pristabel.Controls.Add(Me.lb_samlet3)
        Me.gb_pristabel.Controls.Add(Me.lb_samlet4)
        Me.gb_pristabel.Controls.Add(Me.lb_samlet5)
        Me.gb_pristabel.Controls.Add(Me.lb_samlet1)
        Me.gb_pristabel.Controls.Add(Me.lb_timer2)
        Me.gb_pristabel.Controls.Add(Me.lb_cnc2)
        Me.gb_pristabel.Controls.Add(Me.lb_timer3)
        Me.gb_pristabel.Controls.Add(Me.lb_cnc3)
        Me.gb_pristabel.Controls.Add(Me.lb_timer4)
        Me.gb_pristabel.Controls.Add(Me.lb_cnc4)
        Me.gb_pristabel.Controls.Add(Me.lb_cnc5)
        Me.gb_pristabel.Controls.Add(Me.lb_timer1)
        Me.gb_pristabel.Controls.Add(Me.lb_cnc1)
        Me.gb_pristabel.Controls.Add(Me.Label25)
        Me.gb_pristabel.Controls.Add(Me.Label26)
        Me.gb_pristabel.Controls.Add(Me.Label27)
        Me.gb_pristabel.Controls.Add(Me.lb_timer5)
        Me.gb_pristabel.Controls.Add(Me.Label29)
        Me.gb_pristabel.Controls.Add(Me.lb_indk�b2)
        Me.gb_pristabel.Controls.Add(Me.lb_indk�b3)
        Me.gb_pristabel.Controls.Add(Me.lb_indk�b4)
        Me.gb_pristabel.Controls.Add(Me.lb_indk�b5)
        Me.gb_pristabel.Controls.Add(Me.lb_indk�b1)
        Me.gb_pristabel.Controls.Add(Me.lb_r�varer2)
        Me.gb_pristabel.Controls.Add(Me.lb_r�varer3)
        Me.gb_pristabel.Controls.Add(Me.lb_r�varer4)
        Me.gb_pristabel.Controls.Add(Me.lb_r�varer5)
        Me.gb_pristabel.Controls.Add(Me.Label122)
        Me.gb_pristabel.Controls.Add(Me.lb_r�varerstk1)
        Me.gb_pristabel.Controls.Add(Me.Label121)
        Me.gb_pristabel.Controls.Add(Me.lb_mand2)
        Me.gb_pristabel.Controls.Add(Me.Label120)
        Me.gb_pristabel.Controls.Add(Me.lb_mand3)
        Me.gb_pristabel.Controls.Add(Me.Label119)
        Me.gb_pristabel.Controls.Add(Me.lb_mand4)
        Me.gb_pristabel.Controls.Add(Me.lb_mand5)
        Me.gb_pristabel.Controls.Add(Me.lb_mand1)
        Me.gb_pristabel.Controls.Add(Me.tb_antal2)
        Me.gb_pristabel.Controls.Add(Me.tb_antal3)
        Me.gb_pristabel.Controls.Add(Me.tb_antal4)
        Me.gb_pristabel.Controls.Add(Me.tb_antal5)
        Me.gb_pristabel.Controls.Add(Me.tb_antal1)
        Me.gb_pristabel.Location = New System.Drawing.Point(8, 30)
        Me.gb_pristabel.Name = "gb_pristabel"
        Me.gb_pristabel.Size = New System.Drawing.Size(777, 240)
        Me.gb_pristabel.TabIndex = 241
        Me.gb_pristabel.TabStop = False
        Me.gb_pristabel.Text = "Prisskema"
        '
        'lb_r�varerstk5
        '
        Me.lb_r�varerstk5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_r�varerstk5.Location = New System.Drawing.Point(636, 134)
        Me.lb_r�varerstk5.Name = "lb_r�varerstk5"
        Me.lb_r�varerstk5.Size = New System.Drawing.Size(63, 20)
        Me.lb_r�varerstk5.TabIndex = 233
        Me.lb_r�varerstk5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_r�varerstk4
        '
        Me.lb_r�varerstk4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_r�varerstk4.Location = New System.Drawing.Point(504, 134)
        Me.lb_r�varerstk4.Name = "lb_r�varerstk4"
        Me.lb_r�varerstk4.Size = New System.Drawing.Size(63, 20)
        Me.lb_r�varerstk4.TabIndex = 232
        Me.lb_r�varerstk4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_r�varerstk3
        '
        Me.lb_r�varerstk3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_r�varerstk3.Location = New System.Drawing.Point(372, 134)
        Me.lb_r�varerstk3.Name = "lb_r�varerstk3"
        Me.lb_r�varerstk3.Size = New System.Drawing.Size(63, 20)
        Me.lb_r�varerstk3.TabIndex = 231
        Me.lb_r�varerstk3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_r�varerstk2
        '
        Me.lb_r�varerstk2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_r�varerstk2.Location = New System.Drawing.Point(240, 134)
        Me.lb_r�varerstk2.Name = "lb_r�varerstk2"
        Me.lb_r�varerstk2.Size = New System.Drawing.Size(63, 20)
        Me.lb_r�varerstk2.TabIndex = 230
        Me.lb_r�varerstk2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_r�varer1
        '
        Me.lb_r�varer1.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.lb_r�varer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_r�varer1.Location = New System.Drawing.Point(173, 134)
        Me.lb_r�varer1.Name = "lb_r�varer1"
        Me.lb_r�varer1.Size = New System.Drawing.Size(63, 20)
        Me.lb_r�varer1.TabIndex = 229
        Me.lb_r�varer1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_mand5_tid
        '
        Me.lb_mand5_tid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_mand5_tid.Location = New System.Drawing.Point(713, 53)
        Me.lb_mand5_tid.Name = "lb_mand5_tid"
        Me.lb_mand5_tid.Size = New System.Drawing.Size(50, 20)
        Me.lb_mand5_tid.TabIndex = 228
        Me.lb_mand5_tid.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_CNC5_tid
        '
        Me.lb_CNC5_tid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_CNC5_tid.Location = New System.Drawing.Point(713, 73)
        Me.lb_CNC5_tid.Name = "lb_CNC5_tid"
        Me.lb_CNC5_tid.Size = New System.Drawing.Size(50, 20)
        Me.lb_CNC5_tid.TabIndex = 227
        Me.lb_CNC5_tid.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_mand4_tid
        '
        Me.lb_mand4_tid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_mand4_tid.Location = New System.Drawing.Point(581, 53)
        Me.lb_mand4_tid.Name = "lb_mand4_tid"
        Me.lb_mand4_tid.Size = New System.Drawing.Size(50, 20)
        Me.lb_mand4_tid.TabIndex = 226
        Me.lb_mand4_tid.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_CNC4_tid
        '
        Me.lb_CNC4_tid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_CNC4_tid.Location = New System.Drawing.Point(581, 73)
        Me.lb_CNC4_tid.Name = "lb_CNC4_tid"
        Me.lb_CNC4_tid.Size = New System.Drawing.Size(50, 20)
        Me.lb_CNC4_tid.TabIndex = 225
        Me.lb_CNC4_tid.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_mand3_tid
        '
        Me.lb_mand3_tid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_mand3_tid.Location = New System.Drawing.Point(449, 53)
        Me.lb_mand3_tid.Name = "lb_mand3_tid"
        Me.lb_mand3_tid.Size = New System.Drawing.Size(50, 20)
        Me.lb_mand3_tid.TabIndex = 224
        Me.lb_mand3_tid.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_CNC3_tid
        '
        Me.lb_CNC3_tid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_CNC3_tid.Location = New System.Drawing.Point(449, 73)
        Me.lb_CNC3_tid.Name = "lb_CNC3_tid"
        Me.lb_CNC3_tid.Size = New System.Drawing.Size(50, 20)
        Me.lb_CNC3_tid.TabIndex = 223
        Me.lb_CNC3_tid.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_CNC2_tid
        '
        Me.lb_CNC2_tid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_CNC2_tid.Location = New System.Drawing.Point(317, 73)
        Me.lb_CNC2_tid.Name = "lb_CNC2_tid"
        Me.lb_CNC2_tid.Size = New System.Drawing.Size(50, 20)
        Me.lb_CNC2_tid.TabIndex = 222
        Me.lb_CNC2_tid.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_mand2_tid
        '
        Me.lb_mand2_tid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_mand2_tid.Location = New System.Drawing.Point(317, 53)
        Me.lb_mand2_tid.Name = "lb_mand2_tid"
        Me.lb_mand2_tid.Size = New System.Drawing.Size(50, 20)
        Me.lb_mand2_tid.TabIndex = 221
        Me.lb_mand2_tid.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_CNC1_tid
        '
        Me.lb_CNC1_tid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_CNC1_tid.Location = New System.Drawing.Point(186, 73)
        Me.lb_CNC1_tid.Name = "lb_CNC1_tid"
        Me.lb_CNC1_tid.Size = New System.Drawing.Size(50, 20)
        Me.lb_CNC1_tid.TabIndex = 220
        Me.lb_CNC1_tid.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_mand1_tid
        '
        Me.lb_mand1_tid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_mand1_tid.Location = New System.Drawing.Point(186, 53)
        Me.lb_mand1_tid.Name = "lb_mand1_tid"
        Me.lb_mand1_tid.Size = New System.Drawing.Size(50, 20)
        Me.lb_mand1_tid.TabIndex = 219
        Me.lb_mand1_tid.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label118
        '
        Me.Label118.AutoSize = True
        Me.Label118.Location = New System.Drawing.Point(266, 8)
        Me.Label118.Name = "Label118"
        Me.Label118.Size = New System.Drawing.Size(59, 13)
        Me.Label118.TabIndex = 218
        Me.Label118.Text = "Ordre str. 2"
        '
        'Label117
        '
        Me.Label117.AutoSize = True
        Me.Label117.Location = New System.Drawing.Point(405, 8)
        Me.Label117.Name = "Label117"
        Me.Label117.Size = New System.Drawing.Size(59, 13)
        Me.Label117.TabIndex = 217
        Me.Label117.Text = "Ordre str. 3"
        '
        'Label116
        '
        Me.Label116.AutoSize = True
        Me.Label116.Location = New System.Drawing.Point(537, 8)
        Me.Label116.Name = "Label116"
        Me.Label116.Size = New System.Drawing.Size(59, 13)
        Me.Label116.TabIndex = 216
        Me.Label116.Text = "Ordre str. 4"
        '
        'Label115
        '
        Me.Label115.AutoSize = True
        Me.Label115.Location = New System.Drawing.Point(670, 8)
        Me.Label115.Name = "Label115"
        Me.Label115.Size = New System.Drawing.Size(59, 13)
        Me.Label115.TabIndex = 215
        Me.Label115.Text = "Ordre str. 5"
        '
        'lb_timer2
        '
        Me.lb_timer2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_timer2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_timer2.Location = New System.Drawing.Point(240, 94)
        Me.lb_timer2.Name = "lb_timer2"
        Me.lb_timer2.Size = New System.Drawing.Size(126, 20)
        Me.lb_timer2.TabIndex = 166
        Me.lb_timer2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_timer3
        '
        Me.lb_timer3.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_timer3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_timer3.Location = New System.Drawing.Point(372, 94)
        Me.lb_timer3.Name = "lb_timer3"
        Me.lb_timer3.Size = New System.Drawing.Size(126, 20)
        Me.lb_timer3.TabIndex = 165
        Me.lb_timer3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_timer4
        '
        Me.lb_timer4.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_timer4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_timer4.Location = New System.Drawing.Point(504, 94)
        Me.lb_timer4.Name = "lb_timer4"
        Me.lb_timer4.Size = New System.Drawing.Size(126, 20)
        Me.lb_timer4.TabIndex = 164
        Me.lb_timer4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_timer1
        '
        Me.lb_timer1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_timer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_timer1.Location = New System.Drawing.Point(109, 94)
        Me.lb_timer1.Name = "lb_timer1"
        Me.lb_timer1.Size = New System.Drawing.Size(126, 20)
        Me.lb_timer1.TabIndex = 162
        Me.lb_timer1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label122
        '
        Me.Label122.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label122.Location = New System.Drawing.Point(240, 75)
        Me.Label122.Name = "Label122"
        Me.Label122.Size = New System.Drawing.Size(126, 20)
        Me.Label122.TabIndex = 146
        Me.Label122.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label121
        '
        Me.Label121.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label121.Location = New System.Drawing.Point(372, 75)
        Me.Label121.Name = "Label121"
        Me.Label121.Size = New System.Drawing.Size(126, 20)
        Me.Label121.TabIndex = 143
        Me.Label121.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label120
        '
        Me.Label120.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label120.Location = New System.Drawing.Point(504, 75)
        Me.Label120.Name = "Label120"
        Me.Label120.Size = New System.Drawing.Size(126, 20)
        Me.Label120.TabIndex = 142
        Me.Label120.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label119
        '
        Me.Label119.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label119.Location = New System.Drawing.Point(636, 75)
        Me.Label119.Name = "Label119"
        Me.Label119.Size = New System.Drawing.Size(126, 20)
        Me.Label119.TabIndex = 140
        Me.Label119.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'gb_opstart
        '
        Me.gb_opstart.BackColor = System.Drawing.Color.Linen
        Me.gb_opstart.Controls.Add(Me.tb_antal_program_uk)
        Me.gb_opstart.Controls.Add(Me.tb_antal_opstart_uk)
        Me.gb_opstart.Controls.Add(Me.Label126)
        Me.gb_opstart.Controls.Add(Me.Label91)
        Me.gb_opstart.Controls.Add(Me.tb_Program_kr_uk)
        Me.gb_opstart.Controls.Add(Me.tb_opstart_kr_uk)
        Me.gb_opstart.Controls.Add(Me.Label56)
        Me.gb_opstart.Controls.Add(Me.Label39)
        Me.gb_opstart.Controls.Add(Me.Label50)
        Me.gb_opstart.Controls.Add(Me.tb_opstart_afgivettilbud)
        Me.gb_opstart.Controls.Add(Me.Label51)
        Me.gb_opstart.Controls.Add(Me.Label54)
        Me.gb_opstart.Controls.Add(Me.tb_opstart_avance)
        Me.gb_opstart.Controls.Add(Me.Label55)
        Me.gb_opstart.Controls.Add(Me.Label59)
        Me.gb_opstart.Controls.Add(Me.Label60)
        Me.gb_opstart.Controls.Add(Me.lb_opst_prog_brutto)
        Me.gb_opstart.Controls.Add(Me.lb_opstart_program)
        Me.gb_opstart.Controls.Add(Me.lb_opstart_kr)
        Me.gb_opstart.Controls.Add(Me.lb_antal_program)
        Me.gb_opstart.Controls.Add(Me.lb_program_kr)
        Me.gb_opstart.Controls.Add(Me.lb_antal_opstart)
        Me.gb_opstart.ForeColor = System.Drawing.SystemColors.ControlText
        Me.gb_opstart.Location = New System.Drawing.Point(785, 30)
        Me.gb_opstart.Name = "gb_opstart"
        Me.gb_opstart.Size = New System.Drawing.Size(201, 240)
        Me.gb_opstart.TabIndex = 242
        Me.gb_opstart.TabStop = False
        Me.gb_opstart.Text = "CNC Opstart/program"
        '
        'tb_antal_program_uk
        '
        Me.tb_antal_program_uk.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_antal_program_uk.Location = New System.Drawing.Point(141, 112)
        Me.tb_antal_program_uk.MaximumSize = New System.Drawing.Size(77, 20)
        Me.tb_antal_program_uk.Name = "tb_antal_program_uk"
        Me.tb_antal_program_uk.Size = New System.Drawing.Size(53, 21)
        Me.tb_antal_program_uk.TabIndex = 544
        Me.tb_antal_program_uk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_antal_opstart_uk
        '
        Me.tb_antal_opstart_uk.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_antal_opstart_uk.Location = New System.Drawing.Point(141, 52)
        Me.tb_antal_opstart_uk.MaximumSize = New System.Drawing.Size(77, 20)
        Me.tb_antal_opstart_uk.Name = "tb_antal_opstart_uk"
        Me.tb_antal_opstart_uk.Size = New System.Drawing.Size(53, 21)
        Me.tb_antal_opstart_uk.TabIndex = 542
        Me.tb_antal_opstart_uk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label126
        '
        Me.Label126.AutoSize = True
        Me.Label126.Location = New System.Drawing.Point(3, 119)
        Me.Label126.Name = "Label126"
        Me.Label126.Size = New System.Drawing.Size(75, 13)
        Me.Label126.TabIndex = 241
        Me.Label126.Text = "Program  antal"
        '
        'lb_opstart_kr
        '
        Me.lb_opstart_kr.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_opstart_kr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_opstart_kr.Location = New System.Drawing.Point(82, 73)
        Me.lb_opstart_kr.Name = "lb_opstart_kr"
        Me.lb_opstart_kr.Size = New System.Drawing.Size(53, 20)
        Me.lb_opstart_kr.TabIndex = 191
        Me.lb_opstart_kr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_antal_program
        '
        Me.lb_antal_program.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_antal_program.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_antal_program.Location = New System.Drawing.Point(82, 114)
        Me.lb_antal_program.Name = "lb_antal_program"
        Me.lb_antal_program.Size = New System.Drawing.Size(53, 20)
        Me.lb_antal_program.TabIndex = 190
        Me.lb_antal_program.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'gb_matr
        '
        Me.gb_matr.BackColor = System.Drawing.Color.Lavender
        Me.gb_matr.Controls.Add(Me.Label178)
        Me.gb_matr.Controls.Add(Me.Label177)
        Me.gb_matr.Controls.Add(Me.tb_Kilopris_uk)
        Me.gb_matr.Controls.Add(Me.Label149)
        Me.gb_matr.Controls.Add(Me.tb_sv�rhed_uk)
        Me.gb_matr.Controls.Add(Me.lb_faktor)
        Me.gb_matr.Controls.Add(Me.Label20)
        Me.gb_matr.Controls.Add(Me.lb_sv�rhed)
        Me.gb_matr.Controls.Add(Me.cb_frav�lg)
        Me.gb_matr.Controls.Add(Me.lb_spildnetto)
        Me.gb_matr.Controls.Add(Me.Lb_Kilopris)
        Me.gb_matr.Controls.Add(Me.Label92)
        Me.gb_matr.Controls.Add(Me.Lb_matrgruppe)
        Me.gb_matr.Controls.Add(Me.Lb_klasse)
        Me.gb_matr.Controls.Add(Me.Label89)
        Me.gb_matr.Controls.Add(Me.lb_emnev�gt)
        Me.gb_matr.Controls.Add(Me.Label8)
        Me.gb_matr.Controls.Add(Me.lb_modulstr)
        Me.gb_matr.Controls.Add(Me.Label21)
        Me.gb_matr.Controls.Add(Me.lb_spildtype)
        Me.gb_matr.Controls.Add(Me.Label19)
        Me.gb_matr.Controls.Add(Me.Label13)
        Me.gb_matr.Controls.Add(Me.rb_netto)
        Me.gb_matr.Controls.Add(Me.lb_pladeformatY)
        Me.gb_matr.Controls.Add(Me.rb_brutto)
        Me.gb_matr.Controls.Add(Me.lb_spild)
        Me.gb_matr.Controls.Add(Me.cb_materiale)
        Me.gb_matr.Controls.Add(Me.lb_emner_prplade)
        Me.gb_matr.Controls.Add(Me.lb_pladeformatX)
        Me.gb_matr.Controls.Add(Me.lb_tykkelse)
        Me.gb_matr.Controls.Add(Me.lb_antalplader)
        Me.gb_matr.Controls.Add(Me.tb_pladetykkelse)
        Me.gb_matr.Controls.Add(Me.Label14)
        Me.gb_matr.Controls.Add(Me.Label15)
        Me.gb_matr.Controls.Add(Me.Label16)
        Me.gb_matr.Controls.Add(Me.Label17)
        Me.gb_matr.Controls.Add(Me.Label5)
        Me.gb_matr.Controls.Add(Me.Label18)
        Me.gb_matr.Controls.Add(Me.Label6)
        Me.gb_matr.Controls.Add(Me.Label7)
        Me.gb_matr.Controls.Add(Me.Label10)
        Me.gb_matr.Location = New System.Drawing.Point(992, 30)
        Me.gb_matr.Name = "gb_matr"
        Me.gb_matr.Size = New System.Drawing.Size(272, 328)
        Me.gb_matr.TabIndex = 243
        Me.gb_matr.TabStop = False
        Me.gb_matr.Text = " V�LG MATERIALE"
        '
        'Label149
        '
        Me.Label149.AutoSize = True
        Me.Label149.Location = New System.Drawing.Point(188, 123)
        Me.Label149.Name = "Label149"
        Me.Label149.Size = New System.Drawing.Size(22, 13)
        Me.Label149.TabIndex = 309
        Me.Label149.Text = "UK"
        '
        'tb_sv�rhed_uk
        '
        Me.tb_sv�rhed_uk.Location = New System.Drawing.Point(181, 137)
        Me.tb_sv�rhed_uk.Name = "tb_sv�rhed_uk"
        Me.tb_sv�rhed_uk.Size = New System.Drawing.Size(35, 20)
        Me.tb_sv�rhed_uk.TabIndex = 308
        Me.tb_sv�rhed_uk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lb_faktor
        '
        Me.lb_faktor.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_faktor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_faktor.Location = New System.Drawing.Point(220, 137)
        Me.lb_faktor.Name = "lb_faktor"
        Me.lb_faktor.Size = New System.Drawing.Size(45, 20)
        Me.lb_faktor.TabIndex = 307
        Me.lb_faktor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(218, 122)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(37, 13)
        Me.Label20.TabIndex = 306
        Me.Label20.Text = "Faktor"
        '
        'lb_sv�rhed
        '
        Me.lb_sv�rhed.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_sv�rhed.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_sv�rhed.Location = New System.Drawing.Point(96, 137)
        Me.lb_sv�rhed.Name = "lb_sv�rhed"
        Me.lb_sv�rhed.Size = New System.Drawing.Size(53, 20)
        Me.lb_sv�rhed.TabIndex = 305
        Me.lb_sv�rhed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cb_frav�lg
        '
        Me.cb_frav�lg.AutoSize = True
        Me.cb_frav�lg.Checked = True
        Me.cb_frav�lg.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cb_frav�lg.Location = New System.Drawing.Point(34, 308)
        Me.cb_frav�lg.Name = "cb_frav�lg"
        Me.cb_frav�lg.Size = New System.Drawing.Size(197, 17)
        Me.cb_frav�lg.TabIndex = 304
        Me.cb_frav�lg.Text = "FRAV�LG overst�rrelse 2000x4000"
        Me.cb_frav�lg.UseVisualStyleBackColor = True
        '
        'lb_spildnetto
        '
        Me.lb_spildnetto.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_spildnetto.ForeColor = System.Drawing.Color.Red
        Me.lb_spildnetto.Location = New System.Drawing.Point(176, 237)
        Me.lb_spildnetto.Name = "lb_spildnetto"
        Me.lb_spildnetto.Size = New System.Drawing.Size(75, 15)
        Me.lb_spildnetto.TabIndex = 303
        '
        'Lb_Kilopris
        '
        Me.Lb_Kilopris.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Lb_Kilopris.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lb_Kilopris.Location = New System.Drawing.Point(96, 237)
        Me.Lb_Kilopris.Name = "Lb_Kilopris"
        Me.Lb_Kilopris.Size = New System.Drawing.Size(53, 20)
        Me.Lb_Kilopris.TabIndex = 302
        Me.Lb_Kilopris.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label92
        '
        Me.Label92.AutoSize = True
        Me.Label92.Location = New System.Drawing.Point(7, 244)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(83, 13)
        Me.Label92.TabIndex = 301
        Me.Label92.Text = "Salgspris Kr./Kg"
        '
        'Lb_matrgruppe
        '
        Me.Lb_matrgruppe.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Lb_matrgruppe.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lb_matrgruppe.Location = New System.Drawing.Point(96, 97)
        Me.Lb_matrgruppe.Name = "Lb_matrgruppe"
        Me.Lb_matrgruppe.Size = New System.Drawing.Size(53, 20)
        Me.Lb_matrgruppe.TabIndex = 300
        Me.Lb_matrgruppe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Lb_klasse
        '
        Me.Lb_klasse.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Lb_klasse.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lb_klasse.Location = New System.Drawing.Point(96, 117)
        Me.Lb_klasse.Name = "Lb_klasse"
        Me.Lb_klasse.Size = New System.Drawing.Size(53, 20)
        Me.Lb_klasse.TabIndex = 299
        Me.Lb_klasse.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Location = New System.Drawing.Point(7, 120)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(38, 13)
        Me.Label89.TabIndex = 298
        Me.Label89.Text = "Klasse"
        '
        'lb_emnev�gt
        '
        Me.lb_emnev�gt.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_emnev�gt.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_emnev�gt.Location = New System.Drawing.Point(211, 197)
        Me.lb_emnev�gt.Name = "lb_emnev�gt"
        Me.lb_emnev�gt.Size = New System.Drawing.Size(53, 20)
        Me.lb_emnev�gt.TabIndex = 296
        Me.lb_emnev�gt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(155, 204)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(62, 13)
        Me.Label8.TabIndex = 295
        Me.Label8.Text = "Emnev�gt "
        '
        'lb_modulstr
        '
        Me.lb_modulstr.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_modulstr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_modulstr.Location = New System.Drawing.Point(96, 78)
        Me.lb_modulstr.Name = "lb_modulstr"
        Me.lb_modulstr.Size = New System.Drawing.Size(53, 20)
        Me.lb_modulstr.TabIndex = 294
        Me.lb_modulstr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(155, 161)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(75, 13)
        Me.Label21.TabIndex = 289
        Me.Label21.Text = "ved ordrestr. 1"
        '
        'lb_spildtype
        '
        Me.lb_spildtype.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_spildtype.ForeColor = System.Drawing.Color.Red
        Me.lb_spildtype.Location = New System.Drawing.Point(176, 221)
        Me.lb_spildtype.Name = "lb_spildtype"
        Me.lb_spildtype.Size = New System.Drawing.Size(75, 15)
        Me.lb_spildtype.TabIndex = 288
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(158, 53)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(23, 13)
        Me.Label19.TabIndex = 287
        Me.Label19.Text = "mm"
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(151, 176)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(19, 20)
        Me.Label13.TabIndex = 286
        Me.Label13.Text = "x"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_pladeformatY
        '
        Me.lb_pladeformatY.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_pladeformatY.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_pladeformatY.Location = New System.Drawing.Point(167, 177)
        Me.lb_pladeformatY.Name = "lb_pladeformatY"
        Me.lb_pladeformatY.Size = New System.Drawing.Size(53, 20)
        Me.lb_pladeformatY.TabIndex = 285
        Me.lb_pladeformatY.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_spild
        '
        Me.lb_spild.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_spild.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_spild.Location = New System.Drawing.Point(96, 217)
        Me.lb_spild.Name = "lb_spild"
        Me.lb_spild.Size = New System.Drawing.Size(53, 20)
        Me.lb_spild.TabIndex = 284
        Me.lb_spild.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_emner_prplade
        '
        Me.lb_emner_prplade.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_emner_prplade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_emner_prplade.Location = New System.Drawing.Point(96, 197)
        Me.lb_emner_prplade.Name = "lb_emner_prplade"
        Me.lb_emner_prplade.Size = New System.Drawing.Size(53, 20)
        Me.lb_emner_prplade.TabIndex = 283
        Me.lb_emner_prplade.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_pladeformatX
        '
        Me.lb_pladeformatX.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_pladeformatX.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_pladeformatX.Location = New System.Drawing.Point(96, 177)
        Me.lb_pladeformatX.Name = "lb_pladeformatX"
        Me.lb_pladeformatX.Size = New System.Drawing.Size(53, 20)
        Me.lb_pladeformatX.TabIndex = 282
        Me.lb_pladeformatX.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lb_antalplader
        '
        Me.lb_antalplader.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_antalplader.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_antalplader.Location = New System.Drawing.Point(96, 157)
        Me.lb_antalplader.Name = "lb_antalplader"
        Me.lb_antalplader.Size = New System.Drawing.Size(53, 20)
        Me.lb_antalplader.TabIndex = 281
        Me.lb_antalplader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(148, 221)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(22, 13)
        Me.Label14.TabIndex = 280
        Me.Label14.Text = "M2"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(7, 224)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(30, 13)
        Me.Label15.TabIndex = 279
        Me.Label15.Text = "Spild"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(7, 184)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(63, 13)
        Me.Label16.TabIndex = 274
        Me.Label16.Text = "Pladeformat"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(7, 204)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(81, 13)
        Me.Label17.TabIndex = 273
        Me.Label17.Text = "Emner pr. plade"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(7, 164)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(63, 13)
        Me.Label18.TabIndex = 272
        Me.Label18.Text = "Antal plader"
        '
        'bu_udskriv
        '
        Me.bu_udskriv.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.bu_udskriv.Enabled = False
        Me.bu_udskriv.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bu_udskriv.Location = New System.Drawing.Point(1186, 928)
        Me.bu_udskriv.Name = "bu_udskriv"
        Me.bu_udskriv.Size = New System.Drawing.Size(75, 54)
        Me.bu_udskriv.TabIndex = 245
        Me.bu_udskriv.Text = "UDSKRIV"
        Me.bu_udskriv.UseVisualStyleBackColor = False
        Me.bu_udskriv.Visible = False
        '
        'MetalTilbudDataSet1
        '
        Me.MetalTilbudDataSet1.DataSetName = "MetalTilbudDataSet"
        Me.MetalTilbudDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.LavenderBlush
        Me.GroupBox1.Controls.Add(Me.Label123)
        Me.GroupBox1.Controls.Add(Me.Label131)
        Me.GroupBox1.Controls.Add(Me.tb_slag_til_huller_B)
        Me.GroupBox1.Controls.Add(Me.Label135)
        Me.GroupBox1.Controls.Add(Me.tb_toolshift_B)
        Me.GroupBox1.Controls.Add(Me.Label136)
        Me.GroupBox1.Controls.Add(Me.tb_combiCNC_tid_uk)
        Me.GroupBox1.Controls.Add(Me.Label109)
        Me.GroupBox1.Controls.Add(Me.lb_Combi_opstart)
        Me.GroupBox1.Controls.Add(Me.tb_hulantal_3B)
        Me.GroupBox1.Controls.Add(Me.Label111)
        Me.GroupBox1.Controls.Add(Me.Label112)
        Me.GroupBox1.Controls.Add(Me.Label113)
        Me.GroupBox1.Controls.Add(Me.tb_hulantal_2B)
        Me.GroupBox1.Controls.Add(Me.Label114)
        Me.GroupBox1.Controls.Add(Me.lb_CombiCNC_tid)
        Me.GroupBox1.Controls.Add(Me.tb_cuttinglength_B)
        Me.GroupBox1.Controls.Add(Me.tb_combi_opstart_uk)
        Me.GroupBox1.Controls.Add(Me.Label125)
        Me.GroupBox1.Controls.Add(Me.tb_hulantal_1B)
        Me.GroupBox1.Location = New System.Drawing.Point(263, 470)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(250, 193)
        Me.GroupBox1.TabIndex = 246
        Me.GroupBox1.TabStop = False
        '
        'Label123
        '
        Me.Label123.AutoSize = True
        Me.Label123.Location = New System.Drawing.Point(4, 119)
        Me.Label123.Name = "Label123"
        Me.Label123.Size = New System.Drawing.Size(114, 13)
        Me.Label123.TabIndex = 261
        Me.Label123.Text = "Sk�rel�ngde (>�100)"
        '
        'Label131
        '
        Me.Label131.AutoSize = True
        Me.Label131.Location = New System.Drawing.Point(7, 40)
        Me.Label131.Name = "Label131"
        Me.Label131.Size = New System.Drawing.Size(91, 13)
        Me.Label131.TabIndex = 260
        Me.Label131.Text = "Antal slag til huller"
        '
        'tb_slag_til_huller_B
        '
        Me.tb_slag_til_huller_B.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_slag_til_huller_B.Location = New System.Drawing.Point(132, 37)
        Me.tb_slag_til_huller_B.Name = "tb_slag_til_huller_B"
        Me.tb_slag_til_huller_B.Size = New System.Drawing.Size(53, 20)
        Me.tb_slag_til_huller_B.TabIndex = 41
        '
        'Label135
        '
        Me.Label135.AutoSize = True
        Me.Label135.Location = New System.Drawing.Point(128, 5)
        Me.Label135.Name = "Label135"
        Me.Label135.Size = New System.Drawing.Size(48, 13)
        Me.Label135.TabIndex = 258
        Me.Label135.Text = "pr. emne"
        '
        'tb_toolshift_B
        '
        Me.tb_toolshift_B.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_toolshift_B.Location = New System.Drawing.Point(132, 17)
        Me.tb_toolshift_B.Name = "tb_toolshift_B"
        Me.tb_toolshift_B.Size = New System.Drawing.Size(53, 20)
        Me.tb_toolshift_B.TabIndex = 40
        '
        'Label136
        '
        Me.Label136.AutoSize = True
        Me.Label136.Location = New System.Drawing.Point(6, 21)
        Me.Label136.Name = "Label136"
        Me.Label136.Size = New System.Drawing.Size(71, 13)
        Me.Label136.TabIndex = 256
        Me.Label136.Text = "V�rkt�jsskift "
        '
        'tb_combiCNC_tid_uk
        '
        Me.tb_combiCNC_tid_uk.Location = New System.Drawing.Point(190, 141)
        Me.tb_combiCNC_tid_uk.Name = "tb_combiCNC_tid_uk"
        Me.tb_combiCNC_tid_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_combiCNC_tid_uk.TabIndex = 344
        '
        'Label109
        '
        Me.Label109.AutoSize = True
        Me.Label109.Location = New System.Drawing.Point(4, 101)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(113, 13)
        Me.Label109.TabIndex = 255
        Me.Label109.Text = "Antal huller (�51-�100)"
        '
        'lb_Combi_opstart
        '
        Me.lb_Combi_opstart.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_Combi_opstart.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_Combi_opstart.Location = New System.Drawing.Point(132, 165)
        Me.lb_Combi_opstart.Name = "lb_Combi_opstart"
        Me.lb_Combi_opstart.Size = New System.Drawing.Size(53, 20)
        Me.lb_Combi_opstart.TabIndex = 254
        '
        'tb_hulantal_3B
        '
        Me.tb_hulantal_3B.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_hulantal_3B.Location = New System.Drawing.Point(132, 97)
        Me.tb_hulantal_3B.Name = "tb_hulantal_3B"
        Me.tb_hulantal_3B.Size = New System.Drawing.Size(53, 20)
        Me.tb_hulantal_3B.TabIndex = 44
        '
        'Label111
        '
        Me.Label111.AutoSize = True
        Me.Label111.Location = New System.Drawing.Point(187, 125)
        Me.Label111.Name = "Label111"
        Me.Label111.Size = New System.Drawing.Size(60, 13)
        Me.Label111.TabIndex = 246
        Me.Label111.Text = "Underkend"
        '
        'Label112
        '
        Me.Label112.AutoSize = True
        Me.Label112.Location = New System.Drawing.Point(4, 82)
        Me.Label112.Name = "Label112"
        Me.Label112.Size = New System.Drawing.Size(107, 13)
        Me.Label112.TabIndex = 253
        Me.Label112.Text = "Antal huller (�11-�50)"
        '
        'Label113
        '
        Me.Label113.AutoSize = True
        Me.Label113.Location = New System.Drawing.Point(21, 144)
        Me.Label113.Name = "Label113"
        Me.Label113.Size = New System.Drawing.Size(91, 13)
        Me.Label113.TabIndex = 247
        Me.Label113.Text = "CNC min./100 stk"
        '
        'tb_hulantal_2B
        '
        Me.tb_hulantal_2B.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_hulantal_2B.Location = New System.Drawing.Point(132, 77)
        Me.tb_hulantal_2B.Name = "tb_hulantal_2B"
        Me.tb_hulantal_2B.Size = New System.Drawing.Size(53, 20)
        Me.tb_hulantal_2B.TabIndex = 43
        '
        'Label114
        '
        Me.Label114.AutoSize = True
        Me.Label114.Location = New System.Drawing.Point(21, 168)
        Me.Label114.Name = "Label114"
        Me.Label114.Size = New System.Drawing.Size(63, 13)
        Me.Label114.TabIndex = 253
        Me.Label114.Text = "Opstart min."
        '
        'lb_CombiCNC_tid
        '
        Me.lb_CombiCNC_tid.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_CombiCNC_tid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_CombiCNC_tid.Location = New System.Drawing.Point(132, 141)
        Me.lb_CombiCNC_tid.Name = "lb_CombiCNC_tid"
        Me.lb_CombiCNC_tid.Size = New System.Drawing.Size(53, 20)
        Me.lb_CombiCNC_tid.TabIndex = 251
        '
        'tb_cuttinglength_B
        '
        Me.tb_cuttinglength_B.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_cuttinglength_B.Location = New System.Drawing.Point(132, 117)
        Me.tb_cuttinglength_B.Name = "tb_cuttinglength_B"
        Me.tb_cuttinglength_B.Size = New System.Drawing.Size(53, 20)
        Me.tb_cuttinglength_B.TabIndex = 45
        '
        'tb_combi_opstart_uk
        '
        Me.tb_combi_opstart_uk.Location = New System.Drawing.Point(190, 165)
        Me.tb_combi_opstart_uk.Name = "tb_combi_opstart_uk"
        Me.tb_combi_opstart_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_combi_opstart_uk.TabIndex = 345
        '
        'Label125
        '
        Me.Label125.AutoSize = True
        Me.Label125.Location = New System.Drawing.Point(4, 63)
        Me.Label125.Name = "Label125"
        Me.Label125.Size = New System.Drawing.Size(101, 13)
        Me.Label125.TabIndex = 248
        Me.Label125.Text = "Antal huller (�2-�10)"
        '
        'tb_hulantal_1B
        '
        Me.tb_hulantal_1B.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.tb_hulantal_1B.Location = New System.Drawing.Point(132, 57)
        Me.tb_hulantal_1B.Name = "tb_hulantal_1B"
        Me.tb_hulantal_1B.Size = New System.Drawing.Size(53, 20)
        Me.tb_hulantal_1B.TabIndex = 42
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.LavenderBlush
        Me.GroupBox2.Controls.Add(Me.tb_klip_tid_uk)
        Me.GroupBox2.Controls.Add(Me.lb_klip_opstart)
        Me.GroupBox2.Controls.Add(Me.Label127)
        Me.GroupBox2.Controls.Add(Me.Label129)
        Me.GroupBox2.Controls.Add(Me.lb_klip_tid)
        Me.GroupBox2.Controls.Add(Me.tb_klip_opstart_uk)
        Me.GroupBox2.Location = New System.Drawing.Point(263, 687)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(252, 69)
        Me.GroupBox2.TabIndex = 247
        Me.GroupBox2.TabStop = False
        '
        'tb_klip_tid_uk
        '
        Me.tb_klip_tid_uk.Location = New System.Drawing.Point(187, 13)
        Me.tb_klip_tid_uk.Name = "tb_klip_tid_uk"
        Me.tb_klip_tid_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_klip_tid_uk.TabIndex = 362
        '
        'lb_klip_opstart
        '
        Me.lb_klip_opstart.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_klip_opstart.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_klip_opstart.Location = New System.Drawing.Point(128, 37)
        Me.lb_klip_opstart.Name = "lb_klip_opstart"
        Me.lb_klip_opstart.Size = New System.Drawing.Size(53, 20)
        Me.lb_klip_opstart.TabIndex = 260
        '
        'Label127
        '
        Me.Label127.AutoSize = True
        Me.Label127.Location = New System.Drawing.Point(18, 16)
        Me.Label127.Name = "Label127"
        Me.Label127.Size = New System.Drawing.Size(86, 13)
        Me.Label127.TabIndex = 256
        Me.Label127.Text = "Klip min./100 stk"
        '
        'Label129
        '
        Me.Label129.AutoSize = True
        Me.Label129.Location = New System.Drawing.Point(18, 40)
        Me.Label129.Name = "Label129"
        Me.Label129.Size = New System.Drawing.Size(63, 13)
        Me.Label129.TabIndex = 259
        Me.Label129.Text = "Opstart min."
        '
        'lb_klip_tid
        '
        Me.lb_klip_tid.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_klip_tid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_klip_tid.Location = New System.Drawing.Point(128, 13)
        Me.lb_klip_tid.Name = "lb_klip_tid"
        Me.lb_klip_tid.Size = New System.Drawing.Size(53, 20)
        Me.lb_klip_tid.TabIndex = 257
        '
        'tb_klip_opstart_uk
        '
        Me.tb_klip_opstart_uk.Location = New System.Drawing.Point(187, 37)
        Me.tb_klip_opstart_uk.Name = "tb_klip_opstart_uk"
        Me.tb_klip_opstart_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_klip_opstart_uk.TabIndex = 363
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label9.Location = New System.Drawing.Point(71, 618)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(186, 18)
        Me.Label9.TabIndex = 261
        Me.Label9.Text = "Gruppe 1"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label110
        '
        Me.Label110.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label110.Location = New System.Drawing.Point(319, 279)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(192, 18)
        Me.Label110.TabIndex = 262
        Me.Label110.Text = "Gruppe 1"
        Me.Label110.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label124
        '
        Me.Label124.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label124.Location = New System.Drawing.Point(325, 455)
        Me.Label124.Name = "Label124"
        Me.Label124.Size = New System.Drawing.Size(186, 18)
        Me.Label124.TabIndex = 263
        Me.Label124.Text = "Gruppe 1"
        Me.Label124.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label138
        '
        Me.Label138.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label138.Location = New System.Drawing.Point(306, 674)
        Me.Label138.Name = "Label138"
        Me.Label138.Size = New System.Drawing.Size(207, 18)
        Me.Label138.TabIndex = 264
        Me.Label138.Text = "Gruppe 1"
        Me.Label138.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lb_r�kkeantal
        '
        Me.lb_r�kkeantal.AutoSize = True
        Me.lb_r�kkeantal.Location = New System.Drawing.Point(1216, 897)
        Me.lb_r�kkeantal.Name = "lb_r�kkeantal"
        Me.lb_r�kkeantal.Size = New System.Drawing.Size(0, 13)
        Me.lb_r�kkeantal.TabIndex = 363
        Me.lb_r�kkeantal.Visible = False
        '
        'gb_forbrug
        '
        Me.gb_forbrug.BackColor = System.Drawing.Color.WhiteSmoke
        Me.gb_forbrug.Controls.Add(Me.Label199)
        Me.gb_forbrug.Controls.Add(Me.tb_svejsestag_kr_uk)
        Me.gb_forbrug.Controls.Add(Me.tb_tilsatsmatr_kr_uk)
        Me.gb_forbrug.Controls.Add(Me.tb_pressnut_kr_uk)
        Me.gb_forbrug.Controls.Add(Me.Label196)
        Me.gb_forbrug.Controls.Add(Me.lb_tilsatsmatr_kr)
        Me.gb_forbrug.Controls.Add(Me.Label198)
        Me.gb_forbrug.Controls.Add(Me.Label193)
        Me.gb_forbrug.Controls.Add(Me.lb_svejsestag_kr)
        Me.gb_forbrug.Controls.Add(Me.Label195)
        Me.gb_forbrug.Controls.Add(Me.Label191)
        Me.gb_forbrug.Controls.Add(Me.lb_pressnut_kr)
        Me.gb_forbrug.Controls.Add(Me.Label190)
        Me.gb_forbrug.Location = New System.Drawing.Point(992, 361)
        Me.gb_forbrug.Name = "gb_forbrug"
        Me.gb_forbrug.Size = New System.Drawing.Size(272, 90)
        Me.gb_forbrug.TabIndex = 364
        Me.gb_forbrug.TabStop = False
        Me.gb_forbrug.Text = "Forbrug"
        '
        'Label199
        '
        Me.Label199.AutoSize = True
        Me.Label199.Location = New System.Drawing.Point(203, 7)
        Me.Label199.Name = "Label199"
        Me.Label199.Size = New System.Drawing.Size(60, 13)
        Me.Label199.TabIndex = 243
        Me.Label199.Text = "Underkend"
        '
        'tb_svejsestag_kr_uk
        '
        Me.tb_svejsestag_kr_uk.Location = New System.Drawing.Point(207, 43)
        Me.tb_svejsestag_kr_uk.Name = "tb_svejsestag_kr_uk"
        Me.tb_svejsestag_kr_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_svejsestag_kr_uk.TabIndex = 219
        '
        'tb_tilsatsmatr_kr_uk
        '
        Me.tb_tilsatsmatr_kr_uk.Location = New System.Drawing.Point(207, 63)
        Me.tb_tilsatsmatr_kr_uk.Name = "tb_tilsatsmatr_kr_uk"
        Me.tb_tilsatsmatr_kr_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_tilsatsmatr_kr_uk.TabIndex = 220
        '
        'tb_pressnut_kr_uk
        '
        Me.tb_pressnut_kr_uk.Location = New System.Drawing.Point(207, 23)
        Me.tb_pressnut_kr_uk.Name = "tb_pressnut_kr_uk"
        Me.tb_pressnut_kr_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_pressnut_kr_uk.TabIndex = 218
        '
        'Label196
        '
        Me.Label196.AutoSize = True
        Me.Label196.Location = New System.Drawing.Point(136, 66)
        Me.Label196.Name = "Label196"
        Me.Label196.Size = New System.Drawing.Size(64, 13)
        Me.Label196.TabIndex = 217
        Me.Label196.Text = "Kr. pr. emne"
        '
        'lb_tilsatsmatr_kr
        '
        Me.lb_tilsatsmatr_kr.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_tilsatsmatr_kr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_tilsatsmatr_kr.Location = New System.Drawing.Point(91, 63)
        Me.lb_tilsatsmatr_kr.Name = "lb_tilsatsmatr_kr"
        Me.lb_tilsatsmatr_kr.Size = New System.Drawing.Size(44, 20)
        Me.lb_tilsatsmatr_kr.TabIndex = 215
        Me.lb_tilsatsmatr_kr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label198
        '
        Me.Label198.AutoSize = True
        Me.Label198.Location = New System.Drawing.Point(7, 66)
        Me.Label198.Name = "Label198"
        Me.Label198.Size = New System.Drawing.Size(53, 13)
        Me.Label198.TabIndex = 216
        Me.Label198.Text = "tilsatsmatr"
        '
        'Label193
        '
        Me.Label193.AutoSize = True
        Me.Label193.Location = New System.Drawing.Point(136, 45)
        Me.Label193.Name = "Label193"
        Me.Label193.Size = New System.Drawing.Size(64, 13)
        Me.Label193.TabIndex = 214
        Me.Label193.Text = "Kr. pr. emne"
        '
        'lb_svejsestag_kr
        '
        Me.lb_svejsestag_kr.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_svejsestag_kr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_svejsestag_kr.Location = New System.Drawing.Point(91, 43)
        Me.lb_svejsestag_kr.Name = "lb_svejsestag_kr"
        Me.lb_svejsestag_kr.Size = New System.Drawing.Size(44, 20)
        Me.lb_svejsestag_kr.TabIndex = 212
        Me.lb_svejsestag_kr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label195
        '
        Me.Label195.AutoSize = True
        Me.Label195.Location = New System.Drawing.Point(7, 45)
        Me.Label195.Name = "Label195"
        Me.Label195.Size = New System.Drawing.Size(59, 13)
        Me.Label195.TabIndex = 213
        Me.Label195.Text = "Svejsestag"
        '
        'Label191
        '
        Me.Label191.AutoSize = True
        Me.Label191.Location = New System.Drawing.Point(136, 25)
        Me.Label191.Name = "Label191"
        Me.Label191.Size = New System.Drawing.Size(64, 13)
        Me.Label191.TabIndex = 210
        Me.Label191.Text = "Kr. pr. emne"
        '
        'lb_pressnut_kr
        '
        Me.lb_pressnut_kr.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lb_pressnut_kr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lb_pressnut_kr.Location = New System.Drawing.Point(91, 23)
        Me.lb_pressnut_kr.Name = "lb_pressnut_kr"
        Me.lb_pressnut_kr.Size = New System.Drawing.Size(44, 20)
        Me.lb_pressnut_kr.TabIndex = 208
        Me.lb_pressnut_kr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label190
        '
        Me.Label190.AutoSize = True
        Me.Label190.Location = New System.Drawing.Point(7, 25)
        Me.Label190.Name = "Label190"
        Me.Label190.Size = New System.Drawing.Size(81, 13)
        Me.Label190.TabIndex = 209
        Me.Label190.Text = "Presm�trik/stag"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1059, 928)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(58, 54)
        Me.Button1.TabIndex = 365
        Me.Button1.UseVisualStyleBackColor = True
        Me.Button1.Visible = False
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(1122, 928)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(58, 54)
        Me.Button2.TabIndex = 366
        Me.Button2.UseVisualStyleBackColor = True
        Me.Button2.Visible = False
        '
        'tb_Kilopris_uk
        '
        Me.tb_Kilopris_uk.Location = New System.Drawing.Point(96, 260)
        Me.tb_Kilopris_uk.Name = "tb_Kilopris_uk"
        Me.tb_Kilopris_uk.Size = New System.Drawing.Size(53, 20)
        Me.tb_Kilopris_uk.TabIndex = 310
        Me.tb_Kilopris_uk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label177
        '
        Me.Label177.AutoSize = True
        Me.Label177.Location = New System.Drawing.Point(150, 264)
        Me.Label177.Name = "Label177"
        Me.Label177.Size = New System.Drawing.Size(38, 13)
        Me.Label177.TabIndex = 311
        Me.Label177.Text = "Kr./Kg"
        '
        'Label178
        '
        Me.Label178.AutoSize = True
        Me.Label178.Location = New System.Drawing.Point(7, 265)
        Me.Label178.Name = "Label178"
        Me.Label178.Size = New System.Drawing.Size(86, 13)
        Me.Label178.TabIndex = 312
        Me.Label178.Text = "Underk. Salgspr."
        '
        'metal_tilbud
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.FloralWhite
        Me.ClientSize = New System.Drawing.Size(1270, 992)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.gb_forbrug)
        Me.Controls.Add(Me.lb_r�kkeantal)
        Me.Controls.Add(Me.Label138)
        Me.Controls.Add(Me.Label124)
        Me.Controls.Add(Me.Label110)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.rb_klip)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.gb_gruppe4)
        Me.Controls.Add(Me.bu_udskriv)
        Me.Controls.Add(Me.bu_Reset)
        Me.Controls.Add(Me.rb_B_kombi)
        Me.Controls.Add(Me.gb_matr)
        Me.Controls.Add(Me.rb_D_stans)
        Me.Controls.Add(Me.gb_opstart)
        Me.Controls.Add(Me.gb_pristabel)
        Me.Controls.Add(Me.gb_hul)
        Me.Controls.Add(Me.cb_Tegning)
        Me.Controls.Add(Me.gb_indk�b)
        Me.Controls.Add(Me.gb_overfladebeh)
        Me.Controls.Add(Me.rb_C_laser)
        Me.Controls.Add(Me.gb_admin)
        Me.Controls.Add(Me.gb_gruppe5)
        Me.Controls.Add(Me.gb_gruppe3)
        Me.Controls.Add(Me.gb_gruppe2)
        Me.Controls.Add(Me.gb_gruppe1)
        Me.Controls.Add(Me.gb_buk)
        Me.Controls.Add(Me.Label78)
        Me.Controls.Add(Me.rtb_bem)
        Me.Controls.Add(Me.Label57)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.tb_revision)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.tb_emne)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cb_kunde)
        Me.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "metal_tilbud"
        Me.Text = "METAL TILBUDSPROGRAM"
        Me.gb_gruppe1.ResumeLayout(False)
        Me.gb_gruppe1.PerformLayout()
        Me.gb_gruppe2.ResumeLayout(False)
        Me.gb_gruppe2.PerformLayout()
        Me.gb_gevind.ResumeLayout(False)
        Me.gb_gevind.PerformLayout()
        Me.gb_unders�nk.ResumeLayout(False)
        Me.gb_unders�nk.PerformLayout()
        Me.gb_gruppe3.ResumeLayout(False)
        Me.gb_gruppe3.PerformLayout()
        Me.gb_gruppe4.ResumeLayout(False)
        Me.gb_gruppe4.PerformLayout()
        Me.GroupBox15.ResumeLayout(False)
        Me.GroupBox15.PerformLayout()
        Me.gb_gruppe5.ResumeLayout(False)
        Me.gb_gruppe5.PerformLayout()
        Me.gb_admin.ResumeLayout(False)
        Me.gb_admin.PerformLayout()
        Me.gb_overfladebeh.ResumeLayout(False)
        Me.gb_overfladebeh.PerformLayout()
        Me.gb_buk.ResumeLayout(False)
        Me.gb_buk.PerformLayout()
        Me.gb_hul.ResumeLayout(False)
        Me.gb_hul.PerformLayout()
        Me.gb_pristabel.ResumeLayout(False)
        Me.gb_pristabel.PerformLayout()
        Me.gb_opstart.ResumeLayout(False)
        Me.gb_opstart.PerformLayout()
        Me.gb_matr.ResumeLayout(False)
        Me.gb_matr.PerformLayout()
        CType(Me.MetalTilbudDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.gb_forbrug.ResumeLayout(False)
        Me.gb_forbrug.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents rtb_bem As System.Windows.Forms.RichTextBox
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents lb_operat�r As System.Windows.Forms.Label
    Friend WithEvents lb_dato As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents tb_opstart_afgivettilbud As System.Windows.Forms.TextBox
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents tb_opstart_avance As System.Windows.Forms.TextBox
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents lb_opst_prog_brutto As System.Windows.Forms.Label
    Friend WithEvents lb_opstart_program As System.Windows.Forms.Label
    Friend WithEvents lb_program_kr As System.Windows.Forms.Label
    Friend WithEvents lb_antal_opstart As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents tb_tilbud2 As System.Windows.Forms.TextBox
    Friend WithEvents tb_tilbud3 As System.Windows.Forms.TextBox
    Friend WithEvents tb_tilbud4 As System.Windows.Forms.TextBox
    Friend WithEvents tb_tilbud5 As System.Windows.Forms.TextBox
    Friend WithEvents tb_tilbud1 As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents tb_avance As System.Windows.Forms.TextBox
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents lb_salg2 As System.Windows.Forms.Label
    Friend WithEvents lb_salg3 As System.Windows.Forms.Label
    Friend WithEvents lb_salg4 As System.Windows.Forms.Label
    Friend WithEvents lb_salg5 As System.Windows.Forms.Label
    Friend WithEvents lb_salg1 As System.Windows.Forms.Label
    Friend WithEvents lb_samlet2 As System.Windows.Forms.Label
    Friend WithEvents lb_samlet3 As System.Windows.Forms.Label
    Friend WithEvents lb_samlet4 As System.Windows.Forms.Label
    Friend WithEvents lb_samlet5 As System.Windows.Forms.Label
    Friend WithEvents lb_samlet1 As System.Windows.Forms.Label
    Friend WithEvents lb_cnc2 As System.Windows.Forms.Label
    Friend WithEvents lb_cnc3 As System.Windows.Forms.Label
    Friend WithEvents lb_cnc4 As System.Windows.Forms.Label
    Friend WithEvents lb_cnc5 As System.Windows.Forms.Label
    Friend WithEvents lb_cnc1 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents lb_timer5 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents lb_indk�b2 As System.Windows.Forms.Label
    Friend WithEvents lb_indk�b3 As System.Windows.Forms.Label
    Friend WithEvents lb_indk�b4 As System.Windows.Forms.Label
    Friend WithEvents lb_indk�b5 As System.Windows.Forms.Label
    Friend WithEvents lb_indk�b1 As System.Windows.Forms.Label
    Friend WithEvents lb_r�varer2 As System.Windows.Forms.Label
    Friend WithEvents lb_r�varer3 As System.Windows.Forms.Label
    Friend WithEvents lb_r�varer4 As System.Windows.Forms.Label
    Friend WithEvents lb_r�varer5 As System.Windows.Forms.Label
    Friend WithEvents lb_r�varerstk1 As System.Windows.Forms.Label
    Friend WithEvents lb_mand2 As System.Windows.Forms.Label
    Friend WithEvents lb_mand3 As System.Windows.Forms.Label
    Friend WithEvents lb_mand4 As System.Windows.Forms.Label
    Friend WithEvents lb_mand5 As System.Windows.Forms.Label
    Friend WithEvents lb_mand1 As System.Windows.Forms.Label
    Friend WithEvents tb_antal2 As System.Windows.Forms.TextBox
    Friend WithEvents tb_antal3 As System.Windows.Forms.TextBox
    Friend WithEvents tb_antal4 As System.Windows.Forms.TextBox
    Friend WithEvents tb_antal5 As System.Windows.Forms.TextBox
    Friend WithEvents tb_antal1 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents tb_revision As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents tb_emne As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cb_kunde As System.Windows.Forms.ComboBox
    Friend WithEvents bu_Reset As System.Windows.Forms.Button
    Friend WithEvents lb_tykkelse As System.Windows.Forms.Label
    Friend WithEvents tb_pladetykkelse As System.Windows.Forms.TextBox
    Friend WithEvents cb_materiale As System.Windows.Forms.ComboBox
    Friend WithEvents gb_gruppe1 As System.Windows.Forms.GroupBox
    Friend WithEvents gb_gruppe2 As System.Windows.Forms.GroupBox
    Friend WithEvents gb_gruppe3 As System.Windows.Forms.GroupBox
    Friend WithEvents gb_gruppe4 As System.Windows.Forms.GroupBox
    Friend WithEvents gb_gruppe5 As System.Windows.Forms.GroupBox
    Friend WithEvents gb_admin As System.Windows.Forms.GroupBox
    Friend WithEvents gb_overfladebeh As System.Windows.Forms.GroupBox
    Friend WithEvents gb_indk�b As System.Windows.Forms.GroupBox
    Friend WithEvents tb_bukmax_y As System.Windows.Forms.TextBox
    Friend WithEvents tb_bukmax_x As System.Windows.Forms.TextBox
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents gb_buk As System.Windows.Forms.GroupBox
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents tb_buk5_x As System.Windows.Forms.TextBox
    Friend WithEvents tb_buk5_y As System.Windows.Forms.TextBox
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents tb_buk4_x As System.Windows.Forms.TextBox
    Friend WithEvents tb_buk4_y As System.Windows.Forms.TextBox
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents tb_buk3_x As System.Windows.Forms.TextBox
    Friend WithEvents tb_buk3_y As System.Windows.Forms.TextBox
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents tb_buk2_x As System.Windows.Forms.TextBox
    Friend WithEvents tb_buk2_y As System.Windows.Forms.TextBox
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents tb_buk1_x As System.Windows.Forms.TextBox
    Friend WithEvents tb_buk1_y As System.Windows.Forms.TextBox
    Friend WithEvents lb_udfold_y As System.Windows.Forms.Label
    Friend WithEvents lb_udfold_x As System.Windows.Forms.Label
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents tb_buk11_x As System.Windows.Forms.TextBox
    Friend WithEvents tb_buk11_y As System.Windows.Forms.TextBox
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents tb_buk10_x As System.Windows.Forms.TextBox
    Friend WithEvents tb_buk10_y As System.Windows.Forms.TextBox
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents tb_buk9_x As System.Windows.Forms.TextBox
    Friend WithEvents tb_buk9_y As System.Windows.Forms.TextBox
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents tb_buk8_x As System.Windows.Forms.TextBox
    Friend WithEvents tb_buk8_y As System.Windows.Forms.TextBox
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents tb_buk7_x As System.Windows.Forms.TextBox
    Friend WithEvents tb_buk7_y As System.Windows.Forms.TextBox
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents tb_buk6_x As System.Windows.Forms.TextBox
    Friend WithEvents tb_buk6_y As System.Windows.Forms.TextBox
    Friend WithEvents cb_Tegning As System.Windows.Forms.ComboBox
    Friend WithEvents gb_hul As System.Windows.Forms.GroupBox
    Friend WithEvents Label88 As System.Windows.Forms.Label
    Friend WithEvents lb_hovedtegning As System.Windows.Forms.Label
    Friend WithEvents tb_opstart_kr_uk As System.Windows.Forms.TextBox
    Friend WithEvents tb_Program_kr_uk As System.Windows.Forms.TextBox
    Friend WithEvents Label91 As System.Windows.Forms.Label
    Friend WithEvents Label94 As System.Windows.Forms.Label
    Friend WithEvents Label93 As System.Windows.Forms.Label
    Friend WithEvents lb_buk_tid As System.Windows.Forms.Label
    Friend WithEvents tb_buk_uk As System.Windows.Forms.TextBox
    Friend WithEvents Label96 As System.Windows.Forms.Label
    Friend WithEvents Label95 As System.Windows.Forms.Label
    Friend WithEvents tb_vibration_uk As System.Windows.Forms.TextBox
    Friend WithEvents tb_boltesvejs_uk As System.Windows.Forms.TextBox
    Friend WithEvents tb_afgrat_uk As System.Windows.Forms.TextBox
    Friend WithEvents Label106 As System.Windows.Forms.Label
    Friend WithEvents tb_pressnut_uk As System.Windows.Forms.TextBox
    Friend WithEvents tb_grinding_uk As System.Windows.Forms.TextBox
    Friend WithEvents Label105 As System.Windows.Forms.Label
    Friend WithEvents tb_gevind_uk As System.Windows.Forms.TextBox
    Friend WithEvents tb_brush_uk As System.Windows.Forms.TextBox
    Friend WithEvents Label104 As System.Windows.Forms.Label
    Friend WithEvents tb_countersink_uk As System.Windows.Forms.TextBox
    Friend WithEvents Label103 As System.Windows.Forms.Label
    Friend WithEvents Label101 As System.Windows.Forms.Label
    Friend WithEvents tb_stans_manuel_uk As System.Windows.Forms.TextBox
    Friend WithEvents tb_rette_uk As System.Windows.Forms.TextBox
    Friend WithEvents Label102 As System.Windows.Forms.Label
    Friend WithEvents Label100 As System.Windows.Forms.Label
    Friend WithEvents gb_pristabel As System.Windows.Forms.GroupBox
    Friend WithEvents gb_opstart As System.Windows.Forms.GroupBox
    Friend WithEvents gb_matr As System.Windows.Forms.GroupBox
    Friend WithEvents Label98 As System.Windows.Forms.Label
    Friend WithEvents Label97 As System.Windows.Forms.Label
    Friend WithEvents tb_CNCmin_uk As System.Windows.Forms.TextBox
    Friend WithEvents rb_klip As System.Windows.Forms.RadioButton
    Friend WithEvents rb_C_laser As System.Windows.Forms.RadioButton
    Friend WithEvents rb_D_stans As System.Windows.Forms.RadioButton
    Friend WithEvents Label99 As System.Windows.Forms.Label
    Friend WithEvents lb_gruppe1_tid As System.Windows.Forms.Label
    Friend WithEvents lb_boltesvejs As System.Windows.Forms.Label
    Friend WithEvents lb_pressnut As System.Windows.Forms.Label
    Friend WithEvents lb_gevind As System.Windows.Forms.Label
    Friend WithEvents lb_countersink As System.Windows.Forms.Label
    Friend WithEvents Label118 As System.Windows.Forms.Label
    Friend WithEvents Label117 As System.Windows.Forms.Label
    Friend WithEvents Label116 As System.Windows.Forms.Label
    Friend WithEvents Label115 As System.Windows.Forms.Label
    Friend WithEvents lb_timer2 As System.Windows.Forms.Label
    Friend WithEvents lb_timer3 As System.Windows.Forms.Label
    Friend WithEvents lb_timer4 As System.Windows.Forms.Label
    Friend WithEvents lb_timer1 As System.Windows.Forms.Label
    Friend WithEvents Label122 As System.Windows.Forms.Label
    Friend WithEvents Label121 As System.Windows.Forms.Label
    Friend WithEvents Label120 As System.Windows.Forms.Label
    Friend WithEvents Label119 As System.Windows.Forms.Label
    Friend WithEvents rb_netto As System.Windows.Forms.RadioButton
    Friend WithEvents rb_brutto As System.Windows.Forms.RadioButton
    Friend WithEvents Label128 As System.Windows.Forms.Label
    Friend WithEvents lb_spotweld As System.Windows.Forms.Label
    Friend WithEvents tb_spotweld_uk As System.Windows.Forms.TextBox
    Friend WithEvents Label132 As System.Windows.Forms.Label
    Friend WithEvents lb_grind_weld As System.Windows.Forms.Label
    Friend WithEvents lb_weld As System.Windows.Forms.Label
    Friend WithEvents lb_tackweld As System.Windows.Forms.Label
    Friend WithEvents tb_grind_weld_uk As System.Windows.Forms.TextBox
    Friend WithEvents tb_weld_uk As System.Windows.Forms.TextBox
    Friend WithEvents tb_tackweld_uk As System.Windows.Forms.TextBox
    Friend WithEvents Label137 As System.Windows.Forms.Label
    Friend WithEvents lb_kontrol As System.Windows.Forms.Label
    Friend WithEvents tb_kontrol_uk As System.Windows.Forms.TextBox
    Friend WithEvents Label133 As System.Windows.Forms.Label
    Friend WithEvents Label134 As System.Windows.Forms.Label
    Friend WithEvents lb_kontor As System.Windows.Forms.Label
    Friend WithEvents tb_kontor_uk As System.Windows.Forms.TextBox
    Friend WithEvents rb_B_kombi As System.Windows.Forms.RadioButton
    Friend WithEvents tb_boltesvejs_antal As System.Windows.Forms.TextBox
    Friend WithEvents tb_presm�trik_antal As System.Windows.Forms.TextBox
    Friend WithEvents lb_grinding As System.Windows.Forms.Label
    Friend WithEvents lb_afgrat As System.Windows.Forms.Label
    Friend WithEvents lb_stans_manuel As System.Windows.Forms.Label
    Friend WithEvents lb_rette As System.Windows.Forms.Label
    Friend WithEvents lb_vibration As System.Windows.Forms.Label
    Friend WithEvents lb_brush As System.Windows.Forms.Label
    Friend WithEvents Label147 As System.Windows.Forms.Label
    Friend WithEvents Label151 As System.Windows.Forms.Label
    Friend WithEvents Label148 As System.Windows.Forms.Label
    Friend WithEvents TextBox77 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox76 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox75 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox74 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox73 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox72 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox67 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox68 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox69 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox70 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox71 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox15 As System.Windows.Forms.GroupBox
    Friend WithEvents Label152 As System.Windows.Forms.Label
    Friend WithEvents Label153 As System.Windows.Forms.Label
    Friend WithEvents Label154 As System.Windows.Forms.Label
    Friend WithEvents Label155 As System.Windows.Forms.Label
    Friend WithEvents Label156 As System.Windows.Forms.Label
    Friend WithEvents Label157 As System.Windows.Forms.Label
    Friend WithEvents Label158 As System.Windows.Forms.Label
    Friend WithEvents Label159 As System.Windows.Forms.Label
    Friend WithEvents TextBox78 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox79 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox80 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox81 As System.Windows.Forms.TextBox
    Friend WithEvents Label160 As System.Windows.Forms.Label
    Friend WithEvents Label161 As System.Windows.Forms.Label
    Friend WithEvents Label162 As System.Windows.Forms.Label
    Friend WithEvents Label163 As System.Windows.Forms.Label
    Friend WithEvents Label164 As System.Windows.Forms.Label
    Friend WithEvents Label165 As System.Windows.Forms.Label
    Friend WithEvents Label166 As System.Windows.Forms.Label
    Friend WithEvents Label167 As System.Windows.Forms.Label
    Friend WithEvents Label168 As System.Windows.Forms.Label
    Friend WithEvents Label169 As System.Windows.Forms.Label
    Friend WithEvents Label170 As System.Windows.Forms.Label
    Friend WithEvents TextBox82 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox83 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox84 As System.Windows.Forms.TextBox
    Friend WithEvents Label171 As System.Windows.Forms.Label
    Friend WithEvents TextBox85 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox86 As System.Windows.Forms.TextBox
    Friend WithEvents Label172 As System.Windows.Forms.Label
    Friend WithEvents TextBox87 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox88 As System.Windows.Forms.TextBox
    Friend WithEvents Label173 As System.Windows.Forms.Label
    Friend WithEvents TextBox89 As System.Windows.Forms.TextBox
    Friend WithEvents Label174 As System.Windows.Forms.Label
    Friend WithEvents Label175 As System.Windows.Forms.Label
    Friend WithEvents TextBox90 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox91 As System.Windows.Forms.TextBox
    Friend WithEvents Label176 As System.Windows.Forms.Label
    Friend WithEvents bu_udskriv As System.Windows.Forms.Button
    Friend WithEvents MetalTilbudDataSet1 As Metaltilbud1.MetalTilbudDataSet
    Friend WithEvents lb_gevind_antal As System.Windows.Forms.Label
    Friend WithEvents lb_unders�nk_antal As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents tb_timesats_mand As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents lb_antalplader As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents lb_emner_prplade As System.Windows.Forms.Label
    Friend WithEvents lb_pladeformatX As System.Windows.Forms.Label
    Friend WithEvents lb_pladeformatY As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents lb_spild As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents lb_spildtype As System.Windows.Forms.Label
    Friend WithEvents lb_modulstr As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents lb_buk_opst As System.Windows.Forms.Label
    Friend WithEvents tb_buk_opst_uk As System.Windows.Forms.TextBox
    Friend WithEvents lb_emnev�gt As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents tb_slag_til_huller As System.Windows.Forms.TextBox
    Friend WithEvents tb_toolshift As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents tb_cuttinglength_C As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents tb_timesats_C As System.Windows.Forms.TextBox
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents tb_timesats_B As System.Windows.Forms.TextBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents tb_timesats_D As System.Windows.Forms.TextBox
    Friend WithEvents lb_gruppe1_opstart As System.Windows.Forms.Label
    Friend WithEvents lb_opstart As System.Windows.Forms.Label
    Friend WithEvents tb_gruppe1_opstart_uk As System.Windows.Forms.TextBox
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents tb_hulantal_2C As System.Windows.Forms.TextBox
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents tb_hulantal_3C As System.Windows.Forms.TextBox
    Friend WithEvents lb_laser_opstart As System.Windows.Forms.Label
    Friend WithEvents Label90 As System.Windows.Forms.Label
    Friend WithEvents tb_laser_opstart_uk As System.Windows.Forms.TextBox
    Friend WithEvents lb_laserCNC_tid As System.Windows.Forms.Label
    Friend WithEvents Label107 As System.Windows.Forms.Label
    Friend WithEvents Label108 As System.Windows.Forms.Label
    Friend WithEvents tb_laserCNC_tid_uk As System.Windows.Forms.TextBox
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents tb_hulantal_1C As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents tb_combiCNC_tid_uk As System.Windows.Forms.TextBox
    Friend WithEvents Label109 As System.Windows.Forms.Label
    Friend WithEvents lb_Combi_opstart As System.Windows.Forms.Label
    Friend WithEvents tb_hulantal_3B As System.Windows.Forms.TextBox
    Friend WithEvents Label111 As System.Windows.Forms.Label
    Friend WithEvents Label112 As System.Windows.Forms.Label
    Friend WithEvents Label113 As System.Windows.Forms.Label
    Friend WithEvents tb_hulantal_2B As System.Windows.Forms.TextBox
    Friend WithEvents Label114 As System.Windows.Forms.Label
    Friend WithEvents lb_CombiCNC_tid As System.Windows.Forms.Label
    Friend WithEvents tb_cuttinglength_B As System.Windows.Forms.TextBox
    Friend WithEvents tb_combi_opstart_uk As System.Windows.Forms.TextBox
    Friend WithEvents Label125 As System.Windows.Forms.Label
    Friend WithEvents tb_hulantal_1B As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents tb_klip_tid_uk As System.Windows.Forms.TextBox
    Friend WithEvents lb_klip_opstart As System.Windows.Forms.Label
    Friend WithEvents Label127 As System.Windows.Forms.Label
    Friend WithEvents Label129 As System.Windows.Forms.Label
    Friend WithEvents lb_klip_tid As System.Windows.Forms.Label
    Friend WithEvents tb_klip_opstart_uk As System.Windows.Forms.TextBox
    Friend WithEvents Label131 As System.Windows.Forms.Label
    Friend WithEvents tb_slag_til_huller_B As System.Windows.Forms.TextBox
    Friend WithEvents Label135 As System.Windows.Forms.Label
    Friend WithEvents tb_toolshift_B As System.Windows.Forms.TextBox
    Friend WithEvents Label136 As System.Windows.Forms.Label
    Friend WithEvents Label123 As System.Windows.Forms.Label
    Friend WithEvents Label89 As System.Windows.Forms.Label
    Friend WithEvents Lb_klasse As System.Windows.Forms.Label
    Friend WithEvents Lb_matrgruppe As System.Windows.Forms.Label
    Friend WithEvents Lb_Kilopris As System.Windows.Forms.Label
    Friend WithEvents Label92 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label110 As System.Windows.Forms.Label
    Friend WithEvents Label124 As System.Windows.Forms.Label
    Friend WithEvents Label138 As System.Windows.Forms.Label
    Friend WithEvents Label126 As System.Windows.Forms.Label
    Friend WithEvents cb_afgrat As System.Windows.Forms.CheckBox
    Friend WithEvents cb_steelmaster As System.Windows.Forms.CheckBox
    Friend WithEvents cb_brush As System.Windows.Forms.CheckBox
    Friend WithEvents cb_vibrationsafgr As System.Windows.Forms.CheckBox
    Friend WithEvents cb_rette As System.Windows.Forms.CheckBox
    Friend WithEvents tb_antal_program_uk As System.Windows.Forms.TextBox
    Friend WithEvents tb_antal_opstart_uk As System.Windows.Forms.TextBox
    Friend WithEvents lb_r�kkeantal As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents lb_opstart_kr As System.Windows.Forms.Label
    Friend WithEvents lb_antal_program As System.Windows.Forms.Label
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents tb_overfl_pris1 As System.Windows.Forms.TextBox
    Friend WithEvents tb_overfl_afd�k1 As System.Windows.Forms.TextBox
    Friend WithEvents tb_overfl_opstart1 As System.Windows.Forms.TextBox
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label140 As System.Windows.Forms.Label
    Friend WithEvents tb_overfl_pris100_1 As System.Windows.Forms.Label
    Friend WithEvents Label130 As System.Windows.Forms.Label
    Friend WithEvents tb_overfl_avance1 As System.Windows.Forms.TextBox
    Friend WithEvents tb_overfl_pris100_3 As System.Windows.Forms.Label
    Friend WithEvents tb_overfl_avance3 As System.Windows.Forms.TextBox
    Friend WithEvents tb_overfl_pris3 As System.Windows.Forms.TextBox
    Friend WithEvents tb_overfl_afd�k3 As System.Windows.Forms.TextBox
    Friend WithEvents tb_overfl_opstart3 As System.Windows.Forms.TextBox
    Friend WithEvents tb_overfl_pris100_2 As System.Windows.Forms.Label
    Friend WithEvents tb_overfl_avance2 As System.Windows.Forms.TextBox
    Friend WithEvents tb_overfl_pris2 As System.Windows.Forms.TextBox
    Friend WithEvents tb_overfl_afd�k2 As System.Windows.Forms.TextBox
    Friend WithEvents tb_overfl_opstart2 As System.Windows.Forms.TextBox
    Friend WithEvents tb_overfl_pris100_4 As System.Windows.Forms.Label
    Friend WithEvents tb_overfl_avance4 As System.Windows.Forms.TextBox
    Friend WithEvents tb_overfl_pris4 As System.Windows.Forms.TextBox
    Friend WithEvents tb_overfl_afd�k4 As System.Windows.Forms.TextBox
    Friend WithEvents tb_overfl_opstart4 As System.Windows.Forms.TextBox
    Friend WithEvents cb_overfl_leverand�r2 As System.Windows.Forms.ComboBox
    Friend WithEvents cb_overfl_leverand�r1 As System.Windows.Forms.ComboBox
    Friend WithEvents cb_overfl_leverand�r4 As System.Windows.Forms.ComboBox
    Friend WithEvents cb_overfl_leverand�r3 As System.Windows.Forms.ComboBox
    Friend WithEvents lb_spildnetto As System.Windows.Forms.Label
    Friend WithEvents cb_frav�lg As System.Windows.Forms.CheckBox
    Friend WithEvents lb_CNC1_tid As System.Windows.Forms.Label
    Friend WithEvents lb_mand1_tid As System.Windows.Forms.Label
    Friend WithEvents lb_mand5_tid As System.Windows.Forms.Label
    Friend WithEvents lb_CNC5_tid As System.Windows.Forms.Label
    Friend WithEvents lb_mand4_tid As System.Windows.Forms.Label
    Friend WithEvents lb_CNC4_tid As System.Windows.Forms.Label
    Friend WithEvents lb_mand3_tid As System.Windows.Forms.Label
    Friend WithEvents lb_CNC3_tid As System.Windows.Forms.Label
    Friend WithEvents lb_CNC2_tid As System.Windows.Forms.Label
    Friend WithEvents lb_mand2_tid As System.Windows.Forms.Label
    Friend WithEvents lb_sv�rhed As System.Windows.Forms.Label
    Friend WithEvents lb_faktor As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents tb_m6 As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents tb_m8 As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents tb_m10 As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents tb_m5 As System.Windows.Forms.TextBox
    Friend WithEvents Label139 As System.Windows.Forms.Label
    Friend WithEvents tb_m2_5 As System.Windows.Forms.TextBox
    Friend WithEvents Label141 As System.Windows.Forms.Label
    Friend WithEvents tb_m3 As System.Windows.Forms.TextBox
    Friend WithEvents Label142 As System.Windows.Forms.Label
    Friend WithEvents tb_m4 As System.Windows.Forms.TextBox
    Friend WithEvents Label143 As System.Windows.Forms.Label
    Friend WithEvents Label144 As System.Windows.Forms.Label
    Friend WithEvents Label145 As System.Windows.Forms.Label
    Friend WithEvents tb_m2 As System.Windows.Forms.TextBox
    Friend WithEvents Label179 As System.Windows.Forms.Label
    Friend WithEvents Label180 As System.Windows.Forms.Label
    Friend WithEvents gb_gevind As System.Windows.Forms.GroupBox
    Friend WithEvents gb_unders�nk As System.Windows.Forms.GroupBox
    Friend WithEvents Label182 As System.Windows.Forms.Label
    Friend WithEvents Label181 As System.Windows.Forms.Label
    Friend WithEvents Label183 As System.Windows.Forms.Label
    Friend WithEvents tb_2 As System.Windows.Forms.TextBox
    Friend WithEvents Label184 As System.Windows.Forms.Label
    Friend WithEvents tb_3 As System.Windows.Forms.TextBox
    Friend WithEvents Label185 As System.Windows.Forms.Label
    Friend WithEvents tb_4 As System.Windows.Forms.TextBox
    Friend WithEvents Label186 As System.Windows.Forms.Label
    Friend WithEvents Label187 As System.Windows.Forms.Label
    Friend WithEvents Label188 As System.Windows.Forms.Label
    Friend WithEvents tb_1 As System.Windows.Forms.TextBox
    Friend WithEvents gb_forbrug As System.Windows.Forms.GroupBox
    Friend WithEvents Label191 As System.Windows.Forms.Label
    Friend WithEvents lb_pressnut_kr As System.Windows.Forms.Label
    Friend WithEvents Label190 As System.Windows.Forms.Label
    Friend WithEvents tb_svejsestag_kr_uk As System.Windows.Forms.TextBox
    Friend WithEvents tb_tilsatsmatr_kr_uk As System.Windows.Forms.TextBox
    Friend WithEvents tb_pressnut_kr_uk As System.Windows.Forms.TextBox
    Friend WithEvents Label196 As System.Windows.Forms.Label
    Friend WithEvents lb_tilsatsmatr_kr As System.Windows.Forms.Label
    Friend WithEvents Label198 As System.Windows.Forms.Label
    Friend WithEvents Label193 As System.Windows.Forms.Label
    Friend WithEvents lb_svejsestag_kr As System.Windows.Forms.Label
    Friend WithEvents Label195 As System.Windows.Forms.Label
    Friend WithEvents Label199 As System.Windows.Forms.Label
    Friend WithEvents Label146 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label149 As System.Windows.Forms.Label
    Friend WithEvents tb_sv�rhed_uk As System.Windows.Forms.TextBox
    Friend WithEvents cb_overfl_beh4 As System.Windows.Forms.ComboBox
    Friend WithEvents cb_overfl_beh3 As System.Windows.Forms.ComboBox
    Friend WithEvents cb_overfl_beh2 As System.Windows.Forms.ComboBox
    Friend WithEvents cb_overfl_beh1 As System.Windows.Forms.ComboBox
    Friend WithEvents tb_weldlength As System.Windows.Forms.TextBox
    Friend WithEvents Label189 As System.Windows.Forms.Label
    Friend WithEvents tb_numberofwelds As System.Windows.Forms.TextBox
    Friend WithEvents Label150 As System.Windows.Forms.Label
    Friend WithEvents cb_weld As System.Windows.Forms.CheckBox
    Friend WithEvents cb_grind_weld As System.Windows.Forms.CheckBox
    Friend WithEvents cb_tackweld As System.Windows.Forms.CheckBox
    Friend WithEvents Label194 As System.Windows.Forms.Label
    Friend WithEvents Label197 As System.Windows.Forms.Label
    Friend WithEvents Label200 As System.Windows.Forms.Label
    Friend WithEvents Label192 As System.Windows.Forms.Label
    Friend WithEvents Label203 As System.Windows.Forms.Label
    Friend WithEvents tb_numberofspots As System.Windows.Forms.TextBox
    Friend WithEvents Label202 As System.Windows.Forms.Label
    Friend WithEvents Label201 As System.Windows.Forms.Label
    Friend WithEvents rb_migmag As System.Windows.Forms.RadioButton
    Friend WithEvents rb_tig As System.Windows.Forms.RadioButton
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents lb_pos_ht As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents tb_numberofspotweldseams As System.Windows.Forms.TextBox
    Friend WithEvents cb_spotweld As System.Windows.Forms.CheckBox
    Friend WithEvents lb_r�varer1 As System.Windows.Forms.Label
    Friend WithEvents lb_r�varerstk5 As System.Windows.Forms.Label
    Friend WithEvents lb_r�varerstk4 As System.Windows.Forms.Label
    Friend WithEvents lb_r�varerstk3 As System.Windows.Forms.Label
    Friend WithEvents lb_r�varerstk2 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents tb_overfl_pris2_uk As System.Windows.Forms.TextBox
    Friend WithEvents tb_overfl_pris3_uk As System.Windows.Forms.TextBox
    Friend WithEvents tb_overfl_pris1_uk As System.Windows.Forms.TextBox
    Friend WithEvents Label204 As System.Windows.Forms.Label
    Friend WithEvents lb_nettoareal As System.Windows.Forms.Label
    Friend WithEvents cb_1side_2 As System.Windows.Forms.CheckBox
    Friend WithEvents cb_1side_3 As System.Windows.Forms.CheckBox
    Friend WithEvents cb_1side_1 As System.Windows.Forms.CheckBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label205 As System.Windows.Forms.Label
    Friend WithEvents Label178 As System.Windows.Forms.Label
    Friend WithEvents Label177 As System.Windows.Forms.Label
    Friend WithEvents tb_Kilopris_uk As System.Windows.Forms.TextBox
End Class
