<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class thread_input
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tb_m2 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.tb_m4 = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.tb_m3 = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.tb_m2_5 = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.tb_m6 = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.tb_m8 = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.tb_m10 = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.tb_m5 = New System.Windows.Forms.TextBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'tb_m2
        '
        Me.tb_m2.Location = New System.Drawing.Point(113, 59)
        Me.tb_m2.Name = "tb_m2"
        Me.tb_m2.Size = New System.Drawing.Size(78, 20)
        Me.tb_m2.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(39, 59)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(69, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "M2"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(38, 36)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(69, 20)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Gevind str."
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(113, 36)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(78, 20)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Antal pr emne"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(38, 119)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(69, 20)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "M4"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tb_m4
        '
        Me.tb_m4.Location = New System.Drawing.Point(113, 119)
        Me.tb_m4.Name = "tb_m4"
        Me.tb_m4.Size = New System.Drawing.Size(78, 20)
        Me.tb_m4.TabIndex = 3
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(38, 99)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(69, 20)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "M3"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tb_m3
        '
        Me.tb_m3.Location = New System.Drawing.Point(113, 99)
        Me.tb_m3.Name = "tb_m3"
        Me.tb_m3.Size = New System.Drawing.Size(78, 20)
        Me.tb_m3.TabIndex = 2
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(38, 79)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(69, 20)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "M2,5"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tb_m2_5
        '
        Me.tb_m2_5.Location = New System.Drawing.Point(113, 79)
        Me.tb_m2_5.Name = "tb_m2_5"
        Me.tb_m2_5.Size = New System.Drawing.Size(78, 20)
        Me.tb_m2_5.TabIndex = 1
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(38, 159)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(69, 20)
        Me.Label7.TabIndex = 17
        Me.Label7.Text = "M6"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tb_m6
        '
        Me.tb_m6.Location = New System.Drawing.Point(113, 159)
        Me.tb_m6.Name = "tb_m6"
        Me.tb_m6.Size = New System.Drawing.Size(78, 20)
        Me.tb_m6.TabIndex = 5
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(38, 179)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(69, 20)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "M8"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tb_m8
        '
        Me.tb_m8.Location = New System.Drawing.Point(113, 179)
        Me.tb_m8.Name = "tb_m8"
        Me.tb_m8.Size = New System.Drawing.Size(78, 20)
        Me.tb_m8.TabIndex = 6
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(38, 199)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(69, 20)
        Me.Label9.TabIndex = 13
        Me.Label9.Text = "M10"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tb_m10
        '
        Me.tb_m10.Location = New System.Drawing.Point(113, 199)
        Me.tb_m10.Name = "tb_m10"
        Me.tb_m10.Size = New System.Drawing.Size(78, 20)
        Me.tb_m10.TabIndex = 7
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(38, 139)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(69, 20)
        Me.Label10.TabIndex = 11
        Me.Label10.Text = "M5"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tb_m5
        '
        Me.tb_m5.Location = New System.Drawing.Point(113, 139)
        Me.tb_m5.Name = "tb_m5"
        Me.tb_m5.Size = New System.Drawing.Size(78, 20)
        Me.tb_m5.TabIndex = 4
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(115, 235)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 20)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "Forts�t"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'thread_input
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(257, 282)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.tb_m6)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.tb_m8)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.tb_m10)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.tb_m5)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.tb_m2_5)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.tb_m3)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.tb_m4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.tb_m2)
        Me.Name = "thread_input"
        Me.Text = "GEVIND"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tb_m2 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents tb_m4 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents tb_m3 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents tb_m2_5 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents tb_m6 As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents tb_m8 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents tb_m10 As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents tb_m5 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
