Public Class GetsurfacetreatmentValues

End Class
